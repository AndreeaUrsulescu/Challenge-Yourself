package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

/**
 * Created by Ursulescu on 10.06.2015.
 */
public class CommentChallengeTask extends AsyncTask<Object, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public CommentChallengeTask(AsyncTaskResultProcessing listener) { this.listener = listener; }

    @Override
    protected Map<String, Object> doInBackground(Object... params) {
        JSONObject commentJson = new JSONObject();
        Map<String, Object> result = null;

        try {
            commentJson.put("comment", params[3]);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (commentJson.length() > 0) {
            HttpClient httpClient = new DefaultHttpClient();
            String url = "http://192.168.137.1:8080/challenge-yourself/api/challenge/"
                    + params[0] + "/addcomment";

            if ((int) params[1] != -1) {
                url = url + "?userId=" + params[1];
            } else {
                url = url + "/";
            }
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("X-Auth-Token", (String) params[2]);
            HttpResponse response;

            try {
                StringEntity stringEntity = new StringEntity(commentJson.toString());
                httpPost.setEntity(stringEntity);
                httpPost.setHeader("Content-Type", "application/json");
                response = httpClient.execute(httpPost);

                result = NetworkUtils.getInfoFromHttpResponse(response);
                int statusCode = response.getStatusLine().getStatusCode();
                result.put("statusCode", statusCode);
                result.put("service", "comment");

            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
