package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.challengeyourself.ursulescu.utils.SecurityUtils;

import javax.crypto.SecretKey;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        verifyIfTheUserIsLoggedIn();

        Typeface typeFace = Typeface.createFromAsset(getAssets(), "fonts/always.ttf");

        TextView appName = (TextView) findViewById(R.id.app_name);
        Button logInButton = (Button) findViewById(R.id.log_in);
        Button signUpButton = (Button) findViewById(R.id.sign_up);

        appName.setTypeface(typeFace);
        logInButton.setTypeface(typeFace);
        signUpButton.setTypeface(typeFace);
    }

    public void goToLoginActivity(View v) {
          Intent loginIntent = new Intent(this, LoginActivity.class);
          startActivity(loginIntent);
    }

    public void goToSignUpActivity(View v) {
          Intent signUpIntent = new Intent(this, SignUpActivity.class);
          startActivity(signUpIntent);
    }

    private void verifyIfTheUserIsLoggedIn() {
        String userToken = getUserToken();
        if (userToken != null) {
            Intent homeIntent = new Intent(this, HomeActivity.class);
            startActivity(homeIntent);
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }
}
