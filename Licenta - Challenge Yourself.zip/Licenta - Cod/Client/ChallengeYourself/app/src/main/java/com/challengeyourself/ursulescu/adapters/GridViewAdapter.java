package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.networkTasks.SetUploadedChallengesImageTask;
import com.etsy.android.grid.util.DynamicHeightImageView;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Ursulescu on 12.06.2015.
 */
public class GridViewAdapter extends ArrayAdapter<UserChallenge> {

    private final LayoutInflater layoutInflater;
    private final Random randomRatioGenerator;
    private Context context;
    private static final SparseArray<Double> heightRatios = new SparseArray<>();

    public GridViewAdapter(Context context, int resource, ArrayList<UserChallenge> objects) {
        super(context, resource, objects);
        this.context = context;
        this.layoutInflater = LayoutInflater.from(context);
        this.randomRatioGenerator = new Random();
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.custom_row_staggered_gridview, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.challengeImage = (DynamicHeightImageView) convertView.findViewById(R.id.gridView_image);
            viewHolder.footer = (TextView) convertView.findViewById(R.id.gridView_footer);
            viewHolder.footerImage = (ImageView) convertView.findViewById(R.id.gridView_footer_image);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        double heightRatio = getPositionRatio(position);
        viewHolder.challengeImage.setHeightRatio(heightRatio);
        viewHolder.footer.setText(getItem(position).getChallengeName());
        setFooterImage(viewHolder, position);
        setFont(viewHolder);
        viewHolder.position = position;

        new SetUploadedChallengesImageTask().execute(viewHolder, getItem(position).getEncodedThumbnail(),
                getItem(position).getPhotoOrientation(), position);

        return convertView;
    }

    private void setFooterImage(ViewHolder viewHolder, int position) {
        switch(getItem(position).getChallengeType()) {
            case "friendship":
                viewHolder.footerImage.setImageResource(R.drawable.inf128);
                break;
            case "culture":
                viewHolder.footerImage.setImageResource(R.drawable.book128);
                break;
            case "kitchen":
                viewHolder.footerImage.setImageResource(R.drawable.cake128);
                break;
            case "entertainment":
                viewHolder.footerImage.setImageResource(R.drawable.dj128);
        }
    }

    private double getPositionRatio(final int position) {
        double ratio = heightRatios.get(position, 0.0);

        if (ratio == 0) {
            ratio = getRandomHeightRatio();
            heightRatios.append(position, ratio);
        }
        return ratio;
    }

    private double getRandomHeightRatio() {
        return (randomRatioGenerator.nextDouble() / 2.5) + 1.0;
    }

    public static class ViewHolder {
        public DynamicHeightImageView challengeImage;
        public TextView footer;
        public ImageView footerImage;
        public int position;
    }

    private void setFont(ViewHolder viewHolder) {
        Typeface rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
        viewHolder.footer.setTypeface(rosemaryFont);
    }
}
