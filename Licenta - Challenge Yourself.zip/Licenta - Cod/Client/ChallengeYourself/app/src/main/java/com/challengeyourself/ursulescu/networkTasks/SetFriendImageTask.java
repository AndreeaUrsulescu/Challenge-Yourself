package com.challengeyourself.ursulescu.networkTasks;

import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.challengeyourself.ursulescu.adapters.FriendsAdapter;
import com.challengeyourself.ursulescu.utils.ImageUtils;

/**
 * Created by Ursulescu on 13.06.2015.
 */
public class SetFriendImageTask extends AsyncTask<Object, Void, Object[]> {

    @Override
    protected Object[] doInBackground(Object... params) {
        FriendsAdapter.ViewHolder viewHolder = (FriendsAdapter.ViewHolder) params[0];
        String encodedImage = (String) params[1];
        int photoOrientation = (int) params[2];

        Bitmap imageBitmap = null;

        if (encodedImage.compareTo("Default profile picture") == 0) {
            imageBitmap = null;
        } else {
            imageBitmap = ImageUtils.decodeBase64Image(encodedImage);
        }

        return new Object[] {viewHolder, imageBitmap, photoOrientation, params[3]};
    }

    @Override
    protected void onPostExecute(Object[] result) {
        FriendsAdapter.ViewHolder viewHolder = (FriendsAdapter.ViewHolder) result[0];
        Bitmap imageBitmap = (Bitmap) result[1];
        int photoOrientation = (int) result[2];

        if (viewHolder.position == (int) result[3]) {
            if (imageBitmap != null) {
                viewHolder.friendPhoto.setImageBitmap(imageBitmap);
                ImageUtils.rotateImageViewByOrientation(viewHolder.friendPhoto, photoOrientation);
            }
        }
    }
}
