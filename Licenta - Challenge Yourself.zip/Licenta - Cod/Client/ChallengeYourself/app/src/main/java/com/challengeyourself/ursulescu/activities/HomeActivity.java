package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.challengeyourself.ursulescu.items.UserChallengeStorage;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class HomeActivity extends NavigationDrawerActivity {

    TextView appNameView, myProfileTextView, challengesTextView, newsFeedTextView, searchPeopleTextView;
    Typeface alwaysFont, rosemaryFont;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.home, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        init();
        setTextViewsFonts();
    }

    private void init() {
        appNameView = (TextView) findViewById(R.id.app_name_home);
        myProfileTextView = (TextView) findViewById(R.id.my_profile);
        challengesTextView = (TextView) findViewById(R.id.challenges);
        newsFeedTextView = (TextView) findViewById(R.id.news_feed);
        searchPeopleTextView = (TextView) findViewById(R.id.search_people);

        alwaysFont = Typeface.createFromAsset(getAssets(), "fonts/always.ttf");
        rosemaryFont =Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
    }

    private void setTextViewsFonts() {
        appNameView.setTypeface(alwaysFont);

        myProfileTextView.setTypeface(rosemaryFont);
        newsFeedTextView.setTypeface(rosemaryFont);
        challengesTextView.setTypeface(rosemaryFont);
        searchPeopleTextView.setTypeface(rosemaryFont);
    }

    public void goToMyProfileActivity(View button) {
        UserChallengeStorage.setUserId(-1);
        Intent myProfileIntent = new Intent(this, MyProfileActivity.class);
        myProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(myProfileIntent);
    }

    public void goToChallengesMenuActivity(View button) {
        UserChallengeStorage.setUserId(-1);
        Intent challengesIntent = new Intent(this, ChallengesActivity.class);
        challengesIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(challengesIntent);
    }

    public void goToPeopleActivity(View button) {
        Intent myIntent = new Intent(this, PeopleActivity.class);
        myIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(myIntent);
    }

    public void goToFeedActivity(View button) {
        Intent feedIntent = new Intent(this, FeedActivity.class);
        feedIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(feedIntent);
    }
}
