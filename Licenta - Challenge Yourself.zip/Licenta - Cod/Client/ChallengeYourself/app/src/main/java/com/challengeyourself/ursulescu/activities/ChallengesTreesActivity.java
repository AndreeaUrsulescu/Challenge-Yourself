package com.challengeyourself.ursulescu.activities;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.adapters.ChallengesTreesPagerAdapter;
import com.challengeyourself.ursulescu.challengesTree.ChallengesTree;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.fragments.CultureTreeFragment;
import com.challengeyourself.ursulescu.fragments.EntertainmentTreeFragment;
import com.challengeyourself.ursulescu.fragments.FoodTreeFragment;
import com.challengeyourself.ursulescu.fragments.FriendshipTreeFragment;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.GetChallengeInfoTask;
import com.challengeyourself.ursulescu.networkTasks.PostPictureForChallengeTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageIdByUri;
import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageOrientationByUri;
import static com.challengeyourself.ursulescu.utils.ImageUtils.rotateImageViewByOrientation;

/**
 * Created by Ursulescu on 20.03.2015.
 */
public class ChallengesTreesActivity extends NavigationDrawerFragmentActivity implements View.OnClickListener, AsyncTaskResultProcessing{

    private static final int TAKE_PICTURE_REQUEST_CODE = 100;
    private static final int CHOOSE_FROM_GALLERY_REQUEST_CODE = 200;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    private ViewPager challengesTreesViewPager;
    private ChallengesTreesPagerAdapter challengesTreesPagerAdapter;
    private List<Fragment> challengesPages;

    public ChallengesTree friendshipChallengesTree;
    public ChallengesTree cultureChallengesTree;
    public ChallengesTree kitchenChallengesTree;
    public ChallengesTree entertainmentChallengesTree;

    public String userToken;

    private Dialog challengeDialog;
    private ImageView challengeLogo;
    private TextView challengeTitle, challengeDescription;
    private Button dialogBottomButton;
    private Typeface rosemaryFont;

    private Uri challengePictureUri;
    private int clickedChallengeId;
    private boolean imageHasBeenSetInFrame = false;
    private int treeId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.challenges_trees, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        Log.d("recreated", "create");
        init();

        userToken = getUserToken();
        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }

        createChallengesTrees();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("recreated", "DA");
        clickedChallengeId = savedInstanceState.getInt("clickedChallengeId");
        if (savedInstanceState.containsKey("challengePictureUri")) {
            challengePictureUri = Uri.parse(savedInstanceState.getString("challengePictureUri"));
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    private void createChallengesTrees() {
        createFriendshipTree();
        createCultureTree();
        createKitchenTree();
        createEntertainmentTree();
    }

    private ChallengesTree createChallengeNode(int challengeId, ArrayList<ChallengesTree> challengeDescendants) {
        ChallengesTree challengeNode = new ChallengesTree();

        challengeNode.setChallengeId(challengeId);
        challengeNode.setDescendants(challengeDescendants);

        return challengeNode;
    }

    private void createFriendshipTree() {

        ArrayList<ChallengesTree> challenge16Descendants = new ArrayList<>();
        challenge16Descendants.add(createChallengeNode(R.id.challenge19, null));
        challenge16Descendants.add(createChallengeNode(R.id.challenge20, null));

        ArrayList<ChallengesTree> challenge17Descendants = new ArrayList<>();
        challenge17Descendants.add(createChallengeNode(R.id.challenge21, null));
        challenge17Descendants.add(createChallengeNode(R.id.challenge22, null));

        ArrayList<ChallengesTree> challenge13Descendants = new ArrayList<>();
        challenge13Descendants.add(createChallengeNode(R.id.challenge16, challenge16Descendants));
        challenge13Descendants.add(createChallengeNode(R.id.challenge17, challenge17Descendants));

        ArrayList<ChallengesTree> challenge10Descendants = new ArrayList<>();
        challenge10Descendants.add(createChallengeNode(R.id.challenge13, challenge13Descendants));

        ArrayList<ChallengesTree> challenge12Descendants = new ArrayList<>();
        challenge12Descendants.add(createChallengeNode(R.id.challenge15, null));

        ArrayList<ChallengesTree> challenge9Descendants = new ArrayList<>();
        challenge9Descendants.add(createChallengeNode(R.id.challenge12, challenge12Descendants));

        ArrayList<ChallengesTree> challenge14Descendants = new ArrayList<>();
        challenge14Descendants.add(createChallengeNode(R.id.challenge18, null));

        ArrayList<ChallengesTree> challenge11Descendants = new ArrayList<>();
        challenge11Descendants.add(createChallengeNode(R.id.challenge14, challenge14Descendants));

        ArrayList<ChallengesTree> challenge3Descendants = new ArrayList<>();
        challenge3Descendants.add(createChallengeNode(R.id.challenge9, challenge9Descendants));
        challenge3Descendants.add(createChallengeNode(R.id.challenge10, challenge10Descendants));
        challenge3Descendants.add(createChallengeNode(R.id.challenge11, challenge11Descendants));

        ArrayList<ChallengesTree> challenge2Descendants = new ArrayList<>();
        challenge2Descendants.add(createChallengeNode(R.id.challenge5, null));
        challenge2Descendants.add(createChallengeNode(R.id.challenge6, null));

        ArrayList<ChallengesTree> challenge4Descendants = new ArrayList<>();
        challenge4Descendants.add(createChallengeNode(R.id.challenge7, null));
        challenge4Descendants.add(createChallengeNode(R.id.challenge8, null));

        ArrayList<ChallengesTree> challenge1Descendants = new ArrayList<>();
        challenge1Descendants.add(createChallengeNode(R.id.challenge2, challenge2Descendants));
        challenge1Descendants.add(createChallengeNode(R.id.challenge3, challenge3Descendants));
        challenge1Descendants.add(createChallengeNode(R.id.challenge4, challenge4Descendants));

        friendshipChallengesTree = createChallengeNode(R.id.challenge1, challenge1Descendants);
    }

    private void createCultureTree() {

        ArrayList<ChallengesTree> challenge38Descendants = new ArrayList<>();
        challenge38Descendants.add(createChallengeNode(R.id.challenge41, null));
        challenge38Descendants.add(createChallengeNode(R.id.challenge42, null));

        ArrayList<ChallengesTree> challenge39Descendants = new ArrayList<>();
        challenge39Descendants.add(createChallengeNode(R.id.challenge43, null));
        challenge39Descendants.add(createChallengeNode(R.id.challenge44, null));

        ArrayList<ChallengesTree> challenge35Descendants = new ArrayList<>();
        challenge35Descendants.add(createChallengeNode(R.id.challenge38, challenge38Descendants));
        challenge35Descendants.add(createChallengeNode(R.id.challenge39, challenge39Descendants));

        ArrayList<ChallengesTree> challenge32Descendants = new ArrayList<>();
        challenge32Descendants.add(createChallengeNode(R.id.challenge35, challenge35Descendants));

        ArrayList<ChallengesTree> challenge34Descendants = new ArrayList<>();
        challenge34Descendants.add(createChallengeNode(R.id.challenge37, null));

        ArrayList<ChallengesTree> challenge31Descendants = new ArrayList<>();
        challenge31Descendants.add(createChallengeNode(R.id.challenge34, challenge34Descendants));

        ArrayList<ChallengesTree> challenge36Descendants = new ArrayList<>();
        challenge36Descendants.add(createChallengeNode(R.id.challenge40, null));

        ArrayList<ChallengesTree> challenge33Descendants = new ArrayList<>();
        challenge33Descendants.add(createChallengeNode(R.id.challenge36, challenge36Descendants));

        ArrayList<ChallengesTree> challenge25Descendants = new ArrayList<>();
        challenge25Descendants.add(createChallengeNode(R.id.challenge31, challenge31Descendants));
        challenge25Descendants.add(createChallengeNode(R.id.challenge32, challenge32Descendants));
        challenge25Descendants.add(createChallengeNode(R.id.challenge33, challenge33Descendants));

        ArrayList<ChallengesTree> challenge24Descendants = new ArrayList<>();
        challenge24Descendants.add(createChallengeNode(R.id.challenge27, null));
        challenge24Descendants.add(createChallengeNode(R.id.challenge28, null));

        ArrayList<ChallengesTree> challenge26Descendants = new ArrayList<>();
        challenge26Descendants.add(createChallengeNode(R.id.challenge29, null));
        challenge26Descendants.add(createChallengeNode(R.id.challenge30, null));

        ArrayList<ChallengesTree> challenge23Descendants = new ArrayList<>();
        challenge23Descendants.add(createChallengeNode(R.id.challenge24, challenge24Descendants));
        challenge23Descendants.add(createChallengeNode(R.id.challenge25, challenge25Descendants));
        challenge23Descendants.add(createChallengeNode(R.id.challenge26, challenge26Descendants));

        cultureChallengesTree = createChallengeNode(R.id.challenge23, challenge23Descendants);
    }

    private void createKitchenTree() {

        ArrayList<ChallengesTree> challenge60Descendants = new ArrayList<>();
        challenge60Descendants.add(createChallengeNode(R.id.challenge63, null));
        challenge60Descendants.add(createChallengeNode(R.id.challenge64, null));

        ArrayList<ChallengesTree> challenge61Descendants = new ArrayList<>();
        challenge61Descendants.add(createChallengeNode(R.id.challenge65, null));
        challenge61Descendants.add(createChallengeNode(R.id.challenge66, null));

        ArrayList<ChallengesTree> challenge57Descendants = new ArrayList<>();
        challenge57Descendants.add(createChallengeNode(R.id.challenge60, challenge60Descendants));
        challenge57Descendants.add(createChallengeNode(R.id.challenge61, challenge61Descendants));

        ArrayList<ChallengesTree> challenge54Descendants = new ArrayList<>();
        challenge54Descendants.add(createChallengeNode(R.id.challenge57, challenge57Descendants));

        ArrayList<ChallengesTree> challenge56Descendants = new ArrayList<>();
        challenge56Descendants.add(createChallengeNode(R.id.challenge59, null));

        ArrayList<ChallengesTree> challenge53Descendants = new ArrayList<>();
        challenge53Descendants.add(createChallengeNode(R.id.challenge56, challenge56Descendants));

        ArrayList<ChallengesTree> challenge58Descendants = new ArrayList<>();
        challenge58Descendants.add(createChallengeNode(R.id.challenge62, null));

        ArrayList<ChallengesTree> challenge55Descendants = new ArrayList<>();
        challenge55Descendants.add(createChallengeNode(R.id.challenge58, challenge58Descendants));

        ArrayList<ChallengesTree> challenge47Descendants = new ArrayList<>();
        challenge47Descendants.add(createChallengeNode(R.id.challenge53, challenge53Descendants));
        challenge47Descendants.add(createChallengeNode(R.id.challenge54, challenge54Descendants));
        challenge47Descendants.add(createChallengeNode(R.id.challenge55, challenge55Descendants));

        ArrayList<ChallengesTree> challenge46Descendants = new ArrayList<>();
        challenge46Descendants.add(createChallengeNode(R.id.challenge49, null));
        challenge46Descendants.add(createChallengeNode(R.id.challenge50, null));

        ArrayList<ChallengesTree> challenge48Descendants = new ArrayList<>();
        challenge48Descendants.add(createChallengeNode(R.id.challenge51, null));
        challenge48Descendants.add(createChallengeNode(R.id.challenge52, null));

        ArrayList<ChallengesTree> challenge45Descendants = new ArrayList<>();
        challenge45Descendants.add(createChallengeNode(R.id.challenge46, challenge46Descendants));
        challenge45Descendants.add(createChallengeNode(R.id.challenge47, challenge47Descendants));
        challenge45Descendants.add(createChallengeNode(R.id.challenge48, challenge48Descendants));

        kitchenChallengesTree = createChallengeNode(R.id.challenge45, challenge45Descendants);
    }

    private void createEntertainmentTree() {

        ArrayList<ChallengesTree> challenge82Descendants = new ArrayList<>();
        challenge82Descendants.add(createChallengeNode(R.id.challenge85, null));
        challenge82Descendants.add(createChallengeNode(R.id.challenge86, null));

        ArrayList<ChallengesTree> challenge83Descendants = new ArrayList<>();
        challenge83Descendants.add(createChallengeNode(R.id.challenge87, null));
        challenge83Descendants.add(createChallengeNode(R.id.challenge88, null));

        ArrayList<ChallengesTree> challenge79Descendants = new ArrayList<>();
        challenge79Descendants.add(createChallengeNode(R.id.challenge82, challenge82Descendants));
        challenge79Descendants.add(createChallengeNode(R.id.challenge83, challenge83Descendants));

        ArrayList<ChallengesTree> challenge76Descendants = new ArrayList<>();
        challenge76Descendants.add(createChallengeNode(R.id.challenge79, challenge79Descendants));

        ArrayList<ChallengesTree> challenge78Descendants = new ArrayList<>();
        challenge78Descendants.add(createChallengeNode(R.id.challenge81, null));

        ArrayList<ChallengesTree> challenge75Descendants = new ArrayList<>();
        challenge75Descendants.add(createChallengeNode(R.id.challenge78, challenge78Descendants));

        ArrayList<ChallengesTree> challenge80Descendants = new ArrayList<>();
        challenge80Descendants.add(createChallengeNode(R.id.challenge84, null));

        ArrayList<ChallengesTree> challenge77Descendants = new ArrayList<>();
        challenge77Descendants.add(createChallengeNode(R.id.challenge80, challenge80Descendants));

        ArrayList<ChallengesTree> challenge69Descendants = new ArrayList<>();
        challenge69Descendants.add(createChallengeNode(R.id.challenge75, challenge75Descendants));
        challenge69Descendants.add(createChallengeNode(R.id.challenge76, challenge76Descendants));
        challenge69Descendants.add(createChallengeNode(R.id.challenge77, challenge77Descendants));

        ArrayList<ChallengesTree> challenge68Descendants = new ArrayList<>();
        challenge68Descendants.add(createChallengeNode(R.id.challenge71, null));
        challenge68Descendants.add(createChallengeNode(R.id.challenge72, null));

        ArrayList<ChallengesTree> challenge70Descendants = new ArrayList<>();
        challenge70Descendants.add(createChallengeNode(R.id.challenge73, null));
        challenge70Descendants.add(createChallengeNode(R.id.challenge74, null));

        ArrayList<ChallengesTree> challenge67Descendants = new ArrayList<>();
        challenge67Descendants.add(createChallengeNode(R.id.challenge68, challenge68Descendants));
        challenge67Descendants.add(createChallengeNode(R.id.challenge69, challenge69Descendants));
        challenge67Descendants.add(createChallengeNode(R.id.challenge70, challenge70Descendants));

        entertainmentChallengesTree = createChallengeNode(R.id.challenge67, challenge67Descendants);
    }

    private void init() {
        rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        challengesPages = new ArrayList<>();
        challengesPages.add(Fragment.instantiate(this, FriendshipTreeFragment.class.getName()));
        challengesPages.add(Fragment.instantiate(this, CultureTreeFragment.class.getName()));
        challengesPages.add(Fragment.instantiate(this, FoodTreeFragment.class.getName()));
        challengesPages.add(Fragment.instantiate(this, EntertainmentTreeFragment.class.getName()));

//        findViewById(R.id.challenge23).setOnClickListener(this);

        challengesTreesViewPager = (ViewPager) findViewById(R.id.challenges_tree_container);
        challengesTreesPagerAdapter = new ChallengesTreesPagerAdapter(this.getSupportFragmentManager(), challengesPages);
        challengesTreesViewPager.setAdapter(challengesTreesPagerAdapter);

        Bundle intentExtras = getIntent().getExtras();
        treeId = intentExtras.getInt("tree");

        switch (treeId) {
            case R.id.friendship_button:
                challengesTreesViewPager.setCurrentItem(0);
                break;
            case R.id.culture_button:
                challengesTreesViewPager.setCurrentItem(1);
                break;
            case R.id.kitchen_button:
                challengesTreesViewPager.setCurrentItem(2);
                break;
            case R.id.entertainment_button:
                challengesTreesViewPager.setCurrentItem(3);
        }
    }

    private void initDialog(Dialog challengeDialog) {
        challengeLogo = (ImageView) challengeDialog.findViewById(R.id.challenge_category_picture);
        challengeTitle = (TextView) challengeDialog.findViewById(R.id.challenge_name);
        challengeDescription = (TextView) challengeDialog.findViewById(R.id.challenge_description);
        dialogBottomButton = (Button) challengeDialog.findViewById(R.id.challenge_cancel_button);
    }

    private void setChallengeLogoInDialog(String challengeType) {
        if (challengeType.compareTo("friendship") == 0) {
            challengeLogo.setImageResource(R.drawable.inf128);
        } else if (challengeType.compareTo("culture") == 0) {
            challengeLogo.setImageResource(R.drawable.book128);
        } else if (challengeType.compareTo("kitchen") == 0) {
            challengeLogo.setImageResource(R.drawable.cake128);
        } else if (challengeType.compareTo("entertainment") == 0) {
            challengeLogo.setImageResource(R.drawable.dj128);
        }
    }

    private void setDialogChooseFromGalleryButtonListener() {
        dialogBottomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), CHOOSE_FROM_GALLERY_REQUEST_CODE);
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        if (challengePictureUri != null) {
            outState.putString("challengePictureUri", challengePictureUri.getPath());
        }
        outState.putInt("clickedChallengeId", clickedChallengeId);
        //outState.putInt("treeId", treeId);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       if (requestCode == CHOOSE_FROM_GALLERY_REQUEST_CODE && resultCode != 0) {
            SystemClock.sleep(1000);
            setChallengePictureInFrame("galleryPhoto", data);
            if (imageHasBeenSetInFrame == true) {
                int thumbnailId = (int) getImageIdByUri(challengePictureUri, getContentResolver());
                String thumbnailPath = ImageUtils.getThumbnailPathById(thumbnailId, getContentResolver());
                int imageOrientation = getImageOrientationByUri(challengePictureUri, getContentResolver());
                if (challengeDialog != null) {
                    challengeDialog.dismiss();
                }
                imageHasBeenSetInFrame = false;
                new PostPictureForChallengeTask(this).execute(userToken, String.valueOf(findViewById(clickedChallengeId).getTag()),
                        ImageUtils.getImagePathById(getContentResolver(), String.valueOf(ImageUtils.getImageIdByUri(challengePictureUri, getContentResolver()))), thumbnailPath, "galleryPhoto",
                        String.valueOf(imageOrientation));
            }
        }
    }

    private void setChallengePictureInFrame(String photoType, Intent data) {
        int thumbnailId, imageOrientation = 90;
        LinearLayout challengeFrame = (LinearLayout) findViewById(clickedChallengeId);
        ImageView challengePic = new ImageView(this);

        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        imageParams.gravity = Gravity.CENTER;
        challengePic.setLayoutParams(imageParams);

        challengePic.setAdjustViewBounds(true);
        challengePic.setScaleType(ImageView.ScaleType.CENTER_CROP);

        if (photoType.compareTo("newPhoto") == 0) {
            thumbnailId = ImageUtils.getThumbnailIdForExternalStorageImage(challengePictureUri.getPath(), getContentResolver());
        } else {
            challengePictureUri = data.getData();
            imageOrientation = getImageOrientationByUri(challengePictureUri, getContentResolver());
            thumbnailId = (int) getImageIdByUri(challengePictureUri, getContentResolver());
        }

        if (thumbnailId != -1) {
            imageHasBeenSetInFrame = true;
            challengePic.setImageBitmap(MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),
                    thumbnailId, MediaStore.Images.Thumbnails.MINI_KIND, null));
            challengePic.setRotation(imageOrientation);
            challengeFrame.addView(challengePic);
            challengeFrame.setOnClickListener(this);
        }
    }

    private void setChallengeButtonsAndTextBackground(String challengeCategory) {
        if (challengeCategory.compareTo("friendship") == 0) {
            challengeTitle.setTextColor(Color.parseColor("#A7E4D7"));
            dialogBottomButton.setBackgroundColor(Color.parseColor("#A7E4D7"));

        } else if (challengeCategory.compareTo("culture") == 0) {
            challengeTitle.setTextColor(Color.parseColor("#9DECA9"));
            dialogBottomButton.setBackgroundColor(Color.parseColor("#9DECA9"));

        } else if (challengeCategory.compareTo("kitchen") == 0) {
            challengeTitle.setTextColor(Color.parseColor("#FEAA98"));
            dialogBottomButton.setBackgroundColor(Color.parseColor("#FEAA98"));

        } else if (challengeCategory.compareTo("entertainment") == 0) {
            challengeTitle.setTextColor(Color.parseColor("#C8A4AD"));
            dialogBottomButton.setBackgroundColor(Color.parseColor("#C8A4AD"));
        }
        dialogBottomButton.setTypeface(rosemaryFont);
        setDialogChooseFromGalleryButtonListener();
    }

    private void processChallengeInfoResponse(Map<String, Object> serverResponse) {
        String challengeType = (String) serverResponse.get("challengeType");

        if (challengeType.compareTo("Challenge") == 0) {

            if ((boolean)serverResponse.get("access")) {
                challengeDialog = new Dialog(this);
                challengeDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                challengeDialog.setContentView(R.layout.challenge_dialog);

                WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                layoutParams.copyFrom(challengeDialog.getWindow().getAttributes());
                layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
                challengeDialog.getWindow().setAttributes(layoutParams);

                initDialog(challengeDialog);

                Map<String, Object> challenge = (Map<String, Object>) serverResponse.get("challenge");
                setChallengeLogoInDialog((String) challenge.get("category"));
                challengeTitle.setText((String) challenge.get("name"));
                challengeTitle.setTypeface(rosemaryFont);
                challengeDescription.setText((String) challenge.get("description"));
                challengeDescription.setTypeface(rosemaryFont);
                setChallengeButtonsAndTextBackground((String) challenge.get("category"));

                challengeDialog.show();
            } else {
                //TO DO
            }
        } else if (challengeType.compareTo("UserChallenge") == 0) {
            HashMap<String, Object> challenge = (HashMap<String, Object>) serverResponse.get("challenge");
            UserChallengeStorage.setUserChallenge(NetworkUtils.getUserChallengeFromHashMap(challenge));
            Intent userChallengeIntent = new Intent(this, UserChallengeActivity.class);
            startActivity(userChallengeIntent);
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            if (((String)serverResponse.get("service")).compareTo("getChallengeInfo") == 0) {
                processChallengeInfoResponse(serverResponse);
            } else if (((String)serverResponse.get("service")).compareTo("postPicture") == 0) {
                Toast.makeText(this, "Your photo has been updated!", Toast.LENGTH_LONG).show();
            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void onClick(View v) {
        clickedChallengeId = v.getId();
        int challengeNumber = Integer.parseInt((String) v.getTag());
        new GetChallengeInfoTask(this).execute(challengeNumber, userToken);
    }
}
