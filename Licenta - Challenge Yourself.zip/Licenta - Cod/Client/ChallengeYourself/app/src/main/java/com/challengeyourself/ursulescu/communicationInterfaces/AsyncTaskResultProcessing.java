package com.challengeyourself.ursulescu.communicationInterfaces;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public interface AsyncTaskResultProcessing {
    void processResult(Object[] result);
}
