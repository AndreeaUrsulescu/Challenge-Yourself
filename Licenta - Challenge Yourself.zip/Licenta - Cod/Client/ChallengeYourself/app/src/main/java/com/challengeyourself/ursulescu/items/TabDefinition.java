package com.challengeyourself.ursulescu.items;

import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.MyProfileActivity;

import java.util.UUID;

/**
 * Created by Ursulescu on 10.06.2015.
 */
public class TabDefinition {

    private final String tabUuid;
    private final int tabContentViewId;
    private final String tabTitle;
    private final int tabTitleViewId;
    private final int tabButtonLayoutId;
    private final Fragment fragment;

    public TabDefinition(int tabContentViewId, String title, int tabTitleViewId,
                         int tabLayoutButtonId, Fragment tabFragment) {
        this.tabUuid = String.valueOf(UUID.randomUUID());
        this.tabContentViewId = tabContentViewId;
        this.tabTitle = title;
        this.tabTitleViewId = tabTitleViewId;
        this.tabButtonLayoutId = tabLayoutButtonId;
        this.fragment = tabFragment;
    }

    public String getTabUuid() {
        return tabUuid;
    }

    public int getTabContentViewId() {
        return tabContentViewId;
    }

    public String getTabTitle() {
        return tabTitle;
    }

    public int getTabTitleViewId() {
        return tabTitleViewId;
    }

    public int getTabButtonLayoutId() {
        return tabButtonLayoutId;
    }

    public Fragment getFragment() {
        return fragment;
    }

    public View createView(LayoutInflater inflater, ViewGroup tabsView) {
        View tabView = inflater.inflate(this.tabButtonLayoutId, tabsView, false);
        TextView titleView = (TextView) tabView.findViewById(this.tabTitleViewId);
        titleView.setText(this.tabTitle);
        titleView.setGravity(Gravity.CENTER);
        titleView.setTypeface(MyProfileActivity.rosemaryFont);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.weight = 1;
        tabView.setLayoutParams(layoutParams);
        return tabView;
    }
}
