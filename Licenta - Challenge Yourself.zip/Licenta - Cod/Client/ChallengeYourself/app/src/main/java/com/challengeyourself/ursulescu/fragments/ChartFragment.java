package com.challengeyourself.ursulescu.fragments;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.activities.MainActivity;
import com.challengeyourself.ursulescu.activities.MyProfileActivity;
import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.formatters.PercentValueFormatter;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.GetProfileInfoTask;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Ursulescu on 10.06.2015.
 */
public class ChartFragment extends Fragment implements AsyncTaskResultProcessing{

    private PieChart challengesChart;
    private MyProfileActivity myProfileActivity;
    private Typeface rosemaryFont;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.chart_fragment, container, false);
        challengesChart = (PieChart) view.findViewById(R.id.challenges_chart);
        myProfileActivity = (MyProfileActivity) getActivity();
        new GetProfileInfoTask(this).execute(myProfileActivity.userToken, String.valueOf(UserChallengeStorage.getUserId()));

        return view;
    }

    private void initChart() {
        rosemaryFont = Typeface.createFromAsset(myProfileActivity.getAssets(), "fonts/Rosemary.ttf");
        challengesChart.setCenterText("Passed Challenges");
        challengesChart.setCenterTextColor(Color.WHITE);
        challengesChart.setCenterTextSize(15f);
        challengesChart.setCenterTextTypeface(rosemaryFont);
        challengesChart.setDrawHoleEnabled(true);
        challengesChart.setHoleColorTransparent(true);
        challengesChart.setDescription("");
        challengesChart.setHoleRadius(50f);
        challengesChart.setDrawSliceText(false);
    }

    private void setChartData(List<Float> chartData) {
        initChart();
        ArrayList<String> xVals = new ArrayList<String>();
        xVals.add("Friendship");
        xVals.add("Culture");
        xVals.add("Kitchen");
        xVals.add("Entertainment");

        ArrayList<Entry> yVals1 = new ArrayList<Entry>();

        for (int i = 0; i < chartData.size(); i++) {
            yVals1.add(new Entry(((Number) chartData.get(i)).floatValue(), i));
        }

        PieDataSet dataSet = new PieDataSet(yVals1, "");
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(15f);
        dataSet.setValueTypeface(rosemaryFont);
        dataSet.setSliceSpace(7f);

        ArrayList<Integer> colors = new ArrayList<Integer>();
        colors.add(Color.parseColor("#A7E4D7"));
        colors.add(Color.parseColor("#9DECA9"));
        colors.add(Color.parseColor("#FEAA98"));
        colors.add(Color.parseColor("#C8A4AD"));

        dataSet.setColors(colors);

        PieData pieData = new PieData(xVals, dataSet);
        pieData.setValueFormatter(new PercentValueFormatter());
        challengesChart.setData(pieData);
        setChartLegend();
        challengesChart.invalidate();
    }

    private void setChartLegend() {
        Legend chartLegend = challengesChart.getLegend();
        chartLegend.setPosition(Legend.LegendPosition.RIGHT_OF_CHART_CENTER);
        chartLegend.setTextColor(Color.WHITE);
        chartLegend.setTypeface(rosemaryFont);
        chartLegend.setYEntrySpace(12f);
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            setChartData((List<Float>) serverResponse.get("statistics"));
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(myProfileActivity, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }
}
