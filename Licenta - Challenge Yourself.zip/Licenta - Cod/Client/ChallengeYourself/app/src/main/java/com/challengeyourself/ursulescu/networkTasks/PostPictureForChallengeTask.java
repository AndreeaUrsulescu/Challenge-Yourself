package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.ImageUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 04.05.2015.
 */
public class PostPictureForChallengeTask extends AsyncTask<String, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public PostPictureForChallengeTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(String... params) {
        Map<String, Object> response = new HashMap<>();
        String encodedPicture = ImageUtils.encodeImageToBase64(params[2], true, Integer.valueOf(params[5]));
        String encodedThumbnail = ImageUtils.encodeImageToBase64(params[3], false, null);
        JSONObject challengeInformation = new JSONObject();

        try {
            challengeInformation.put("challengeId", Integer.valueOf(params[1]));
            challengeInformation.put("thumbnail", encodedThumbnail);
            challengeInformation.put("picture", encodedPicture);
            if (params[4].compareTo("newPhoto") == 0) {
                challengeInformation.put("pictureOrientation", 90);
            } else {
                challengeInformation.put("pictureOrientation", Integer.valueOf(params[5]));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (challengeInformation.length() > 0) {
            HttpClient httpClient = new DefaultHttpClient();
            HttpResponse httpResponse;
            HttpPost httpPost = new HttpPost("http://192.168.137.1:8080/challenge-yourself/api/challenge/"
                    + params[1] + "/photo/");
            httpPost.addHeader("X-Auth-Token", params[0]);

            StringEntity stringEntity = null;
            try {
                stringEntity = new StringEntity(challengeInformation.toString());
                httpPost.setEntity(stringEntity);
                httpPost.setHeader("Content-Type", "application/json");
                httpResponse = httpClient.execute(httpPost);
                response.put("service", "postPicture");
                response.put("statusCode", httpResponse.getStatusLine().getStatusCode());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return response;
    }

    protected void onPostExecute(Map<String, Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
