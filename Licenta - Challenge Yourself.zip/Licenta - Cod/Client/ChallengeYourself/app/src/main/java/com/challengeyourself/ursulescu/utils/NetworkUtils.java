package com.challengeyourself.ursulescu.utils;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.challengeyourself.ursulescu.items.Comment;
import com.challengeyourself.ursulescu.items.NewsFeedItem;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.items.User;

import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 27.02.2015.
 */
public class NetworkUtils {

    public static boolean isConnectedToInternet(ConnectivityManager connectivityManager) {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }

    public static String getStringResponse(InputStream inputStream) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();

        try {
            while ((line = bufferedReader.readLine()) != null) {
                result.append(line);
            }
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result.toString();
    }

    public static Map<String, Object> getInfoFromHttpResponse(HttpResponse httpResponse) {
        InputStream inputStream;
        String stringResponse = "";
        Map<String, Object> result = new HashMap<>();

        try {
            inputStream = httpResponse.getEntity().getContent();
            if (inputStream != null) {
                stringResponse = getStringResponse(inputStream);

                if (stringResponse.compareTo("") != 0) {
                    JSONObject jsonResponse = new JSONObject(stringResponse);
                    result = JsonUtils.jsonToMap(jsonResponse);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static ArrayList<User> getVotesFromArrayOfHashMaps(ArrayList<HashMap<String, Object>> hashMapVotes) {
        ArrayList<User> votes = new ArrayList<>();

        for (HashMap<String, Object> vote : hashMapVotes) {
            User userVote = new User();
            userVote.setId((int)vote.get("id"));
            userVote.setName((String) vote.get("name"));
            userVote.setProfilePhoto((String)vote.get("profilePhoto"));
            userVote.setPhotoOrientation((int) vote.get("photoOrientation"));
            votes.add(userVote);
        }

        return votes;
    }

    public static ArrayList<Comment> getCommentsFromArrayOfHashMaps(ArrayList<HashMap<String, Object>> hashMapComments) {
        ArrayList<Comment> comments = new ArrayList<>();

        if (hashMapComments != null) {
            for (HashMap<String, Object> hashMapComment : hashMapComments) {
                Comment comment = new Comment();
                comment.setUsername((String) hashMapComment.get("username"));
                comment.setUserPhoto((String) hashMapComment.get("userPhoto"));
                comment.setComment((String) hashMapComment.get("comment"));
                comment.setPhotoOrientation((Integer) hashMapComment.get("photoOrientation"));
                comment.setDate(new Date((Long) hashMapComment.get("date")));
                comment.setUserId((int)hashMapComment.get("userId"));
                comments.add(comment);
            }
        }
        return comments;
    }

    public static ArrayList<User> getUsersFromArrayOfHashMaps(ArrayList<HashMap<String, Object>> hashMapUsers) {
        ArrayList<User> users = new ArrayList<>();

        for (HashMap<String, Object> user : hashMapUsers) {
            users.add(new User((int)user.get("id"), (String)user.get("name"), (String)user.get("description"),
                    (String)user.get("profilePhoto"),(int) user.get("photoOrientation")));
        }

        return users;
    }

    public static UserChallenge getUserChallengeFromHashMap(HashMap<String, Object> challengeMap) {
        UserChallenge userChallenge = new UserChallenge();

        userChallenge.setChallengeId((int) challengeMap.get("challengeId"));
        userChallenge.setDoneChallenge((String) challengeMap.get("doneChallenge"));
        userChallenge.setEncodedThumbnail((String) challengeMap.get("thumbnail"));
        userChallenge.setEncodedPhoto((String) challengeMap.get("picture"));
        userChallenge.setPhotoOrientation((int) challengeMap.get("pictureOrientation"));
        userChallenge.setChallengeName((String) challengeMap.get("challengeName"));
        userChallenge.setChallengeDecsription((String) challengeMap.get("challengeDescription"));
        userChallenge.setChallengeType((String) challengeMap.get("challengeType"));
        userChallenge.setNumberOfVotes((int) challengeMap.get("numberOfVotes"));
        userChallenge.setUpdateDate(new Date((Long) challengeMap.get("updateDate")));

        return userChallenge;
    }

    public static ArrayList<UserChallenge> getUserChallengesFromArrayOfHaspMaps(
            ArrayList<HashMap<String, Object>> hashMapChallenges) {

        ArrayList<UserChallenge> challenges = new ArrayList<>();

        for (HashMap<String, Object> challenge : hashMapChallenges) {
            challenges.add(getUserChallengeFromHashMap(challenge));
        }

        return challenges;
    }

    public static NewsFeedItem getNewsFeedFromHashMap(HashMap<String, Object> newsFeedItemHashMap) {
        NewsFeedItem newsFeedItem = new NewsFeedItem();

        newsFeedItem.setUserId((Integer) newsFeedItemHashMap.get("userId"));
        newsFeedItem.setUserName((String) newsFeedItemHashMap.get("userName"));
        newsFeedItem.setUserPhoto((String) newsFeedItemHashMap.get("userPhoto"));
        newsFeedItem.setUserPhotoOrientation((Integer) newsFeedItemHashMap.get("userPhotoOrientation"));
        newsFeedItem.setChallengeId((Integer) newsFeedItemHashMap.get("challengeId"));
        newsFeedItem.setChallengeName((String) newsFeedItemHashMap.get("challengeName"));
        newsFeedItem.setChallengeDescription((String) newsFeedItemHashMap.get("challengeDescription"));
        newsFeedItem.setChallengeType((String) newsFeedItemHashMap.get("challengeType"));
        newsFeedItem.setChallengePhoto((String) newsFeedItemHashMap.get("challengePhoto"));
        newsFeedItem.setChallengePhotoOrietation((Integer) newsFeedItemHashMap.get("challengePhotoOrietation"));
        newsFeedItem.setUpdateDate(new Date((Long) newsFeedItemHashMap.get("updateDate")));
        newsFeedItem.setNumberOfVotes((Integer) newsFeedItemHashMap.get("numberOfVotes"));
        newsFeedItem.setCanBeVotted((Boolean) newsFeedItemHashMap.get("canBeVotted"));

        return newsFeedItem;
    }

    public static ArrayList<NewsFeedItem> getNewsFeedItemsFromArrayOfHashMaps(
            ArrayList<HashMap<String, Object>> hashMapNewsFeedItems) {
        ArrayList<NewsFeedItem> newsFeedItems = new ArrayList<>();

        for (HashMap<String, Object> hashMapNewsFeedItem : hashMapNewsFeedItems) {
            newsFeedItems.add(getNewsFeedFromHashMap(hashMapNewsFeedItem));
        }
        return newsFeedItems;

    }
}
