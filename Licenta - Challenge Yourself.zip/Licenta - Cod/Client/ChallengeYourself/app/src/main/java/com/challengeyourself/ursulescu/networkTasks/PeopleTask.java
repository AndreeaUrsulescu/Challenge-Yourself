package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 11.03.2015.
 */
public class PeopleTask extends AsyncTask<Object, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public PeopleTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(Object... params) {

        Map<String, Object> result = new HashMap<>();
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;
        JSONObject range = new JSONObject();
        int responseStatus;

        String userToken = (String) params[2];

        try {
            range.put("firstIndex", params[0]);
            range.put("itemsCount", params[1]);

            HttpPost httpPost = new HttpPost("http://192.168.137.1:8080/challenge-yourself/api/people/");
            StringEntity stringEntity = new StringEntity(range.toString());
            httpPost.setEntity(stringEntity);
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("X-Auth-Token", userToken);

            httpResponse = httpClient.execute(httpPost);
            responseStatus = httpResponse.getStatusLine().getStatusCode();

            if (responseStatus == 200) {
                result = NetworkUtils.getInfoFromHttpResponse(httpResponse);
            }
            result.put("statusCode", responseStatus);
            result.put("service", "getPeople");

            return result;

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
