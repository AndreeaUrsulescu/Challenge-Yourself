package com.challengeyourself.ursulescu.items;

import java.util.Date;

/**
 * Created by Ursulescu on 09.06.2015.
 */
public class Comment {
    private int userId;

    private String username;

    private String userPhoto;

    private String comment;

    private Date date;

    private int photoOrientation;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(int photoOrientation) {
        this.photoOrientation = photoOrientation;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
