package com.challengeyourself.ursulescu.items;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Ursulescu on 25.03.2015.
 */
public class UserChallenge implements Serializable{

    private int challengeId;

    private String doneChallenge;

    private String encodedThumbnail;

    private String encodedPhoto;

    private int photoOrientation;

    private Date updateDate;

    private int numberOfVotes;

    private String challengeName;

    private String challengeDecsription;

    private String challengeType;

    public int getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(int challengeId) {
        this.challengeId = challengeId;
    }

    public String getDoneChallenge() {
        return doneChallenge;
    }

    public void setDoneChallenge(String doneChallenge) {
        this.doneChallenge = doneChallenge;
    }

    public String getEncodedPhoto() {
        return encodedPhoto;
    }

    public void setEncodedPhoto(String encodedPhoto) {
        this.encodedPhoto = encodedPhoto;
    }

    public int getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(int photoOrientation) {
        this.photoOrientation = photoOrientation;
    }

    public String getEncodedThumbnail() {
        return encodedThumbnail;
    }

    public void setEncodedThumbnail(String encodedThumbnail) {
        this.encodedThumbnail = encodedThumbnail;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public int getNumberOfVotes() {
        return numberOfVotes;
    }

    public void setNumberOfVotes(int numberOfVotes) {
        this.numberOfVotes = numberOfVotes;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public String getChallengeDecsription() {
        return challengeDecsription;
    }

    public void setChallengeDecsription(String challengeDecsription) {
        this.challengeDecsription = challengeDecsription;
    }

    public String getChallengeType() {
        return challengeType;
    }

    public void setChallengeType(String challengeType) {
        this.challengeType = challengeType;
    }
}
