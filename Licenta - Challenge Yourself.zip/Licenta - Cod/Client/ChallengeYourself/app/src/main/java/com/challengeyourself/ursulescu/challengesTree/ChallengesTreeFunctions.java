package com.challengeyourself.ursulescu.challengesTree;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/**
 * Created by Ursulescu on 25.03.2015.
 */
public class ChallengesTreeFunctions {

    public static Set<Integer> getNewAvailableChallenges(Map<Integer, String> userChallenges, ChallengesTree tree,
                                                               Set<Integer> availableChallenges) {
        if (userChallenges.containsKey(tree.getChallengeId())) {
            if (userChallenges.get(tree.getChallengeId()).compareTo("yes") == 0) {
                for (ChallengesTree descendant : tree.getDescendants()) {
                    if (!userChallenges.containsKey(descendant.getChallengeId())) {
                        availableChallenges.add(descendant.getChallengeId());
                    } else {
                        availableChallenges.addAll(getNewAvailableChallenges(userChallenges, descendant, availableChallenges));
                   }
                }
            }
        }

        return  availableChallenges;
    }
}
