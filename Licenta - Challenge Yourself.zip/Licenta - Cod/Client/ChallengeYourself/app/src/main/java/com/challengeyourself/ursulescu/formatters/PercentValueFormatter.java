package com.challengeyourself.ursulescu.formatters;

import com.github.mikephil.charting.utils.ValueFormatter;

/**
 * Created by Ursulescu on 11.06.2015.
 */
public class PercentValueFormatter implements ValueFormatter {
    @Override
    public String getFormattedValue(float v) {
        return Math.round(v) + "%";
    }
}
