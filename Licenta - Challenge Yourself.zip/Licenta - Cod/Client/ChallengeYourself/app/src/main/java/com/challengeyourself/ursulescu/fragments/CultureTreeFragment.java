package com.challengeyourself.ursulescu.fragments;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.activities.ChallengesTreesActivity;
import com.challengeyourself.ursulescu.activities.MainActivity;
import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.challengesTree.ChallengesTree;
import com.challengeyourself.ursulescu.challengesTree.ChallengesTreeFunctions;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.networkTasks.GetDoneChallengesTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by Ursulescu on 20.03.2015.
 */
public class CultureTreeFragment extends Fragment implements AsyncTaskResultProcessing{

    private ChallengesTree cultureChallengesTree;
    private String userToken;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.culture_challenges, container, false);

        Typeface typeFace = Typeface.createFromAsset(getActivity().getAssets(), "fonts/always.ttf");
        TextView cultureTextView = (TextView) view.findViewById(R.id.culture_text_view);
        cultureTextView.setTypeface(typeFace);

        cultureChallengesTree = ((ChallengesTreesActivity) getActivity()).cultureChallengesTree;
        userToken = ((ChallengesTreesActivity) getActivity()).userToken;

        LinearLayout firstChallenge = (LinearLayout) view.findViewById(R.id.challenge23);
        firstChallenge.setOnClickListener((View.OnClickListener) getActivity());
        setRetainInstance(true);
        new GetDoneChallengesTask(this).execute("culture", userToken);
        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if(isVisibleToUser) {
            Activity parrentActivity = getActivity();
            if(parrentActivity != null) parrentActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    @Override
    public void processResult(Object[] result) {
        if ((Integer) result[0] == 200) {
            ArrayList<UserChallenge> challenges = (ArrayList<UserChallenge>) result[1];
            RelativeLayout cultureContainer = (RelativeLayout) getView().findViewById(R.id.culture_container);

            if (challenges != null) {
                for (UserChallenge challenge : challenges) {
                    LinearLayout challengeLayout = (LinearLayout) getView().findViewById(getResources().getIdentifier(
                            "challenge" + challenge.getChallengeId(), "id", getActivity().getPackageName()));

                    challengeLayout.setClickable(true);
                    challengeLayout.setOnClickListener((View.OnClickListener) getActivity());

                    ImageView challengePic = new ImageView(getActivity());

                    LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    imageParams.gravity = Gravity.CENTER;
                    challengePic.setLayoutParams(imageParams);

                    challengePic.setAdjustViewBounds(true);
                    challengePic.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    challengePic.setImageBitmap(ImageUtils.decodeBase64Image(challenge.getEncodedPhoto()));
                    challengePic.setRotation(challenge.getPhotoOrientation());
                    challengeLayout.addView(challengePic);


                    cultureContainer.removeView(cultureContainer.findViewById(getResources().getIdentifier(
                            "shadow" + challenge.getChallengeId(), "id", getActivity().getPackageName())));
                }

                Map<Integer, String> challengesIds = new HashMap<>();
                for (UserChallenge challenge : challenges) {
                    challengesIds.put(getResources().getIdentifier("challenge" + challenge.getChallengeId(),
                            "id", getActivity().getPackageName()), challenge.getDoneChallenge());
                }

                Set<Integer> availableChallengesIds = ChallengesTreeFunctions.getNewAvailableChallenges(
                        challengesIds, cultureChallengesTree, new HashSet<Integer>());

                for (Integer challengeViewId : availableChallengesIds) {
                    LinearLayout availableChallenge = (LinearLayout) cultureContainer.findViewById(challengeViewId);

                    cultureContainer.removeView(cultureContainer.findViewById(getResources().getIdentifier(
                            "shadow" + availableChallenge.getTag(), "id", getActivity().getPackageName())));

                    availableChallenge.setClickable(true);
                    availableChallenge.setOnClickListener((View.OnClickListener) getActivity());
                }
            }
        } else if ((Integer) result[0] == 401) {
            Intent mainActivityIntent = new Intent(getActivity(), MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }
}
