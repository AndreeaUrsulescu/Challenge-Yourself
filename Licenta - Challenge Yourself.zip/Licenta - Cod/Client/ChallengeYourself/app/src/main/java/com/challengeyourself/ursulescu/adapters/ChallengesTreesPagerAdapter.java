package com.challengeyourself.ursulescu.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created by Ursulescu on 19.03.2015.
 */
public class ChallengesTreesPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> pagerFragments;

    public ChallengesTreesPagerAdapter(FragmentManager fm, List<Fragment> fragments) {
        super(fm);
        this.pagerFragments = fragments;
    }

    @Override
    public int getCount() {
        return this.pagerFragments.size();
    }

    @Override
    public android.support.v4.app.Fragment getItem(int position) {
        return this.pagerFragments.get(position);
    }
}
