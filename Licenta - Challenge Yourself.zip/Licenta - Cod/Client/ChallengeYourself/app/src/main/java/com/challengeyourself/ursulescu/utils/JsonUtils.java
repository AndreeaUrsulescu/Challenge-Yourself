package com.challengeyourself.ursulescu.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by aursulescu on 2/25/2015.
 */
public class JsonUtils {
    public static Map<String, Object> jsonToMap(JSONObject jsonObject) {
        Map<String, Object> result = new HashMap<>();

        Iterator<String> jsonKeysIterator = jsonObject.keys();
        while(jsonKeysIterator.hasNext()) {
            String jsonKey = jsonKeysIterator.next();
            try {
                Object jsonValue = jsonObject.get(jsonKey);

                if (jsonValue instanceof JSONArray) {
                    jsonValue = jsonArrayToList((JSONArray) jsonValue);
                } else if (jsonValue instanceof JSONObject) {
                    jsonValue = jsonToMap((JSONObject) jsonValue);
                }
                result.put(jsonKey, jsonValue);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    public static List<Object> jsonArrayToList(JSONArray jsonArray) {
        ArrayList<Object> result = new ArrayList<>();

        try {
            for (int contor = 0; contor < jsonArray.length(); contor++) {
                Object jsonValue = jsonArray.get(contor);

                if (jsonValue instanceof JSONArray) {
                    jsonValue = jsonArrayToList((JSONArray) jsonValue);
                } else if (jsonValue instanceof JSONObject) {
                    jsonValue = jsonToMap((JSONObject) jsonValue);
                }
                result.add(jsonValue);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return result;
    }
}
