package com.challengeyourself.ursulescu.activities;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class ChallengesActivity extends NavigationDrawerActivity{

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.challenges_activity, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });
        setFont();
    }

    private void setFont() {
        TextView friendshipCategoryText = (TextView) findViewById(R.id.friendship_category_text);
        TextView cultureCategoryText = (TextView) findViewById(R.id.culture_category_text);
        TextView entertainmentCategoryText = (TextView) findViewById(R.id.entertainment_category_text);
        TextView kitchenCategoryText = (TextView) findViewById(R.id.kitchen_category_text);
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");

        friendshipCategoryText.setTypeface(rosemaryFont);
        cultureCategoryText.setTypeface(rosemaryFont);
        kitchenCategoryText.setTypeface(rosemaryFont);
        entertainmentCategoryText.setTypeface(rosemaryFont);
    }

    public void goToChallengesTree(View button) {
        Intent challengesTreesIntent = new Intent(this, ChallengesTreesActivity.class);
        challengesTreesIntent.putExtra("tree", button.getId());
        startActivity(challengesTreesIntent);
    }
}
