package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.Comment;
import com.challengeyourself.ursulescu.networkTasks.SetCommentImageTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ursulescu on 09.06.2015.
 */
public class CommentsAdapter extends BaseAdapter {

    private List<Comment> comments = new ArrayList<>();
    private Context context;

    public CommentsAdapter(Context context) { this.context = context; }

    @Override
    public int getCount() {
        return comments.size();
    }

    @Override
    public Object getItem(int position) {
        return comments.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addMoreItems(List<Comment> newComments) {
        comments.addAll(newComments);
    }

    public void deleteAll() {
        comments.clear();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.comment_item, null);

            viewHolder = new ViewHolder();
            viewHolder.userPhoto = (CircularImage) convertView.findViewById(R.id.comment_user_photo);
            viewHolder.username = (TextView) convertView.findViewById(R.id.comment_name);
            viewHolder.commentText = (TextView) convertView.findViewById(R.id.comment);

            convertView.setTag(viewHolder);
        }
        else  {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.username.setText(comments.get(position).getUsername());
        viewHolder.commentText.setText(comments.get(position).getComment());
        setFont(viewHolder);
        viewHolder.position = position;

        if (comments.get(position).getUserPhoto().compareTo("Default profile picture") == 0) {
            viewHolder.userPhoto.setImageResource(R.drawable.anonymous_user);
        } else {
            new SetCommentImageTask().execute(viewHolder, comments.get(position).getUserPhoto(),
                    comments.get(position).getPhotoOrientation(), position);
        }

        return convertView;
    }

    public class ViewHolder {
        public CircularImage userPhoto;
        public TextView username;
        public TextView commentText;
        public int position;
    }

    private void setFont(ViewHolder viewHolder) {
        Typeface rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
        viewHolder.username.setTypeface(rosemaryFont);
        viewHolder.commentText.setTypeface(rosemaryFont);
    }
}
