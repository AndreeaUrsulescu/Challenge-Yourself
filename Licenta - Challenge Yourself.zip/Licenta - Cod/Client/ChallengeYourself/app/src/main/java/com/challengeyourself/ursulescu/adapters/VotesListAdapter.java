package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.networkTasks.SetImageInViewHolderTask;
import com.challengeyourself.ursulescu.networkTasks.SetVoteImageTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ursulescu on 03.06.2015.
 */
public class VotesListAdapter extends BaseAdapter {

    private List<User> votes = new ArrayList<>();
    private Context context;

    public VotesListAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return votes.size();
    }

    @Override
    public Object getItem(int position) {
        return votes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return votes.get(position).getId();
    }

    public void addMoreItems(List<User> votesList) {
        votes.addAll(votesList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.vote_item, null);

            viewHolder = new ViewHolder();
            viewHolder.votePicture = (CircularImage) convertView.findViewById(R.id.vote_image);
            viewHolder.voteName = (TextView) convertView.findViewById(R.id.vote_name);

            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.voteName.setText(votes.get(position).getName());
        viewHolder.position = position;
        setFont(viewHolder);

        if (votes.get(position).getProfilePhoto().compareTo("Default profile picture") == 0) {
            viewHolder.votePicture.setImageResource(R.drawable.anonymous_user);
        } else {
            new SetVoteImageTask().execute(viewHolder, votes.get(position).getProfilePhoto(),
                    votes.get(position).getPhotoOrientation(), position);
        }

        return convertView;
    }

    public static class ViewHolder {
        public CircularImage votePicture;
        public TextView voteName;
        public int position;
    }

    private void setFont(ViewHolder viewHolder) {
        Typeface rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
        viewHolder.voteName.setTypeface(rosemaryFont);
    }
}
