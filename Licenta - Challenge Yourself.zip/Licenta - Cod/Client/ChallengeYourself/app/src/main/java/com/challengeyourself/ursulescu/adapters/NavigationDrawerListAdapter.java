package com.challengeyourself.ursulescu.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.items.NavigationDrawerItem;

import java.util.List;

/**
 * Created by Ursulescu on 17.06.2015.
 */
public class NavigationDrawerListAdapter extends BaseAdapter {

    private Context context;
    private List<NavigationDrawerItem> items;
    private Typeface rosemaryFont;

    public NavigationDrawerListAdapter(Context context, List<NavigationDrawerItem> items) {
        this.context = context;
        this.items = items;
        rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.navigation_drawer_item, null);
        }

        ImageView icon = (ImageView) convertView.findViewById(R.id.navigation_drawer_item_image);
        TextView title = (TextView) convertView.findViewById(R.id.navigation_drawer_item_title);

        title.setTypeface(rosemaryFont);
        icon.setImageResource(items.get(position).getIcon());
        title.setText(items.get(position).getTitle());
        return convertView;
    }
}
