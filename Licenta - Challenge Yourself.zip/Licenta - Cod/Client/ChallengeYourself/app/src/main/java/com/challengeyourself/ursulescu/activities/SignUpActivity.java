package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.networkTasks.SendRegisterInformationToServerTask;

import java.util.Map;

import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageIdByUri;
import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageOrientationByUri;
import static com.challengeyourself.ursulescu.utils.ImageUtils.getThumbnailPathById;
import static com.challengeyourself.ursulescu.utils.ImageUtils.rotateImageViewByOrientation;
import static com.challengeyourself.ursulescu.utils.UserValidation.verifyFields;

/**
 * Created by Ursulescu on 18.02.2015.
 */
public class SignUpActivity extends Activity implements AsyncTaskResultProcessing{

    private final int PICK_PROFILE_PICTURE = 0;
    private final String DEFAULT_PROFILE_PICTURE = "Default profile picture";

    private CircularImage profilePicView;
    private Uri profilePictureUri;
    private long profilePictureId = -1;
    int imageOrientation = 0;
    private EditText nameView, emailView, passwordView, passwordConfirmationView, descriptionView;
    private ConnectivityManager connectivityManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initViews();
        setFont();
        connectivityManager = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
    }

    private void initViews() {
        profilePicView = (CircularImage) findViewById(R.id.signup_profilePic);
        nameView = (EditText) findViewById(R.id.signup_username);
        emailView = (EditText) findViewById(R.id.signup_email);
        passwordView = (EditText) findViewById(R.id.signup_password);
        passwordConfirmationView = (EditText) findViewById(R.id.signup_password_confirmation);
        descriptionView = (EditText) findViewById(R.id.signup_about);
    }

    private void setFont() {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        Typeface alwaysFont = Typeface.createFromAsset(getAssets(), "fonts/always.ttf");
        TextView descriptionLabel = (TextView) findViewById(R.id.signup_about_label);
        Button changePhotoButton = (Button) findViewById(R.id.signup_change_photo_btn);
        Button registerButton = (Button) findViewById(R.id.signup_register_button);

        nameView.setTypeface(rosemaryFont);
        emailView.setTypeface(rosemaryFont);
        passwordView.setTypeface(rosemaryFont);
        passwordConfirmationView.setTypeface(rosemaryFont);
        descriptionView.setTypeface(rosemaryFont);
        descriptionLabel.setTypeface(rosemaryFont);
        changePhotoButton.setTypeface(rosemaryFont);
        registerButton.setTypeface(rosemaryFont);
    }

    public void pickProfilePicture(View button) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_PROFILE_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK) && (requestCode == PICK_PROFILE_PICTURE) && (data != null)) {
            profilePictureUri = data.getData();
            imageOrientation = getImageOrientationByUri(profilePictureUri, getContentResolver());
            profilePictureId = getImageIdByUri(profilePictureUri, getContentResolver());
            //profilePictureId = parseUri(profilePictureUri);

            rotateImageViewByOrientation(profilePicView, imageOrientation);

            profilePicView.setImageBitmap(MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),
                    profilePictureId, MediaStore.Images.Thumbnails.MINI_KIND, null));
        }
    }

    public void sendRegisterInformationToServer(View button) {
        String name = nameView.getText().toString();
        String email = emailView.getText().toString();
        String password = passwordView.getText().toString();
        String passwordConfirmation = passwordConfirmationView.getText().toString();
        String description = descriptionView.getText().toString();
        String profilePicturePath = "";

        if (profilePictureId == -1) {
            profilePicturePath = DEFAULT_PROFILE_PICTURE;
        } else {
            profilePicturePath = getThumbnailPathById(profilePictureId, getContentResolver());
        }

        if (!verifyFields(name, email, password, passwordConfirmation, description)) {
            Toast.makeText(getApplicationContext(), "Invalid Information", Toast.LENGTH_LONG).show();
        } else {
            //if (isConnected()) {
                Log.d("challengeYourself", "Connected to the Internet");
                Log.d("challengeYourself", "Name: " + name);
                Log.d("challengeYourself", "Email: " + email);
                Log.d("challengeYourself", "Password: " + password);
                Log.d("challengeYourself", "Description: " + description);
                Log.d("challengeYourself", "ProfilePicturePath: " + profilePicturePath);

                SendRegisterInformationToServerTask sendRegisterInformationToServerTask = new SendRegisterInformationToServerTask(this);
                sendRegisterInformationToServerTask.execute(name, email, password, description, profilePicturePath, String.valueOf(imageOrientation));
            //} else {
              //  Toast.makeText(getApplicationContext(), "You are not connected to the Internet!", Toast.LENGTH_LONG).show();
            //}
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];
        int statusCode = ( (Integer)serverResponse.get("statusCode")).intValue();

        if (statusCode == 200) {
            Boolean success = (Boolean) serverResponse.get("success");
            if (success.booleanValue() == true) {
                Intent loginIntent = new Intent(this, LoginActivity.class);
                loginIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(loginIntent);
            } else {
                //afisare erori register
            }
        } else if (statusCode == 401) {
            Toast.makeText(getApplicationContext(), "You have to sign in!", Toast.LENGTH_LONG).show();
        }
    }
}