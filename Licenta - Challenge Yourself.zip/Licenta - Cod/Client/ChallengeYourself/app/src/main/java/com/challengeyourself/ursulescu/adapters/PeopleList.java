package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.PeopleActivity;
import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.networkTasks.SetImageInViewHolderTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ursulescu on 21.03.2015.
 */
public class PeopleList extends BaseAdapter{
    public ArrayList<User> users = new ArrayList<>();
    private Context context;
    private Typeface rosemaryFont;

    public PeopleList(Context actContext) {
        this.context = actContext;
        rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public Object getItem(int i) {
        return users.get(i);
    }

    @Override
    public long getItemId(int i) {
        return users.get(i).getId();
    }

    public void addItem(User peopleItem) {
        users.add(peopleItem);
    }

    public static class ViewHolder {
        public TextView name;
        public TextView description;
        public CircularImage profilePic;
        public ImageView followButton;
        public int position;
        //public Bitmap imageBitmap;
        //public int photoOrientation;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.people_item, null);

            viewHolder = new ViewHolder();
            viewHolder.name = (TextView) convertView.findViewById(R.id.user_name);
            viewHolder.description = (TextView) convertView.findViewById(R.id.user_description);
            viewHolder.profilePic = (CircularImage) convertView.findViewById(R.id.profile_ph);
            viewHolder.followButton = (ImageView) convertView.findViewById(R.id.follow_button);
            //viewHolder.followButton.setTag(i);

            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.name.setText(users.get(i).getName());
        viewHolder.description.setText(users.get(i).getDescription());
        viewHolder.followButton.setId(users.get(i).getId());

        setFont(viewHolder);

        viewHolder.position = i;

        if (users.get(i).getProfilePhoto().compareTo("Default profile picture") == 0) {
            viewHolder.profilePic.setImageResource(R.drawable.anonymous_user);
        } else {
            new SetImageInViewHolderTask().execute(viewHolder, users.get(i).getProfilePhoto(), users.get(i).getPhotoOrientation(), i);
        }

        return convertView;
    }

    private void setFont(ViewHolder viewHolder) {
        viewHolder.name.setTypeface(rosemaryFont);
        viewHolder.description.setTypeface(rosemaryFont);
    }

    public void addMoreItems(List<User> data) {
        users.addAll(data);
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }
}
