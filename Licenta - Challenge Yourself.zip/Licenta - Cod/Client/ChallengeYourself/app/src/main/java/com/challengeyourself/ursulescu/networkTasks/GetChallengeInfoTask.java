package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.Map;

/**
 * Created by Ursulescu on 24.03.2015.
 */
public class GetChallengeInfoTask extends AsyncTask<Object, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public GetChallengeInfoTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(Object... params) {
        Map<String, Object> result;

        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;

        HttpGet httpGet = new HttpGet("http://192.168.137.1:8080/challenge-yourself/api/challenge/"
                + String.valueOf(params[0]) + "/");
        httpGet.addHeader("X-Auth-Token", (String) params[1]);

        try {
            httpResponse = httpClient.execute(httpGet);
            result = NetworkUtils.getInfoFromHttpResponse(httpResponse);
            result.put("service", "getChallengeInfo");
            result.put("statusCode", httpResponse.getStatusLine().getStatusCode());

            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
