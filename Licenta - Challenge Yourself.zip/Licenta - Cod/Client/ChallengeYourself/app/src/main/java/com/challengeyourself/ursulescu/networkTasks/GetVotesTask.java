package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.Map;

/**
 * Created by Ursulescu on 28.05.2015.
 */
public class GetVotesTask extends AsyncTask<Object, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public GetVotesTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(Object... params) {
        Map<String, Object> result;

        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;

        String url = "http://192.168.137.1:8080/challenge-yourself/api/challenge/"
                + String.valueOf(params[0]) + "/votes?firstIndex=" + String.valueOf(params[2])
                + "&itemsCount=" + String.valueOf(params[3]);

        if (params.length > 4 && (int)params[4] != -1) {
            url = url + "&userId=" + params[4];
        }

        HttpGet httpGet = new HttpGet(url);
        httpGet.addHeader("X-Auth-Token", (String) params[1]);

        try {
            httpResponse = httpClient.execute(httpGet);
            result = NetworkUtils.getInfoFromHttpResponse(httpResponse);
            result.put("statusCode", httpResponse.getStatusLine().getStatusCode());
            result.put("service", "getVotes");

            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
