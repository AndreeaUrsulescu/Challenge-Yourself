package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;
import android.preference.PreferenceActivity;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import static com.challengeyourself.ursulescu.utils.NetworkUtils.getInfoFromHttpResponse;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class LoginTask extends AsyncTask<String, Void, Integer> {
    private AsyncTaskResultProcessing listener;
    private String receivedToken = "";

    public LoginTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Integer doInBackground(String... params) {

        HttpClient httpClient = new DefaultHttpClient();
        JSONObject loginData = new JSONObject();
        HttpResponse httpResponse;
        int responseStatus = -1;

        try {
            loginData.put("email", params[0]);
            loginData.put("password", params[1]);
            loginData.put("deviceRegisterId", params[2]);

            HttpPost httpPost = new HttpPost("http://192.168.137.1:8080/challenge-yourself/authenticate/");
            StringEntity stringEntity = new StringEntity(loginData.toString());
            httpPost.setEntity(stringEntity);
            httpPost.setHeader("Content-Type", "application/json");

            httpResponse = httpClient.execute(httpPost);
            responseStatus = httpResponse.getStatusLine().getStatusCode();
            if (responseStatus == 200) {
                receivedToken = httpResponse.getFirstHeader("X-Auth-Token").getValue();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return responseStatus;
    }

    protected void onPostExecute(Integer result) {
        listener.processResult(new Object[]{receivedToken, result});
    }
}
