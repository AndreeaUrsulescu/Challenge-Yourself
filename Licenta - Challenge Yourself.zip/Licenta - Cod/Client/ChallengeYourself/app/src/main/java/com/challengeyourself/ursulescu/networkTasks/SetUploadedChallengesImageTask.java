package com.challengeyourself.ursulescu.networkTasks;

import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.challengeyourself.ursulescu.adapters.GridViewAdapter;
import com.challengeyourself.ursulescu.utils.ImageUtils;

/**
 * Created by Ursulescu on 13.06.2015.
 */
public class SetUploadedChallengesImageTask extends AsyncTask<Object, Void, Object[]> {
    @Override
    protected Object[] doInBackground(Object... params) {
        GridViewAdapter.ViewHolder viewHolder = (GridViewAdapter.ViewHolder) params[0];
        String encodedImage = (String) params[1];
        int photoOrientation = (int) params[2];

        Bitmap imageBitmap = null;
        imageBitmap = ImageUtils.decodeBase64Image(encodedImage);

        return new Object[] {viewHolder, imageBitmap, photoOrientation, params[3]};
    }

    @Override
    protected void onPostExecute(Object[] result) {
        GridViewAdapter.ViewHolder viewHolder = (GridViewAdapter.ViewHolder) result[0];
        Bitmap imageBitmap = (Bitmap) result[1];
        int photoOrientation = (int) result[2];

        if (viewHolder.position == (int) result[3]) {
            if (imageBitmap != null) {
                viewHolder.challengeImage.setImageBitmap(imageBitmap);
                ImageUtils.rotateImageViewByOrientation(viewHolder.challengeImage, photoOrientation);
            }
        }
    }
}
