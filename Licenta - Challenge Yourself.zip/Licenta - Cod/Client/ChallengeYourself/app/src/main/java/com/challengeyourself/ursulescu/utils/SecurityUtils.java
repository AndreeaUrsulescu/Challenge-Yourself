package com.challengeyourself.ursulescu.utils;

import android.content.Context;
import android.util.Base64;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 09.03.2015.
 */
public class SecurityUtils {

    private static Cipher cipher;

    public static SecretKey generateKey() {
        SecureRandom secureRandom = new SecureRandom();

        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256, secureRandom);

            return keyGenerator.generateKey();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void savePrivateKey(SecretKey secretKey, Context context) {
        char[] password = "tokenSecretKey".toCharArray();

        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null, null);
            FileOutputStream fos = context.openFileOutput("tokenKeyStore", Context.MODE_PRIVATE);

            KeyStore.SecretKeyEntry keyStoreEntry = new KeyStore.SecretKeyEntry(secretKey);
            KeyStore.PasswordProtection keyPassword = new KeyStore.PasswordProtection("secretPassword".toCharArray());
            keyStore.setEntry("tokenSecretKey", keyStoreEntry, keyPassword);
            keyStore.store(fos, password);
            fos.close();

        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static SecretKey getPrivateKey(Context context) {
        char[] password = "tokenSecretKey".toCharArray();
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());

            FileInputStream fileInputStream = context.openFileInput("tokenKeyStore");
            keyStore.load(fileInputStream, password);

            KeyStore.PasswordProtection keyPassword = new KeyStore.PasswordProtection("secretPassword".toCharArray());
            KeyStore.Entry entry = keyStore.getEntry("tokenSecretKey", keyPassword);
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) entry).getSecretKey();
            fileInputStream.close();

            return secretKey;
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
        } catch (UnrecoverableEntryException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String encryptToken(String token, SecretKey secretKey) {
        try {
            cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(token.getBytes());
            return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decryptToken(String encryptedToken, SecretKey secretKey) {
        try {
            byte[] bytesToDecrypt = Base64.decode(encryptedToken, Base64.DEFAULT);
            cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] tokenBytes = cipher.doFinal(bytesToDecrypt);
            return new String(tokenBytes);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        }
        return null;
    }
}
