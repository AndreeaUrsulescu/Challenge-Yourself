package com.challengeyourself.ursulescu.utils;

import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Config;
import android.util.Log;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Ursulescu on 27.02.2015.
 */
public class ImageUtils {
    public static long getImageIdByUri(Uri imageUri, ContentResolver contentResolver) {
//        long thumbnailId = -1;
//        String[] projection = {MediaStore.Images.Media._ID};
//        Cursor cursor = contentResolver.query(imageUri, projection, null, null, null);
//
//        if (cursor != null && cursor.getCount() > 0) {
//            int idColumnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
//
//            cursor.moveToFirst();
//            thumbnailId = cursor.getLong(idColumnIndex);
//            cursor.close();
//        }
//        return thumbnailId;
        String imageIdString = imageUri.getLastPathSegment().substring(6);
        return Long.parseLong(imageIdString);
    }

    public static String getImagePathById(ContentResolver contentResolver, String id) {
        String[] column = { MediaStore.Images.Media.DATA };

// where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = contentResolver.
                query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        column, sel, new String[]{ id }, null);

        String filePath = "";

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }

        cursor.close();
        return filePath;
    }

    public static String getImagePathByUri(Uri imageUri, ContentResolver contentResolver) {
        String imagePath = "";
        String[] projection = { MediaStore.Images.Media.DATA};
        Cursor cursor = contentResolver.query(imageUri, projection, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            int dataColumnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            imagePath = cursor.getString(dataColumnIndex);
            cursor.close();
        }
        return imagePath;
    }

    public static void rotateImageViewByOrientation(ImageView imageView, int orientationAngle) {
        imageView.setRotation(orientationAngle);
    }

    public static int getImageOrientationByUri(Uri imageUri, ContentResolver contentResolver) {
        int thumbnailOrientation = -1;
        String[] projection = {MediaStore.Images.Media.ORIENTATION};
        Cursor cursor = contentResolver.query(imageUri, projection, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            int orientationColumnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.ORIENTATION);

            cursor.moveToFirst();
            thumbnailOrientation = cursor.getInt(orientationColumnIndex);
            cursor.close();
        }
        return thumbnailOrientation;
    }

    public static String getThumbnailPathById(long thumbnailId, ContentResolver contentResolver) {
        String result = "";
        Cursor cursor = MediaStore.Images.Thumbnails.queryMiniThumbnail(contentResolver, thumbnailId,
                MediaStore.Images.Thumbnails.MINI_KIND, null);
        if (cursor != null && cursor.getCount() > 0) {
            cursor.moveToFirst();
            result = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Thumbnails.DATA));
            cursor.close();
        }
        return result;
    }

    public static String encodeImageToBase64(String imagePath, boolean resize, Integer photoOrientation ) {
        Bitmap imageBitmap;

        if (resize) {
            if (photoOrientation == 90 || photoOrientation == 270) {
                imageBitmap = decodeSampledBitmapFromPath(imagePath, 500, 300);
            } else {
                imageBitmap = decodeSampledBitmapFromPath(imagePath, 500, 500);
            }
        }  else {
            imageBitmap = BitmapFactory.decodeFile(imagePath);
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    public static Bitmap decodeSampledBitmapFromPath(String path, int requiredWidth,
                                                   int requiredHeight) {

        Bitmap bm = null;
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);
        options.inSampleSize = calculateInSampleSize(options, requiredWidth, requiredHeight);
        options.inJustDecodeBounds = false;
        bm = BitmapFactory.decodeFile(path, options);

        return bm;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options,
                                            int requiredWidth, int requiredHeight) {
        final int actualHeight = options.outHeight;
        final int actualWidth = options.outWidth;
        int inSampleSize = 1;

        if (actualHeight > requiredHeight || actualWidth > requiredWidth) {
            if (actualWidth > actualHeight) {
                inSampleSize = Math.round((float) actualHeight / (float) requiredHeight);
            } else {
                inSampleSize = Math.round((float) actualWidth / (float) requiredWidth);
            }
        }

        return inSampleSize;
    }

    public static byte[] decodeBase64ImageBytes(String encodedImage) {
        return Base64.decode(encodedImage, 0);
    }

    public static Bitmap decodeBase64Image(String encodedImage) {
        byte[] imageBytes = Base64.decode(encodedImage, 0);

        return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
    }

    public static Uri getChallengeImageUriForStoring() {
        File challengesImagesDirectory = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "ChallengeYourself");

        if (!challengesImagesDirectory.exists()) {
            if (!challengesImagesDirectory.mkdirs()) {
                return null;
            }
        }

        String timestamp = new SimpleDateFormat("ddMMyyyy_HHmmss").format(new Date());
        File challengeImageFile = new File(challengesImagesDirectory + File.separator
                + "IMG_" + timestamp + ".jpg");
        return Uri.fromFile(challengeImageFile);
    }

    public static int getThumbnailIdForExternalStorageImage(String imagePath, ContentResolver contentResolver) {
        int thumbnailId = -1;
        Cursor cursor = contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[] {MediaStore.MediaColumns._ID}, MediaStore.MediaColumns.DATA + "=?",
                new String[] {imagePath}, null);
        if (cursor != null && cursor.moveToFirst()) {
            thumbnailId = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
            cursor.close();
        }
        return thumbnailId;
    }
}
