package com.challengeyourself.ursulescu.activities;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.adapters.CommentsAdapter;
import com.challengeyourself.ursulescu.adapters.VotesListAdapter;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.Comment;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.CommentChallengeTask;
import com.challengeyourself.ursulescu.networkTasks.GetChallengeInfoTask;
import com.challengeyourself.ursulescu.networkTasks.GetCommentsTask;
import com.challengeyourself.ursulescu.networkTasks.GetUserChallengeInfoTask;
import com.challengeyourself.ursulescu.networkTasks.GetVotesTask;
import com.challengeyourself.ursulescu.networkTasks.PostPictureForChallengeTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;
import com.challengeyourself.ursulescu.utils.TimeUtils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageIdByUri;
import static com.challengeyourself.ursulescu.utils.ImageUtils.getImageOrientationByUri;

/**
 * Created by Ursulescu on 19.05.2015.
 */
public class UserChallengeActivity extends NavigationDrawerActivity implements AsyncTaskResultProcessing, ListView.OnScrollListener{
    private static final int CHOOSE_FROM_GALLERY_REQUEST_CODE = 200;

    private UserChallenge userChallenge;
    private String userToken;

    private ListView votesList;
    private VotesListAdapter votesListAdapter;
    private Dialog votesDialog;

    private ListView commentsList;
    private CommentsAdapter commentsAdapter;
    private Dialog commentsDialog;

    private Uri challengePictureUri;

    private int numberOfCommentsBlocks = 0;
    private int commentItemsCountUntilAutoload = 3;
    private int numberOfCommentItemsPerPage = 20;
    private boolean commentsLoading = false;
    private boolean moreCommentDataAvailable = true;

    private int numberOfVotesBlocks = 0;
    private int voteItemsCountUntilAutoload = 3;
    private int numberOfVoteItemsPerPage = 20;
    private boolean votesLoading = false;
    private boolean moreVoteDataAvailable = true;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.user_challenge_activity, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        setFont();

        userToken = getUserToken();

        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else if (UserChallengeStorage.getUserChallenge() != null) {
            userChallenge = UserChallengeStorage.getUserChallenge();
            updateChallengeInformation();
        } else {
            Integer userChallengeId = UserChallengeStorage.userChallengeId;
            //Integer.parseInt(getIntent().getExtras().getString("msg"));
            new GetUserChallengeInfoTask(this).execute(userChallengeId, userToken);
        }
    }

    private void setFont() {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        Button votesButton = (Button) findViewById(R.id.userChallenge_votesBtn);
        Button commentsButton = (Button) findViewById(R.id.userChallenge_commentsButton);
        Button changePicButton = (Button) findViewById(R.id.userChallenge_updateButton);
        TextView time = (TextView) findViewById(R.id.userChallenge_time);
        TextView title = (TextView) findViewById(R.id.userChallenge_title);
        TextView description = (TextView) findViewById(R.id.userChallenge_description);

        votesButton.setTypeface(rosemaryFont);
        commentsButton.setTypeface(rosemaryFont);
        changePicButton.setTypeface(rosemaryFont);
        time.setTypeface(rosemaryFont);
        title.setTypeface(rosemaryFont);
        description.setTypeface(rosemaryFont);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initVotesDialog(List<User> votes) {
        votesList = (ListView) votesDialog.findViewById(R.id.votes_list);
        votesListAdapter = new VotesListAdapter(this);
        votesListAdapter.addMoreItems(votes);
        votesList.setAdapter(votesListAdapter);
        votesList.setScrollingCacheEnabled(false);
        votesList.setOnScrollListener(this);
        votesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChallengeStorage.setUserId(((User) votesListAdapter.getItem(position)).getId());
                Intent userProfileIntent = new Intent(UserChallengeActivity.this, MyProfileActivity.class);
                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(userProfileIntent);
            }
        });
    }

    private void initCommentsDialog(List<Comment> comments) {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        EditText editComment = (EditText) commentsDialog.findViewById(R.id.edit_comment);

        editComment.setTypeface(rosemaryFont);
        commentsList = (ListView) commentsDialog.findViewById(R.id.comments_list);
        commentsAdapter = new CommentsAdapter(this);
        commentsAdapter.addMoreItems(comments);
        commentsList.setAdapter(commentsAdapter);
        commentsList.setScrollingCacheEnabled(false);
        commentsList.setOnScrollListener(this);
        commentsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChallengeStorage.setUserId(((Comment) commentsAdapter.getItem(position)).getUserId());
                Intent userProfileIntent = new Intent(UserChallengeActivity.this, MyProfileActivity.class);
                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(userProfileIntent);
            }
        });

        LinearLayout addCommentLayout = (LinearLayout) commentsDialog.findViewById(R.id.add_comment_layout);
        addCommentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText commentEditText = (EditText) commentsDialog.findViewById(R.id.edit_comment);
                if (commentEditText.getText().toString().trim().length() > 0) {
                    new CommentChallengeTask(UserChallengeActivity.this).execute(userChallenge.getChallengeId(),
                            UserChallengeStorage.getUserId(), userToken, commentEditText.getText().toString().trim());
                    commentEditText.setText("");
                }
            }
        });
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    private void updateChallengeInformation() {
        TextView challengeTitle = (TextView) findViewById(R.id.userChallenge_title);
        TextView challengeDescription = (TextView) findViewById(R.id.userChallenge_description);
        ImageView challengePhoto = (ImageView) findViewById(R.id.userChallenge_photo);
        final Button updateButton = (Button) findViewById(R.id.userChallenge_updateButton);

        setChallengeIconAndButtonsColor();
        challengeTitle.setText(userChallenge.getChallengeName());
        challengeDescription.setText(userChallenge.getChallengeDecsription());
        challengePhoto.setImageBitmap(ImageUtils.decodeBase64Image(userChallenge.getEncodedPhoto()));
        challengePhoto.setRotation(userChallenge.getPhotoOrientation());
        setVotesButtonListener();
        setCommentsButtonListener();

        if (userChallenge.getDoneChallenge().compareTo("yes") == 0) {
            ((LinearLayout) updateButton.getParent()).removeView(updateButton);
        } else {
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), CHOOSE_FROM_GALLERY_REQUEST_CODE);
                }
            });
        }

        setPassedTime();
    }

    private void setCommentsButtonListener() {
        Button commentsButton = (Button) findViewById(R.id.userChallenge_commentsButton);
        commentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commentsLoading = true;
                moreCommentDataAvailable = true;
                numberOfCommentsBlocks = 0;
                new GetCommentsTask(UserChallengeActivity.this).execute(userChallenge.getChallengeId(),
                        UserChallengeStorage.getUserId(), 0, numberOfCommentItemsPerPage, userToken);
            }
        });
    }

    private void setVotesButtonListener() {
        Button votesButton = (Button) findViewById(R.id.userChallenge_votesBtn);
        votesButton.setText(userChallenge.getNumberOfVotes() + " Votes");
        if (userChallenge.getNumberOfVotes() > 0) {
            votesButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    votesLoading = true;
                    moreVoteDataAvailable = true;
                    numberOfVotesBlocks = 0;
                    new GetVotesTask(UserChallengeActivity.this).execute(userChallenge.getChallengeId(),
                            userToken, 0, numberOfVoteItemsPerPage);
                }
            });
        }
    }

    private void setPassedTime(){
        TextView timeView = (TextView) findViewById(R.id.userChallenge_time);
        Date currentDate = new Date();
//        int minutes = (int) ((currentDate.getTime()/60000) - (userChallenge.getUpdateDate().getTime()/60000));
//        int hours = minutes/60;
//        timeView.setText(hours + "h " + (minutes - (hours * 60)) + "m");
        timeView.setText(TimeUtils.getPassedTime(userChallenge.getUpdateDate(), currentDate));
    }

    private void setChallengeIconAndButtonsColor() {
        ImageView challengeIcon = (ImageView) findViewById(R.id.userChallenge_icon);
        Button commentsBtn = (Button) findViewById(R.id.userChallenge_commentsButton);
        Button updatePhotoBtn = (Button) findViewById(R.id.userChallenge_updateButton);

        switch(userChallenge.getChallengeType()) {
            case "friendship":
                challengeIcon.setImageResource(R.drawable.inf128);
                commentsBtn.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                updatePhotoBtn.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                break;
            case "culture":
                challengeIcon.setImageResource(R.drawable.book128);
                commentsBtn.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                updatePhotoBtn.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                break;
            case "kitchen":
                challengeIcon.setImageResource(R.drawable.cake128);
                commentsBtn.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                updatePhotoBtn.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                break;
            case "entertainment":
                challengeIcon.setImageResource(R.drawable.dj128);
                commentsBtn.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
                updatePhotoBtn.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
        }
    }

    private void showVotes(List<User> votes) {
        if (numberOfVotesBlocks == 0) {
            votesDialog = new Dialog(this);
            votesDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            votesDialog.setContentView(R.layout.votes_dialog);
            initVotesDialog(votes);
            votesDialog.show();
            numberOfVotesBlocks++;
        } else {
            votesListAdapter.addMoreItems(votes);
            votesListAdapter.notifyDataSetChanged();
        }

        if (votes.size() < numberOfVoteItemsPerPage) {
            moreVoteDataAvailable = false;
        }
    }

    private void showComments(List<Comment> comments) {
        if (numberOfCommentsBlocks == 0) {
            commentsDialog = new Dialog(this);
            commentsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            commentsDialog.setContentView(R.layout.comments_dialog);
            initCommentsDialog(comments);
            commentsDialog.show();
            numberOfCommentsBlocks++;
        } else {
            commentsAdapter.addMoreItems(comments);
            commentsAdapter.notifyDataSetChanged();
        }
        if (comments.size() < numberOfCommentItemsPerPage) {
            moreCommentDataAvailable = false;
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            if (((String)serverResponse.get("service")).compareTo("getVotes") == 0) {
                votesLoading = false;
                if ((boolean)serverResponse.get("existVotes")) {
                    showVotes(NetworkUtils.getVotesFromArrayOfHashMaps(
                            (ArrayList<HashMap<String, Object>>) serverResponse.get("votes")));
                } else {
                    moreVoteDataAvailable = false;
                }
            } else if (((String)serverResponse.get("service")).compareTo("getComments") == 0) {
                commentsLoading = false;
                if (!(boolean)serverResponse.get("existComments")) {
                    moreCommentDataAvailable = false;
                }
                showComments(NetworkUtils.getCommentsFromArrayOfHashMaps(
                        (ArrayList<HashMap<String, Object>>) serverResponse.get("comments")));
            } else if (((String)serverResponse.get("service")).compareTo("comment") == 0) {
                commentsAdapter.deleteAll();
                numberOfCommentsBlocks++;
                new GetCommentsTask(this).execute(userChallenge.getChallengeId(), UserChallengeStorage.getUserId(),
                        0, numberOfCommentItemsPerPage, userToken);
            } else if (((String)serverResponse.get("service")).compareTo("getUserChallengeInfo") == 0) {
                userChallenge = NetworkUtils.getUserChallengeFromHashMap(
                        (HashMap<String, Object>) serverResponse.get("challenge"));
                updateChallengeInformation();
            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {}

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        switch (view.getId()) {
            case R.id.votes_list:
                if (!votesLoading && moreVoteDataAvailable) {
                    if (totalItemCount - voteItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        votesLoading = true;
                        new GetVotesTask(this).execute(userChallenge.getChallengeId(), userToken, totalItemCount, numberOfVoteItemsPerPage);
                    }
                }
                break;
            case R.id.comments_list:
                if (!commentsLoading && moreCommentDataAvailable) {
                    if (totalItemCount - commentItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        commentsLoading = true;
                        new GetCommentsTask(UserChallengeActivity.this).execute(userChallenge.getChallengeId(),
                                UserChallengeStorage.getUserId(), totalItemCount, numberOfCommentItemsPerPage, userToken);
                    }
                }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CHOOSE_FROM_GALLERY_REQUEST_CODE) {
            setChallengePictureInFrame(data);
            int thumbnailId = (int) getImageIdByUri(challengePictureUri, getContentResolver());
            String thumbnailPath = ImageUtils.getThumbnailPathById(thumbnailId, getContentResolver());
            int imageOrientation = getImageOrientationByUri(challengePictureUri, getContentResolver());

            new PostPictureForChallengeTask(this).execute(userToken, String.valueOf(userChallenge.getChallengeId()),
                    ImageUtils.getImagePathById(getContentResolver(), String.valueOf(ImageUtils.getImageIdByUri(challengePictureUri, getContentResolver()))), thumbnailPath, "galleryPhoto",
                    String.valueOf(imageOrientation));
        }
    }

    private void setChallengePictureInFrame(Intent data) {
        int imageOrientation;
        ImageView challengePic = (ImageView) findViewById(R.id.userChallenge_photo);
        Button votesButton = (Button) findViewById(R.id.userChallenge_votesBtn);
        TextView time = (TextView) findViewById(R.id.userChallenge_time);

        votesButton.setText(0 + " Votes");
        time.setText("0m");

        challengePictureUri = data.getData();
        imageOrientation = getImageOrientationByUri(challengePictureUri, getContentResolver());

        challengePic.setRotation(imageOrientation);
        challengePic.setImageBitmap(ImageUtils.decodeSampledBitmapFromPath(ImageUtils.getImagePathById(getContentResolver(),
                String.valueOf(ImageUtils.getImageIdByUri(challengePictureUri, getContentResolver()))), 500, 500));
    }
}
