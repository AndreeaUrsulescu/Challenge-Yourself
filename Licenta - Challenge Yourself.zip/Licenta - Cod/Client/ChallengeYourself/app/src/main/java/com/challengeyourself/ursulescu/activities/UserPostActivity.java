package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.adapters.CommentsAdapter;
import com.challengeyourself.ursulescu.adapters.VotesListAdapter;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.Comment;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.CommentChallengeTask;
import com.challengeyourself.ursulescu.networkTasks.GetCommentsTask;
import com.challengeyourself.ursulescu.networkTasks.GetProfileInfoTask;
import com.challengeyourself.ursulescu.networkTasks.GetVotesTask;
import com.challengeyourself.ursulescu.networkTasks.VoteChallengeTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;
import com.challengeyourself.ursulescu.utils.TimeUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 16.06.2015.
 */
public class UserPostActivity extends NavigationDrawerActivity implements AsyncTaskResultProcessing, View.OnClickListener, AbsListView.OnScrollListener {

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    private String userToken;
    private UserChallenge userChallenge;

    private int numberOfVotesBlocks = 0;
    private int voteItemsCountUntilAutoload = 3;
    private int numberOfVoteItemsPerPage = 20;
    private boolean votesLoading = false;
    private boolean moreVoteItemsAvailable = true;

    private int numberOfCommentsBlocks = 0;
    private int commentItemsCountUntilAutoload = 3;
    private int numberOfCommentItemsPerPage = 20;
    private boolean commentsLoading = false;
    private  boolean moreCommentItemsAvailable = true;

    private Dialog votesDialog;
    private ListView votesList;
    private VotesListAdapter votesListAdapter;

    private Dialog commentsDialog;
    private ListView commentsList;
    private CommentsAdapter commentsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View userPostActivityView = layoutInflater.inflate(R.layout.user_post_activity, null);
        frameLayout.addView(userPostActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        setFont();

        userToken = getUserToken();
        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else {
            userChallenge = UserChallengeStorage.getUserChallenge();
            initActivity();
        }
    }

    private void setFont() {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        TextView name = (TextView) findViewById(R.id.post_username);
        TextView time = (TextView) findViewById(R.id.post_time);
        TextView challengeName = (TextView) findViewById(R.id.post_challenge_name);
        TextView challengeDesc = (TextView) findViewById(R.id.post_challenge_desc);
        Button approveBtn = (Button) findViewById(R.id.post_approve_button);
        Button votesBtn = (Button) findViewById(R.id.post_votes_button);
        Button commentsBtn = (Button) findViewById(R.id.post_comments_button);

        name.setTypeface(rosemaryFont);
        time.setTypeface(rosemaryFont);
        challengeName.setTypeface(rosemaryFont);
        challengeDesc.setTypeface(rosemaryFont);
        approveBtn.setTypeface(rosemaryFont);
        votesBtn.setTypeface(rosemaryFont);
        commentsBtn.setTypeface(rosemaryFont);
    }

    private void initActivity() {
        TextView challengeDescription = (TextView) findViewById(R.id.post_challenge_desc);
        TextView challengeName = (TextView) findViewById(R.id.post_challenge_name);
        Button votesButton = (Button) findViewById(R.id.post_votes_button);

        challengeDescription.setText(userChallenge.getChallengeDecsription());
        challengeName.setText(userChallenge.getChallengeName());
        votesButton.setText(userChallenge.getNumberOfVotes() + " Votes");
        setPassedTime();
        setButtonsColorAndChallengeIcon();
        setButtonsOnClickListener();
        setChallengePhoto();
        new GetProfileInfoTask(this).execute(userToken, String.valueOf(UserChallengeStorage.getUserId()));
    }

    private void setChallengePhoto() {
        ImageView challengePhoto = (ImageView) findViewById(R.id.post_photo);
        challengePhoto.setImageBitmap(ImageUtils.decodeBase64Image(userChallenge.getEncodedPhoto()));
        ImageUtils.rotateImageViewByOrientation(challengePhoto, userChallenge.getPhotoOrientation());
    }

    private void setButtonsOnClickListener() {
        final Button votesButton = (Button) findViewById(R.id.post_votes_button);
        Button commentsButton = (Button) findViewById(R.id.post_comments_button);
        final Button approveButton = (Button) findViewById(R.id.post_approve_button);

        votesButton.setOnClickListener(this);
        commentsButton.setOnClickListener(this);
        if (UserChallengeStorage.getUserId() == -1) {
            LinearLayout approveButtonLayout = (LinearLayout) findViewById(R.id.user_post_buttons_layout);
            approveButtonLayout.removeView(approveButton);
        }else {
            approveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    approveButton.setEnabled(false);
                    approveButton.setBackgroundColor(Color.LTGRAY);
                    votesButton.setText((userChallenge.getNumberOfVotes() + 1) + " Votes");
                    new VoteChallengeTask(UserPostActivity.this).execute(userChallenge.getChallengeId(),
                            UserChallengeStorage.getUserId(), userToken);
                }
            });
        }
    }

    private void setPassedTime(){
        TextView timeText = (TextView) findViewById(R.id.post_time);
        Date currentDate = new Date();
        timeText.setText(TimeUtils.getPassedTime(userChallenge.getUpdateDate(), currentDate));
    }

    private void setButtonsColorAndChallengeIcon() {
        ImageView challengeIcon = (ImageView) findViewById(R.id.post_challenge_icon);
        Button votesButton = (Button) findViewById(R.id.post_votes_button);
        Button commentsButton = (Button) findViewById(R.id.post_comments_button);
        Button approveButton = (Button) findViewById(R.id.post_approve_button);

        switch(userChallenge.getChallengeType()) {
            case "friendship":
                challengeIcon.setImageResource(R.drawable.inf128);
                votesButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                commentsButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                approveButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                break;
            case "culture":
                challengeIcon.setImageResource(R.drawable.book128);
                votesButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                commentsButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                approveButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                break;
            case "kitchen":
                challengeIcon.setImageResource(R.drawable.cake128);
                votesButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                commentsButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                approveButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                break;
            case "entertainment":
                challengeIcon.setImageResource(R.drawable.dj128);
                votesButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
                commentsButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
                approveButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    private void setUserInfo(User user) {
        CircularImage profilePhoto = (CircularImage) findViewById(R.id.post_user_photo);
        TextView username = (TextView) findViewById(R.id.post_username);

        username.setText(user.getName());
        if (user.getProfilePhoto().compareTo("Default profile picture") == 0) {
            profilePhoto.setImageResource(R.drawable.anonymous_user);
        } else {
            profilePhoto.setImageBitmap(ImageUtils.decodeBase64Image(user.getProfilePhoto()));
            ImageUtils.rotateImageViewByOrientation(profilePhoto, user.getPhotoOrientation());
        }
    }

    private void initVotesDialog(List<User> votes) {
        votesList = (ListView) votesDialog.findViewById(R.id.votes_list);
        votesListAdapter = new VotesListAdapter(this);
        votesListAdapter.addMoreItems(votes);
        votesList.setAdapter(votesListAdapter);
        votesList.setScrollingCacheEnabled(false);
        votesList.setOnScrollListener(this);
//        votesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                UserChallengeStorage.setUserId(((User) votesListAdapter.getItem(position)).getId());
//                Intent userProfileIntent = new Intent(UserPostActivity.this, MyProfileActivity.class);
//                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//                votesDialog.dismiss();
//                //UserPostActivity.this.finish();
//                startActivity(userProfileIntent);
//            }
//        });
    }

    private void showVotes(List<User> votes) {
        if (numberOfVotesBlocks == 0) {
            votesDialog = new Dialog(this);
            votesDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            votesDialog.setContentView(R.layout.votes_dialog);
            initVotesDialog(votes);
            votesDialog.show();
            numberOfVotesBlocks++;
        } else {
            votesListAdapter.addMoreItems(votes);
            votesListAdapter.notifyDataSetChanged();
        }

        if (votes.size() < numberOfVoteItemsPerPage) {
            moreVoteItemsAvailable = false;
        }
    }

    private void initCommentsDialog(List<Comment> comments) {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        EditText editComment = (EditText) commentsDialog.findViewById(R.id.edit_comment);

        editComment.setTypeface(rosemaryFont);
        commentsList = (ListView) commentsDialog.findViewById(R.id.comments_list);
        commentsAdapter = new CommentsAdapter(this);
        commentsAdapter.addMoreItems(comments);
        commentsList.setAdapter(commentsAdapter);
        commentsList.setScrollingCacheEnabled(false);
        commentsList.setOnScrollListener(this);
//        commentsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                UserChallengeStorage.setUserId(((Comment) commentsAdapter.getItem(position)).getUserId());
//                Intent userProfileIntent = new Intent(UserPostActivity.this, MyProfileActivity.class);
//                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//                startActivity(userProfileIntent);
//            }
//        });

        LinearLayout addCommentLayout = (LinearLayout) commentsDialog.findViewById(R.id.add_comment_layout);
        addCommentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText commentEditText = (EditText) commentsDialog.findViewById(R.id.edit_comment);
                if (commentEditText.getText().toString().trim().length() > 0) {
                    new CommentChallengeTask(UserPostActivity.this).execute(userChallenge.getChallengeId(),
                            UserChallengeStorage.getUserId(), userToken, commentEditText.getText().toString().trim());
                    commentEditText.setText("");
                }
            }
        });
    }

    private void showComments(List<Comment> comments) {
        if (numberOfCommentsBlocks == 0) {
            commentsDialog = new Dialog(this);
            commentsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            commentsDialog.setContentView(R.layout.comments_dialog);
            initCommentsDialog(comments);
            commentsDialog.show();
            numberOfCommentsBlocks++;
        } else {
            commentsAdapter.addMoreItems(comments);
            commentsAdapter.notifyDataSetChanged();
        }

        if (comments.size() < numberOfCommentItemsPerPage) {
            moreCommentItemsAvailable = false;
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            if (((String)serverResponse.get("service")).compareTo("getMyProfileInfo") == 0) {
                ArrayList<HashMap<String, Object>> users = new ArrayList<>();
                users.add((HashMap<String, Object>) serverResponse.get("userInfo"));
                setUserInfo(NetworkUtils.getUsersFromArrayOfHashMaps(users).get(0));
            } else if (((String)serverResponse.get("service")).compareTo("getVotes") == 0) {
                votesLoading = false;
                if ((boolean)serverResponse.get("existVotes")) {
                    showVotes(NetworkUtils.getVotesFromArrayOfHashMaps(
                            (ArrayList<HashMap<String, Object>>) serverResponse.get("votes")));
                } else {
                    moreVoteItemsAvailable = false;
                }
            } else if (((String)serverResponse.get("service")).compareTo("getComments") == 0) {
                commentsLoading = false;
                if (!(boolean)serverResponse.get("existComments")) {
                    moreCommentItemsAvailable = false;
                }
                showComments(NetworkUtils.getCommentsFromArrayOfHashMaps(
                        (ArrayList<HashMap<String, Object>>) serverResponse.get("comments")));
            } else if (((String)serverResponse.get("service")).compareTo("comment") == 0) {
                commentsAdapter.deleteAll();
                numberOfCommentsBlocks++;
                new GetCommentsTask(this).execute(userChallenge.getChallengeId(), UserChallengeStorage.getUserId(),
                        0, numberOfCommentItemsPerPage, userToken);
            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.post_votes_button:
                votesLoading = true;
                numberOfVotesBlocks = 0;
                new GetVotesTask(this).execute(userChallenge.getChallengeId(), userToken,
                        0, numberOfVoteItemsPerPage, UserChallengeStorage.getUserId());
                break;
            case R.id.post_comments_button:
                commentsLoading = true;
                numberOfCommentsBlocks = 0;
                new GetCommentsTask(this).execute(userChallenge.getChallengeId(), UserChallengeStorage.getUserId(),
                        0, numberOfCommentItemsPerPage, userToken);
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {}

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        switch(view.getId())  {
            case R.id.votes_list:
                if (!votesLoading && moreVoteItemsAvailable) {
                    if (totalItemCount - voteItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        votesLoading = true;
                        new GetVotesTask(this).execute(userChallenge.getChallengeId(), userToken,
                                totalItemCount, numberOfVoteItemsPerPage, UserChallengeStorage.getUserId());
                    }
                }
            case R.id.comments_list:
                if (!commentsLoading && moreCommentItemsAvailable) {
                    if (totalItemCount - commentItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        commentsLoading = true;
                        new GetCommentsTask(this).execute(userChallenge.getChallengeId(), UserChallengeStorage.getUserId(),
                                totalItemCount, numberOfCommentItemsPerPage, userToken);
                    }
                }
        }
    }
}
