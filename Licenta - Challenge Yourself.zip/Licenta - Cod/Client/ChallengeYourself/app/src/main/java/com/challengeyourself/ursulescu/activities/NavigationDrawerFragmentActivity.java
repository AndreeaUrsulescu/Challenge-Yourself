package com.challengeyourself.ursulescu.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.challengeyourself.ursulescu.adapters.NavigationDrawerListAdapter;
import com.challengeyourself.ursulescu.items.NavigationDrawerItem;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.LogoutTask;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 17.06.2015.
 */
public class NavigationDrawerFragmentActivity extends FragmentActivity {

    private DrawerLayout drawerLayout;
    private ListView navigationDrawerList;

    private String[] navigationDrawerTitles;
    private TypedArray navigationDrawerIcons;

    private List<NavigationDrawerItem> navigationDrawerItems;
    private NavigationDrawerListAdapter navigationDrawerListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navigation_drawer_activity);

        navigationDrawerTitles = getResources().getStringArray(R.array.navigation_drawer_items);
        navigationDrawerIcons = getResources().obtainTypedArray(R.array.navigation_drawer_icons);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationDrawerList = (ListView) findViewById(R.id.navigation_drawer_list);

        navigationDrawerItems = new ArrayList<>();

        for (int i = 0; i < navigationDrawerTitles.length; i++) {
            navigationDrawerItems.add(new NavigationDrawerItem(navigationDrawerTitles[i],
                    navigationDrawerIcons.getResourceId(i, -1)));
        }
        navigationDrawerIcons.recycle();
        navigationDrawerListAdapter = new NavigationDrawerListAdapter(getApplicationContext(), navigationDrawerItems);
        navigationDrawerList.setAdapter(navigationDrawerListAdapter);

        navigationDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        Intent homeIntent = new Intent(NavigationDrawerFragmentActivity.this, HomeActivity.class);
                        startActivity(homeIntent);
                        break;
                    case 1:
                        UserChallengeStorage.setUserId(-1);
                        Intent myProfileIntent = new Intent(NavigationDrawerFragmentActivity.this, MyProfileActivity.class);
                        startActivity(myProfileIntent);
                        break;
                    case 2:
                        UserChallengeStorage.setUserId(-1);
                        Intent challengesInent = new Intent(NavigationDrawerFragmentActivity.this, ChallengesActivity.class);
                        startActivity(challengesInent);
                        break;
                    case 3:
                        Intent feedIntent = new Intent(NavigationDrawerFragmentActivity.this, FeedActivity.class);
                        startActivity(feedIntent);
                        break;
                    case 4:
                        Intent peopleIntent = new Intent(NavigationDrawerFragmentActivity.this, PeopleActivity.class);
                        startActivity(peopleIntent);
                        break;
                    case 5:
                        logout();
                }
                drawerLayout.closeDrawer(navigationDrawerList);
            }
        });
    }

    private void logout() {
        String userToken = getUserToken();
        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else {
            SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove("loginToken");
            editor.commit();

            new LogoutTask(this).execute(userToken);
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }
}
