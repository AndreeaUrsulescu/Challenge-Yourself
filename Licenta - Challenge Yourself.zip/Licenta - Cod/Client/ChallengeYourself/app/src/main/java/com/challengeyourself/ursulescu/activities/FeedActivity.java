package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.adapters.CommentsAdapter;
import com.challengeyourself.ursulescu.adapters.NewsFeedAdapter;
import com.challengeyourself.ursulescu.adapters.VotesListAdapter;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.Comment;
import com.challengeyourself.ursulescu.items.NewsFeedItem;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.CommentChallengeTask;
import com.challengeyourself.ursulescu.networkTasks.GetCommentsTask;
import com.challengeyourself.ursulescu.networkTasks.GetVotesTask;
import com.challengeyourself.ursulescu.networkTasks.NewsFeedTask;
import com.challengeyourself.ursulescu.networkTasks.PeopleTask;
import com.challengeyourself.ursulescu.networkTasks.SearchUserTask;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class FeedActivity extends NavigationDrawerActivity implements AsyncTaskResultProcessing,
        ListView.OnScrollListener, Button.OnClickListener {

    private String userToken;
    private ListView newsFeedList;
    private NewsFeedAdapter newsFeedAdapter;
    private NewsFeedItem currentItem;

    private Dialog votesDialog;
    private ListView votesList;
    private VotesListAdapter votesListAdapter;

    private Dialog commentsDialog;
    private ListView commentsList;
    private CommentsAdapter commentsAdapter;

    private int newsFeedItemsCountUntilAutoload = 3;
    private int numberOfNewsFeedItemsPerPage = 10;
    private int maximumNumberOfNewsFeedItems = 100;
    private boolean newsFeedLoading = false;
    private boolean moreNewsFeedItemsAvailable = true;

    private int numberOfVotesBlocks = 0;
    private int voteItemsCountUntilAutoload = 3;
    private int numberOfVoteItemsPerPage = 20;
    private boolean votesLoading = false;
    private boolean moreVoteItemsAvailable = true;

    private int numberOfCommentsBlocks = 0;
    private int commentItemsCountUntilAutoload = 3;
    private int numberOfCommentItemsPerPage = 20;
    private boolean commentsLoading = false;
    private  boolean moreCommentItemsAvailable = true;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View feedActivityView = layoutInflater.inflate(R.layout.news_feed_activity, null);
        frameLayout.addView(feedActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        userToken = getUserToken();
        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else {
            newsFeedLoading = true;
            init();
            new NewsFeedTask(this).execute(0, 10, userToken);
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    private void init() {
        newsFeedList = (ListView) findViewById(R.id.news_feed_list);
        newsFeedAdapter = new NewsFeedAdapter(this, this, userToken);
        newsFeedList.setAdapter(newsFeedAdapter);
        newsFeedList.setOnScrollListener(this);
        newsFeedList.setScrollingCacheEnabled(false);
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            if (((String)serverResponse.get("service")).compareTo("getNewsFeed") == 0) {
                newsFeedLoading = false;
                ArrayList<NewsFeedItem> newsFeedItems = NetworkUtils.getNewsFeedItemsFromArrayOfHashMaps((ArrayList<HashMap<String, Object>>) serverResponse.get("newsFeed"));
                if (newsFeedItems.size() > 0) {
                    newsFeedAdapter.addMoreItems(newsFeedItems);
                    newsFeedAdapter.notifyDataSetChanged();

                    if (newsFeedItems.size() < numberOfNewsFeedItemsPerPage) {
                        moreNewsFeedItemsAvailable = false;
                    }
                } else {
                    moreNewsFeedItemsAvailable = false;
                }
            } else if (((String)serverResponse.get("service")).compareTo("getVotes") == 0) {
                votesLoading = false;
                if ((boolean)serverResponse.get("existVotes")) {
                    showVotes(NetworkUtils.getVotesFromArrayOfHashMaps(
                            (ArrayList<HashMap<String, Object>>) serverResponse.get("votes")));
                } else {
                    moreVoteItemsAvailable = false;
                }
            } else if (((String)serverResponse.get("service")).compareTo("getComments") == 0) {
                commentsLoading = false;
                if (!(boolean)serverResponse.get("existComments")) {
                    moreCommentItemsAvailable = false;
                }
                showComments(NetworkUtils.getCommentsFromArrayOfHashMaps(
                        (ArrayList<HashMap<String, Object>>) serverResponse.get("comments")));
            } else if (((String)serverResponse.get("service")).compareTo("comment") == 0) {
                commentsAdapter.deleteAll();
                new GetCommentsTask(this).execute(currentItem.getChallengeId(), currentItem.getUserId(),
                        0, numberOfCommentItemsPerPage, userToken);

            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {}

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        switch(view.getId())  {
            case R.id.news_feed_list:
                if (!newsFeedLoading && moreNewsFeedItemsAvailable) {

                    if ((totalItemCount >= maximumNumberOfNewsFeedItems)) {
                        moreNewsFeedItemsAvailable = false;
                    } else if (totalItemCount - newsFeedItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        newsFeedLoading = true;
                        new NewsFeedTask(this).execute(totalItemCount, numberOfNewsFeedItemsPerPage, userToken);
                    }
                }
                break;
            case R.id.votes_list:
                if (!votesLoading && moreVoteItemsAvailable) {
                    if (totalItemCount - voteItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        votesLoading = true;
                        new GetVotesTask(this).execute(currentItem.getChallengeId(), userToken,
                                totalItemCount, numberOfVoteItemsPerPage, currentItem.getUserId());
                    }
                }
                break;
            case R.id.comments_list:
                if (!commentsLoading && moreCommentItemsAvailable) {
                    if (totalItemCount - commentItemsCountUntilAutoload <=
                            firstVisibleItem + visibleItemCount) {
                        commentsLoading = true;
                        new GetCommentsTask(this).execute(currentItem.getChallengeId(), currentItem.getUserId(),
                                totalItemCount, numberOfCommentItemsPerPage, userToken);
                    }
                }
        }
    }

    private void initVotesDialog(List<User> votes) {
        votesList = (ListView) votesDialog.findViewById(R.id.votes_list);
        votesListAdapter = new VotesListAdapter(this);
        votesListAdapter.addMoreItems(votes);
        votesList.setAdapter(votesListAdapter);
        votesList.setScrollingCacheEnabled(false);
        votesList.setOnScrollListener(this);
        votesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChallengeStorage.setUserId(((User) votesListAdapter.getItem(position)).getId());
                Intent userProfileIntent = new Intent(FeedActivity.this, MyProfileActivity.class);
                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(userProfileIntent);
            }
        });
    }

    private void initCommentsDialog(List<Comment> comments) {
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        EditText editComment = (EditText) commentsDialog.findViewById(R.id.edit_comment);

        editComment.setTypeface(rosemaryFont);
        commentsList = (ListView) commentsDialog.findViewById(R.id.comments_list);
        commentsAdapter = new CommentsAdapter(this);
        commentsAdapter.addMoreItems(comments);
        commentsList.setAdapter(commentsAdapter);
        commentsList.setScrollingCacheEnabled(false);
        commentsList.setOnScrollListener(this);
        commentsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChallengeStorage.setUserId(((Comment)commentsAdapter.getItem(position)).getUserId());
                Intent userProfileIntent = new Intent(FeedActivity.this, MyProfileActivity.class);
                userProfileIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(userProfileIntent);
            }
        });

        LinearLayout addCommentLayout = (LinearLayout) commentsDialog.findViewById(R.id.add_comment_layout);
        addCommentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText commentEditText = (EditText) commentsDialog.findViewById(R.id.edit_comment);
                if (commentEditText.getText().toString().trim().length() > 0) {
                    new CommentChallengeTask(FeedActivity.this).execute(currentItem.getChallengeId(),
                            currentItem.getUserId(), userToken, commentEditText.getText().toString().trim());
                    commentEditText.setText("");
                }
            }
        });
    }

    private void showVotes(List<User> votes) {
        if (numberOfVotesBlocks == 0) {
            votesDialog = new Dialog(this);
            votesDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            votesDialog.setContentView(R.layout.votes_dialog);
            initVotesDialog(votes);
            votesDialog.show();
            numberOfVotesBlocks++;
        } else {
            votesListAdapter.addMoreItems(votes);
            votesListAdapter.notifyDataSetChanged();
        }

        if (votes.size() < numberOfVoteItemsPerPage) {
            moreVoteItemsAvailable = false;
        }
    }

    private void showComments(List<Comment> comments) {
        if (numberOfCommentsBlocks == 0) {
            commentsDialog = new Dialog(this);
            commentsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            commentsDialog.setContentView(R.layout.comments_dialog);
            initCommentsDialog(comments);
            commentsDialog.show();
            numberOfCommentsBlocks++;
        } else {
            commentsAdapter.addMoreItems(comments);
            commentsAdapter.notifyDataSetChanged();
        }

        if (comments.size() < numberOfCommentItemsPerPage) {
            moreCommentItemsAvailable = false;
        }
    }


    @Override
    public void onClick(View v) {
        int feedItemOrderNumber = (int) v.getTag();
        currentItem = (NewsFeedItem) newsFeedAdapter.getItem(feedItemOrderNumber);

        switch (v.getId()) {
            case R.id.feed_votes_button:
                votesLoading = true;
                numberOfVotesBlocks = 0;
                new GetVotesTask(FeedActivity.this).execute(currentItem.getChallengeId(), userToken,
                        0, numberOfVoteItemsPerPage, currentItem.getUserId());
                break;
            case R.id.feed_comments_button:
                commentsLoading = true;
                numberOfCommentsBlocks = 0;
                new GetCommentsTask(this).execute(currentItem.getChallengeId(), currentItem.getUserId(),
                        0, numberOfCommentItemsPerPage, userToken);
        }
    }
}
