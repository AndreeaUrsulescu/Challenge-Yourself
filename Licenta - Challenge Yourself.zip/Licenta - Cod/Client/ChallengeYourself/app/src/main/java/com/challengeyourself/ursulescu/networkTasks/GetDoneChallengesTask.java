package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 25.03.2015.
 */
public class GetDoneChallengesTask extends AsyncTask<String, Void, ArrayList<UserChallenge>> {

    private AsyncTaskResultProcessing listener;

    private int statusCode;

    public GetDoneChallengesTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected ArrayList<UserChallenge> doInBackground(String... params) {
        Map<String, Object> result;

        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;

        HttpGet httpGet = new HttpGet("http://192.168.137.1:8080/challenge-yourself/api/challenges/"
                + params[0] + "/");
        httpGet.addHeader("X-Auth-Token", params[1]);

        try {
            httpResponse = httpClient.execute(httpGet);
            statusCode =  httpResponse.getStatusLine().getStatusCode();

            if (statusCode == 200) {
                result = NetworkUtils.getInfoFromHttpResponse(httpResponse);

                if ((boolean) result.get("existChallenges")) {
                    return NetworkUtils.getUserChallengesFromArrayOfHaspMaps((ArrayList<HashMap<String, Object>>) result.get("challenges"));
                } else {
                    //de completat
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    protected void onPostExecute(ArrayList<UserChallenge> challenges) {
        listener.processResult(new Object[]{statusCode, challenges});
    }
}
