package com.challengeyourself.ursulescu.networkTasks;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.JsonUtils;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import static com.challengeyourself.ursulescu.utils.ImageUtils.encodeImageToBase64;
import static com.challengeyourself.ursulescu.utils.NetworkUtils.getInfoFromHttpResponse;

/**
 * Created by Ursulescu on 24.02.2015.
 */
public class SendRegisterInformationToServerTask extends AsyncTask<String, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public SendRegisterInformationToServerTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(String... params) {
        JSONObject userInformation = new JSONObject();
        String profileImagePath = params[4];
        Map<String, Object> result = null;

        try {
            userInformation.put("name", params[0].trim());
            userInformation.put("email", params[1].trim());
            userInformation.put("password", params[2]);
            userInformation.put("description", params[3].trim());

            if (profileImagePath.compareTo("Default profile picture") != 0) {
                userInformation.put("profilePhoto", encodeImageToBase64(profileImagePath, false, null));
            } else {
                userInformation.put("profilePhoto", profileImagePath);
            }
            userInformation.put("photoOrientation", Integer.valueOf(params[5]));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (userInformation.length() > 0) {

            HttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost("http://192.168.137.1:8080/challenge-yourself/register/");
            HttpResponse response;

            try {
                StringEntity stringEntity = new StringEntity(userInformation.toString());
                httpPost.setEntity(stringEntity);
                httpPost.setHeader("Content-Type", "application/json");
                response = httpClient.execute(httpPost);

                result = getInfoFromHttpResponse(response);
                int statusCode = response.getStatusLine().getStatusCode();
                result.put("statusCode", statusCode);

            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
