package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.GetProfileInfoTask;
import com.challengeyourself.ursulescu.utils.ImageUtils;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class MyProfileActivity extends NavigationDrawerFragmentActivity implements AsyncTaskResultProcessing{

    public String userToken;
    private Dialog descriptionDialog;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;
    public static Typeface rosemaryFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.activity_myprofile, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        setFont();

        userToken = getUserToken();
        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else {
            new GetProfileInfoTask(this).execute(userToken, String.valueOf(UserChallengeStorage.getUserId()));
        }
    }

    private void setFont() {
        rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        TextView username = (TextView) findViewById(R.id.profile_name);
        Button changePhotoButton = (Button) findViewById(R.id.profile_description);
        username.setTypeface(rosemaryFont);
        changePhotoButton.setTypeface(rosemaryFont);
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    private void showDescriptionDialog(String description) {
        descriptionDialog = new Dialog(this);
        descriptionDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        descriptionDialog.setContentView(R.layout.description_dialog);

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(descriptionDialog.getWindow().getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        descriptionDialog.getWindow().setAttributes(layoutParams);

        TextView descriptionTextView = (TextView) descriptionDialog.findViewById(R.id.description_text);
        descriptionTextView.setText(description);
        descriptionDialog.show();
    }

    private void setUserInfo(final User user) {
        CircularImage profilePhoto = (CircularImage) findViewById(R.id.profile_photo);
        TextView username = (TextView) findViewById(R.id.profile_name);
        Button descriptionButton = (Button) findViewById(R.id.profile_description);

        username.setText(user.getName());
        descriptionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionDialog(user.getDescription());
            }
        });

        if (user.getProfilePhoto().compareTo("Default profile picture") == 0) {
            profilePhoto.setImageResource(R.drawable.anonymous_user);
        } else {
            profilePhoto.setImageBitmap(ImageUtils.decodeBase64Image(user.getProfilePhoto()));
            ImageUtils.rotateImageViewByOrientation(profilePhoto, user.getPhotoOrientation());
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            ArrayList<HashMap<String, Object>> users = new ArrayList<>();
            users.add((HashMap<String, Object>) serverResponse.get("userInfo"));
            setUserInfo(NetworkUtils.getUsersFromArrayOfHashMaps(users).get(0));
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }
}
