package com.challengeyourself.ursulescu.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by Ursulescu on 19.06.2015.
 */
public class TimeUtils {

    private static Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    private static int getDiffYears(Date first, Date last) {
        Calendar a = getCalendar(first);
        Calendar b = getCalendar(last);
        int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
        if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH) ||
                (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a.get(Calendar.MONTH) > b.get(Calendar.MONTH))) {
            diff--;
        }
        return diff;
    }

    private static int differenceInMonths(Date d1, Date d2) {
        Calendar c1 = getCalendar(d1);
        Calendar c2 = getCalendar(d2);
        int diff = 0;

        if (c2.after(c1)) {
            while (c2.after(c1)) {
                c1.add(Calendar.MONTH, 1);
                if (c2.after(c1)) {
                    diff++;
                }
            }
        } else if (c2.before(c1)) {
            while (c2.before(c1)) {
                c1.add(Calendar.MONTH, -1);
                if (c1.before(c2)) {
                    diff--;
                }
            }
        }
        return diff;
    }

    private static int getWeeks(int days) {
        return days/7;
    }

    private static int getDays(int hours) {
        return hours/24;
    }

    private static int getHours(int minutes) { return minutes/60; }

    public static String getPassedTime(Date firstDate, Date lastDate) {
        int minutes = (int) ((lastDate.getTime()/60000) - (firstDate.getTime()/60000));

        if (minutes >= 60) {
            int hours = getHours(minutes);
            if (hours >= 24) {
                int days = getDays(hours);
                int months = differenceInMonths(firstDate, lastDate);
                if (months > 1) {
                    int years = getDiffYears(firstDate, lastDate);
                    if (years > 1) {
                        return years + "y";
                    } else {
                        return months + "months";
                    }
                } else {
                    return days + "d";
                }
            } else {
                return hours + "h";
            }
        } else {
            return minutes + "m";
        }
//        int difference = getDiffYears(firstDate, lastDate);
//
//        if (difference > 0) {
//            return String.valueOf(difference) + "y";
//        } else {
//            difference = differenceInMonths(firstDate, lastDate);
//            if (difference < 11) {}
//        }
    }
}
