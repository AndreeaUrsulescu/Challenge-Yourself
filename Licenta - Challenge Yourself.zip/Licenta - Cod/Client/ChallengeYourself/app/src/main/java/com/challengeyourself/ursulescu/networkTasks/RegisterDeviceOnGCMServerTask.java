package com.challengeyourself.ursulescu.networkTasks;

import android.content.Context;
import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.google.android.gms.gcm.GoogleCloudMessaging;

import java.io.IOException;

/**
 * Created by Ursulescu on 18.06.2015.
 */
public class RegisterDeviceOnGCMServerTask extends AsyncTask<Context, Void, String> {

    private static final String GOOGLE_PROJECT_ID = "231776710303";

    private GoogleCloudMessaging gcm;
    private AsyncTaskResultProcessing listener;

    public RegisterDeviceOnGCMServerTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected String doInBackground(Context... params) {
        String regId = "";

        try {
            if (gcm == null) {
                gcm = GoogleCloudMessaging.getInstance(params[0]);
            }
            //gcm.unregister();
            regId = gcm.register(GOOGLE_PROJECT_ID);

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return regId;
    }

    @Override
    protected void onPostExecute(String msg) {
        listener.processResult(new Object[]{msg, new String("registerDevice")});
    }
}
