package com.challengeyourself.ursulescu.items;

import android.graphics.Bitmap;

/**
 * Created by Ursulescu on 11.03.2015.
 */
public class User {

    private int id;
    private String name;
    private String description;
    private String encodedProfilePhoto;
    private int photoOrientation;

    public User() {}

    public User(int userId, String userName, String userDesc, String profilePic, int orientation) {
        this.id = userId;
        this.name = userName;
        this.description = userDesc;
        this.encodedProfilePhoto = profilePic;
        this.photoOrientation = orientation;
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public String getProfilePhoto() {
        return this.encodedProfilePhoto;
    }

    public int getPhotoOrientation() {
        return this.photoOrientation;
    }

    public void setId(int userId) {
        this.id = userId;
    }

    public void setName(String userName) {
        this.name = userName;
    }

    public void setDescription(String userDescription) {
        this.description = userDescription;
    }

    public void setProfilePhoto(String userProfilePhoto) {
        this.encodedProfilePhoto = userProfilePhoto;
    }

    public void setPhotoOrientation(int orientation) {
        this.photoOrientation = orientation;
    }
}