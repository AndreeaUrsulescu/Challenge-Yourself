package com.challengeyourself.ursulescu.networkTasks;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.adapters.NewsFeedAdapter;
import com.challengeyourself.ursulescu.utils.ImageUtils;

/**
 * Created by Ursulescu on 05.06.2015.
 */
public class SetNewsFeedImagesTask extends AsyncTask<Object, Void, Object[]> {
    @Override
    protected Object[] doInBackground(Object... params) {

        NewsFeedAdapter.ViewHolder viewHolder = (NewsFeedAdapter.ViewHolder) params[0];
        String encodedUserPhoto = (String) params[1];
        int userPhotoOrientation = (int) params[2];
        String encodedChallengePhoto = (String) params[3];
        int chalangePhotoOrientation = (int) params[4];

        Bitmap challengePhotoBitmap = null;
        Bitmap userPhotoBitmap = null;

        if (encodedUserPhoto.compareTo("Default profile picture") == 0) {
            userPhotoBitmap = null;
        } else {
            userPhotoBitmap = ImageUtils.decodeBase64Image(encodedUserPhoto);
        }
        challengePhotoBitmap = ImageUtils.decodeBase64Image(encodedChallengePhoto);

        return new Object[]{viewHolder, userPhotoBitmap, userPhotoOrientation,
                challengePhotoBitmap, chalangePhotoOrientation, params[5]};
    }

    @Override
    protected void onPostExecute(Object[] result) {
        NewsFeedAdapter.ViewHolder viewHolder = (NewsFeedAdapter.ViewHolder) result[0];
        Bitmap userPhotoBitmap = (Bitmap) result[1];
        int userPhotoOrientation = (int) result[2];
        Bitmap challengePhotoBitmap = (Bitmap) result[3];
        int challengePhotoOrientation = (int) result[4];

        if (viewHolder.position == (int) result[5]) {
            if (userPhotoBitmap != null) {
                viewHolder.feedUserPhoto.setImageBitmap(userPhotoBitmap);
                ImageUtils.rotateImageViewByOrientation(viewHolder.feedUserPhoto, userPhotoOrientation);
            } else {
                viewHolder.feedUserPhoto.setImageResource(R.drawable.anonymous_user);
            }
            viewHolder.feedPhoto.setImageBitmap(challengePhotoBitmap);

            ImageUtils.rotateImageViewByOrientation(viewHolder.feedPhoto, challengePhotoOrientation);
        }
    }
}
