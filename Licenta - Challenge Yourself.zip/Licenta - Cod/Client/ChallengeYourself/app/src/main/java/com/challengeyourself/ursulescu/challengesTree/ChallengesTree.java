package com.challengeyourself.ursulescu.challengesTree;

import java.util.List;

/**
 * Created by Ursulescu on 23.03.2015.
 */
public class ChallengesTree {

    private int challengeId;
    private List<ChallengesTree> descendants;

    public int getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(int challengeId) {
        this.challengeId = challengeId;
    }

    public List<ChallengesTree> getDescendants() {
        return descendants;
    }

    public void setDescendants(List<ChallengesTree> descendants) {
        this.descendants = descendants;
    }
}
