package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.FeedActivity;
import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.NewsFeedItem;
import com.challengeyourself.ursulescu.networkTasks.SetNewsFeedImagesTask;
import com.challengeyourself.ursulescu.networkTasks.VoteChallengeTask;
import com.challengeyourself.ursulescu.utils.TimeUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Ursulescu on 05.06.2015.
 */
public class NewsFeedAdapter extends BaseAdapter {

    private List<NewsFeedItem> newsFeedItems = new ArrayList<>();
    private Context context;
    private FeedActivity feedActivity;
    private String userToken;
    private Typeface rosemaryFont;

    public NewsFeedAdapter(Context context, FeedActivity feedActivity, String userToken) {
        this.context = context;
        this.feedActivity = feedActivity;
        this.userToken = userToken;
        rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
    }

    @Override
    public int getCount() {
        return newsFeedItems.size();
    }

    @Override
    public Object getItem(int position) {
        return newsFeedItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void addMoreItems(List<NewsFeedItem> newItems) {
        newsFeedItems.addAll(newItems);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.news_feed_item, null);

            viewHolder = new ViewHolder();
            viewHolder.approveButton = (Button) convertView.findViewById(R.id.approve_button);
            viewHolder.commentsButton = (Button) convertView.findViewById(R.id.feed_comments_button);
            viewHolder.feedChallengeDescription = (TextView) convertView.findViewById(R.id.feed_challenge_desc);
            viewHolder.feedChallengeIcon = (ImageView) convertView.findViewById(R.id.feed_challenge_icon);
            viewHolder.feedChallengeName = (TextView) convertView.findViewById(R.id.feed_challenge_name);
            viewHolder.feedPhoto = (ImageView) convertView.findViewById(R.id.feed_photo);
            viewHolder.feedUpdateDate = (TextView) convertView.findViewById(R.id.feed_time);
            viewHolder.feedUsername = (TextView) convertView.findViewById(R.id.feed_username);
            viewHolder.feedUserPhoto = (CircularImage) convertView.findViewById(R.id.feed_user_photo);
            viewHolder.votesButton = (Button) convertView.findViewById(R.id.feed_votes_button);

            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.feedChallengeDescription.setText(newsFeedItems.get(position).getChallengeDescription());
        viewHolder.feedChallengeName.setText(newsFeedItems.get(position).getChallengeName());
        viewHolder.feedUsername.setText(newsFeedItems.get(position).getUserName());
        viewHolder.votesButton.setText(newsFeedItems.get(position).getNumberOfVotes() + " Votes");
        viewHolder.votesButton.setTag(position);
        viewHolder.commentsButton.setTag(position);
        setPassedTime(viewHolder, position);
        setButtonsColorAndChallengeIcon(viewHolder, position);
        setFont(viewHolder);
        setButtonsOnClickListener(viewHolder, position);

        viewHolder.position = position;

        if (!newsFeedItems.get(position).getCanBeVotted()) {
//            LinearLayout approveButtonLayout = (LinearLayout) viewHolder.approveButton.getParent();
//            approveButtonLayout.removeView(viewHolder.approveButton);
            viewHolder.approveButton.setEnabled(false);
            viewHolder.approveButton.setBackgroundColor(Color.LTGRAY);
        } else {
            viewHolder.approveButton.setEnabled(true);
        }

        new SetNewsFeedImagesTask().execute(viewHolder, newsFeedItems.get(position).getUserPhoto(),
                newsFeedItems.get(position).getUserPhotoOrientation(),
                newsFeedItems.get(position).getChallengePhoto(), newsFeedItems.get(position).getChallengePhotoOrietation(), position);

        return convertView;
    }

    public static class ViewHolder {
        public ImageView feedPhoto;
        public CircularImage feedUserPhoto;
        public TextView feedUsername;
        public TextView feedUpdateDate;
        public ImageView feedChallengeIcon;
        public TextView feedChallengeName;
        public TextView feedChallengeDescription;
        public Button approveButton;
        public Button votesButton;
        public Button commentsButton;
        public int position;
    }

    private void setFont(ViewHolder viewHolder) {
        viewHolder.feedUsername.setTypeface(rosemaryFont);
        viewHolder.feedUpdateDate.setTypeface(rosemaryFont);
        viewHolder.feedChallengeName.setTypeface(rosemaryFont);
        viewHolder.feedChallengeDescription.setTypeface(rosemaryFont);
        viewHolder.approveButton.setTypeface(rosemaryFont);
        viewHolder.commentsButton.setTypeface(rosemaryFont);
        viewHolder.votesButton.setTypeface(rosemaryFont);
    }

    private void setButtonsColorAndChallengeIcon(ViewHolder viewHolder, int position) {
        switch(newsFeedItems.get(position).getChallengeType()) {
            case "friendship":
                viewHolder.feedChallengeIcon.setImageResource(R.drawable.inf128);
                viewHolder.votesButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                viewHolder.commentsButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                viewHolder.approveButton.setBackgroundResource(R.drawable.friendship_challenges_button_selector);
                break;
            case "culture":
                viewHolder.feedChallengeIcon.setImageResource(R.drawable.book128);
                viewHolder.votesButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                viewHolder.commentsButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                viewHolder.approveButton.setBackgroundResource(R.drawable.culture_challenges_button_selector);
                break;
            case "kitchen":
                viewHolder.feedChallengeIcon.setImageResource(R.drawable.cake128);
                viewHolder.votesButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                viewHolder.commentsButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                viewHolder.approveButton.setBackgroundResource(R.drawable.kitchen_challenges_button_selector);
                break;
            case "entertainment":
                viewHolder.feedChallengeIcon.setImageResource(R.drawable.dj128);
                viewHolder.votesButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
                viewHolder.commentsButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
                viewHolder.approveButton.setBackgroundResource(R.drawable.entertainment_challenges_button_selector);
        }
    }

    private void setPassedTime(ViewHolder viewHolder, int position){
        Date currentDate = new Date();
        viewHolder.feedUpdateDate.setText(TimeUtils.getPassedTime(newsFeedItems.get(position).getUpdateDate(), currentDate));
    }

    private void setButtonsOnClickListener(final ViewHolder viewHolder, final int position) {
        viewHolder.votesButton.setOnClickListener(feedActivity);
        viewHolder.commentsButton.setOnClickListener(feedActivity);
        viewHolder.approveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  LinearLayout approveButtonLayout = (LinearLayout) v.getParent();
               // approveButtonLayout.removeView(v);
                viewHolder.approveButton.setEnabled(false);
                viewHolder.approveButton.setBackgroundColor(Color.LTGRAY);
                viewHolder.votesButton.setText((newsFeedItems.get(position).getNumberOfVotes() + 1) + " Votes");
                new VoteChallengeTask(feedActivity).execute(newsFeedItems.get(position).getChallengeId(),
                        newsFeedItems.get(position).getUserId(), userToken);
            }
        });
    }
}
