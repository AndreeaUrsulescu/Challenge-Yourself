package com.challengeyourself.ursulescu.utils;

import android.util.Patterns;

/**
 * Created by Ursulescu on 27.02.2015.
 */
public class UserValidation {
    public static boolean fieldHasCorrectForm(String fieldValue, String regex) {
        return fieldValue.matches(regex);
    }

    public static boolean isValidEmail(String email) {
        if (email.length() <= 0) {
            return false;
        } else {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
    }

    public static boolean fieldHasValidNumberOfCharacters(String fieldValue, int minLength, int maxLength) {
        if (minLength != -1) {
            if (fieldValue.length() < minLength) {
                return false;
            }
        }

        if (maxLength != -1) {
            if (fieldValue.length() > maxLength) {
                return false;
            }
        }
        return true;
    }

    public static boolean verifyFields(String name, String email, String password, String passwordConfirmation,
                                 String description) {
        if (!fieldHasValidNumberOfCharacters(name, 3, 30) || !fieldHasCorrectForm(name, "^[A-Za-z ]*$")) {
            return false;
        }

        if (!isValidEmail(email)) {
            return false;
        }

        if (!fieldHasValidNumberOfCharacters(password, 8, 20) || !fieldHasCorrectForm(password, "^[A-Za-z0-9]*$")) {
            return false;
        }

        if (password.compareTo(passwordConfirmation) != 0) {
            return false;
        }

        if (!fieldHasValidNumberOfCharacters(description, -1, 255)) {
            return false;
        }

        return true;
    }
}
