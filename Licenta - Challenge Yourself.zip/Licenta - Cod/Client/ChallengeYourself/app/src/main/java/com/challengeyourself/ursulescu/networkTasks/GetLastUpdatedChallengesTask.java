package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 12.06.2015.
 */
public class GetLastUpdatedChallengesTask extends AsyncTask<Object, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public GetLastUpdatedChallengesTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(Object... params) {
        Map<String, Object> result;

        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;

        String url = "http://192.168.137.1:8080/challenge-yourself/api/profile/challenges?fromIndex="
                + params[0] + "&numberOfItems=" + params[1];

        if ((int) params[3] != -1) {
            url = url + "&userId=" + params[3];
        }

        HttpGet httpGet = new HttpGet(url);
        httpGet.addHeader("X-Auth-Token", (String) params[2]);

        try {
            httpResponse = httpClient.execute(httpGet);
            result = NetworkUtils.getInfoFromHttpResponse(httpResponse);
            result.put("service", "lastUpdatedChallenges");
            result.put("statusCode", httpResponse.getStatusLine().getStatusCode());

            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
