package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.adapters.PeopleList;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.FollowTask;
import com.challengeyourself.ursulescu.networkTasks.PeopleTask;
import com.challengeyourself.ursulescu.networkTasks.SearchUserTask;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 03.03.2015.
 */
public class PeopleActivity extends NavigationDrawerActivity implements AsyncTaskResultProcessing, ListView.OnScrollListener {

    private EditText searchField;
    InputMethodManager inputMethodManager;

    private int itemsCountUntilAutoload = 2;
    private int maximumNumberOfItems = 60;

    private boolean loading = false;
    private boolean moreDataAvailable = true;

    PeopleList peopleListAdapter;
    private String userToken;
    ListView peopleList;

    private DrawerLayout drawerLayout;
    private ImageView openDrawerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.main_container);
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View homeActivityView = layoutInflater.inflate(R.layout.activity_people, null);
        frameLayout.addView(homeActivityView);

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        openDrawerButton = (ImageView) findViewById(R.id.open_drawer_button);

        openDrawerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(Gravity.START);
            }
        });

        setFont();

        peopleList = (ListView) findViewById(R.id.people_container);
        peopleListAdapter = new PeopleList(this);
        peopleList.setAdapter(peopleListAdapter);

        searchField = (EditText) findViewById(R.id.search_field);
        inputMethodManager = (InputMethodManager)getSystemService(
                Context.INPUT_METHOD_SERVICE);

        peopleList.setScrollingCacheEnabled(false);

        userToken = getUserToken();

        peopleList.setOnScrollListener(this);

        if (userToken == null) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        } else {
            loading = true;
            new PeopleTask(this).execute(0, 10, userToken);
        }
    }

    private void setFont() {
        EditText searchBox = (EditText) findViewById(R.id.search_field);
        Typeface rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        searchBox.setTypeface(rosemaryFont);
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!loading && moreDataAvailable) {

            if ((totalItemCount >= maximumNumberOfItems)) {
                moreDataAvailable = false;
                //remove footer
            } else if (totalItemCount - itemsCountUntilAutoload <=
                    firstVisibleItem + visibleItemCount) {
                loading = true;

                if (searchField.getText().toString().length() == 0) {
                    new PeopleTask(PeopleActivity.this).execute(totalItemCount, 10, userToken);
                } else {
                    new SearchUserTask(PeopleActivity.this).execute(totalItemCount, 10,
                            userToken, searchField.getText().toString());
                }
            }
        }
    }

    private String getUserToken() {
        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        String encryptedToken = sharedPreferences.getString("loginToken", "none");

        if (encryptedToken.compareTo("none") != 0) {
            SecretKey privateKey = SecurityUtils.getPrivateKey(getApplicationContext());
            return SecurityUtils.decryptToken(encryptedToken, privateKey);
        }
        return null;
    }

    public void follow(View button) {
        button.setVisibility(View.GONE);
        new FollowTask(this).execute(button.getId(), userToken);
    }

    public void searchUser(View button) {
        String searchedUser = searchField.getText().toString();

        inputMethodManager.hideSoftInputFromWindow(searchField.getWindowToken(), 0);

        moreDataAvailable = true;
        peopleListAdapter.users.removeAll(peopleListAdapter.users);
        loading = true;

        if (searchedUser.length() > 0) {
            new SearchUserTask(this).execute(0, 10, userToken, searchedUser);
        } else {
            new PeopleTask(this).execute(0, 10, userToken);
        }
    }

    private void processFollowFriendResult(Map<String, Object> serverResponse) {

        if ((int) serverResponse.get("statusCode") == 200) {
            if ((boolean)serverResponse.get("success")) {
                Toast.makeText(this, "Your request have been submitted!", Toast.LENGTH_LONG).show();
            }

        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

        private void processGetPeopleResult(Map<String, Object> serverResponse) {
        loading = false;

        if ((int) serverResponse.get("statusCode") == 200) {

            if ((boolean) serverResponse.get("existsUsers")) {

                ArrayList<User> users = NetworkUtils.getUsersFromArrayOfHashMaps(
                        (ArrayList<HashMap<String, Object>>) serverResponse.get("users"));
                peopleListAdapter.addMoreItems(users);
                peopleListAdapter.notifyDataSetChanged();

                if (users.size() < 10) {
                    moreDataAvailable = false;
                }
            } else {
                moreDataAvailable = false;
            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(this, MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if (((String) serverResponse.get("service")).compareTo("getPeople") == 0 ||
                ((String)serverResponse.get("service")).compareTo("searchUsers") == 0 ) {
            processGetPeopleResult(serverResponse);
        } else if (((String)serverResponse.get("service")).compareTo("follow") == 0) {
            processFollowFriendResult(serverResponse);
        }
    }
}
