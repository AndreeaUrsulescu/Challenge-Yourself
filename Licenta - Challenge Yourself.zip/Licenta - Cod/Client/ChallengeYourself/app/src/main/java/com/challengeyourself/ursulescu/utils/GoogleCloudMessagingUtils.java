package com.challengeyourself.ursulescu.utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;

/**
 * Created by Ursulescu on 18.06.2015.
 */
public class GoogleCloudMessagingUtils {

    public static boolean deviceSupportsGooglePlayServices(Activity activity) {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(activity.getApplicationContext());

        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, activity, 9000).show();
            } else {
                Toast.makeText(
                        activity.getApplicationContext(),
                        "This device doesn't support Play services, so notifications will not work normally",
                        Toast.LENGTH_LONG).show();
                activity.finish();
            }
            return false;
        } else {
            Toast.makeText(
                    activity.getApplicationContext(),
                    "This device supports Play services, App will work normally",
                    Toast.LENGTH_LONG).show();
        }
        return true;
    }
}
