package com.challengeyourself.ursulescu.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.networkTasks.LoginTask;
import com.challengeyourself.ursulescu.networkTasks.LogoutTask;
import com.challengeyourself.ursulescu.networkTasks.RegisterDeviceOnGCMServerTask;
import com.challengeyourself.ursulescu.utils.GoogleCloudMessagingUtils;
import com.challengeyourself.ursulescu.utils.SecurityUtils;

import org.apache.http.HttpStatus;

import java.util.Map;

import javax.crypto.SecretKey;

/**
 * Created by Ursulescu on 18.02.2015.
 */
public class LoginActivity extends Activity implements AsyncTaskResultProcessing{

    private TextView emailView;
    private TextView passwordView;
    private Typeface rosemaryFont, alwaysFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }

    private void init() {
        rosemaryFont = Typeface.createFromAsset(getAssets(), "fonts/Rosemary.ttf");
        alwaysFont = Typeface.createFromAsset(getAssets(), "fonts/always.ttf");
        emailView = (TextView) findViewById(R.id.login_email);
        passwordView = (TextView) findViewById(R.id.login_password);
        Button loginButton = (Button) findViewById(R.id.login_button);

        emailView.setTypeface(rosemaryFont);
        passwordView.setTypeface(rosemaryFont);
        loginButton.setTypeface(rosemaryFont);
    }

    public void login(View button) {
        String userEmail = emailView.getText().toString();
        String userPassword = passwordView.getText().toString();

        if ((userEmail.length() > 0) && (userPassword.length() > 0)) {
            registerDeviceOnGcmServer();
        } else {
            Toast.makeText(getApplicationContext(), "Complete email and password fields!", Toast.LENGTH_LONG).show();
        }
    }

    private void registerDeviceOnGcmServer() {
        String regId = getRegistrationId();

        if (regId.compareTo("none") == 0) {
            if (GoogleCloudMessagingUtils.deviceSupportsGooglePlayServices(this)) {
                new RegisterDeviceOnGCMServerTask(this).execute(getApplicationContext());
            }
        } else {
            String userEmail = emailView.getText().toString();
            String userPassword = passwordView.getText().toString();
            new LoginTask(this).execute(userEmail, userPassword, regId);
        }
    }

    private String getRegistrationId() {
        SharedPreferences sharedPreferences = getSharedPreferences("DeviceInfo", Context.MODE_PRIVATE);
        String regId = sharedPreferences.getString("deviceRegistrationId", "none");

        return regId;
    }

    private void saveEncryptedToken(String token) {
        SecretKey secretKey = SecurityUtils.generateKey();
        SecurityUtils.savePrivateKey(secretKey, this.getApplicationContext());
        String encryptedToken = SecurityUtils.encryptToken(token, secretKey);

        SharedPreferences sharedPreferences = getSharedPreferences("tokens", 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("loginToken", encryptedToken);
        editor.commit();
    }

    private void saveRegistrationIdInSharedPreferences(String registrationId) {
        SharedPreferences sharedPreferences = getSharedPreferences("DeviceInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("deviceRegistrationId", registrationId);
        editor.commit();
    }

    @Override
    public void processResult(Object[] result) {

        if (result[1] instanceof Integer) {
            int statusCode = (int) result[1];
            if (statusCode == 200) {
                //encrypt and save token
                saveEncryptedToken((String) result[0]);

                Intent homeIntent = new Intent(this, HomeActivity.class);
                startActivity(homeIntent);
            } else {
                Toast.makeText(getApplicationContext(), "Wrong email or password!", Toast.LENGTH_LONG).show();
            }
        } else {
            String registrationId = (String) result[0];
            if (!registrationId.isEmpty()) {
                String userEmail = emailView.getText().toString();
                String userPassword = passwordView.getText().toString();

                saveRegistrationIdInSharedPreferences(registrationId);
                Toast.makeText(getApplicationContext(),
                        "Registered with GCM Server successfully", Toast.LENGTH_SHORT).show();
                new LoginTask(this).execute(userEmail, userPassword, registrationId);
            } else {
                Toast.makeText(
                        getApplicationContext(), "Reg ID Creation Failed", Toast.LENGTH_LONG).show();
            }
        }
    }
}
