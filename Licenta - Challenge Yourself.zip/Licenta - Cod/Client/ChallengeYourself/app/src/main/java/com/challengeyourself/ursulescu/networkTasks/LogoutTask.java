package com.challengeyourself.ursulescu.networkTasks;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import com.challengeyourself.ursulescu.activities.MainActivity;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;

/**
 * Created by Ursulescu on 04.03.2015.
 */
public class LogoutTask extends AsyncTask<String, Void, Integer> {

    private Activity callingActivity;

    public LogoutTask(Activity activity) {
        this.callingActivity = activity;
    }

    @Override
    protected Integer doInBackground(String... params) {
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;
        int responseStatus = -1;

        HttpGet httpGet = new HttpGet("http://192.168.137.1:8080/challenge-yourself/api/logout");
        httpGet.addHeader("X-Auth-Token", params[0]);
        try {
            httpResponse = httpClient.execute(httpGet);
            responseStatus = httpResponse.getStatusLine().getStatusCode();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return responseStatus;
    }

    protected void onPostExecute(Integer responseStatus) {
        if (responseStatus.intValue() == 200) {
            Intent mainActivityIntent = new Intent(this.callingActivity, MainActivity.class);
            callingActivity.startActivity(mainActivityIntent);
        } else {
            Toast.makeText(callingActivity.getApplicationContext(), "Unsuccessful logout!", Toast.LENGTH_LONG).show();
        }
    }
}
