package com.challengeyourself.ursulescu.networkTasks;

import android.os.AsyncTask;

import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.utils.NetworkUtils;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Ursulescu on 11.06.2015.
 */
public class GetProfileInfoTask extends AsyncTask<String, Void, Map<String, Object>> {

    private AsyncTaskResultProcessing listener;

    public GetProfileInfoTask(AsyncTaskResultProcessing listener) {
        this.listener = listener;
    }

    @Override
    protected Map<String, Object> doInBackground(String... params) {
        Map<String, Object> result;
        HttpClient httpClient = new DefaultHttpClient();
        HttpResponse httpResponse;

        String url = "http://192.168.137.1:8080/challenge-yourself/api/profile/info";

        if (Integer.parseInt(params[1]) != -1) {
            url = url + "?userId=" + params[1];
        } else {
            url = url + "/";
        }
        HttpGet httpGet = new HttpGet(url);
        httpGet.addHeader("X-Auth-Token", (String) params[0]);

        try {
            httpResponse = httpClient.execute(httpGet);
            result = NetworkUtils.getInfoFromHttpResponse(httpResponse);
            result.put("service", "getMyProfileInfo");
            result.put("statusCode", httpResponse.getStatusLine().getStatusCode());

            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Map<String,Object> serverResponse) {
        listener.processResult(new Object[]{serverResponse});
    }
}
