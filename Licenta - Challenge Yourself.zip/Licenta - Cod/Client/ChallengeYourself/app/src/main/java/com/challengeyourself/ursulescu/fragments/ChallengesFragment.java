package com.challengeyourself.ursulescu.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Toast;

import com.challengeyourself.ursulescu.activities.MainActivity;
import com.challengeyourself.ursulescu.activities.MyProfileActivity;
import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.activities.UserPostActivity;
import com.challengeyourself.ursulescu.adapters.GridViewAdapter;
import com.challengeyourself.ursulescu.communicationInterfaces.AsyncTaskResultProcessing;
import com.challengeyourself.ursulescu.items.UserChallenge;
import com.challengeyourself.ursulescu.items.UserChallengeStorage;
import com.challengeyourself.ursulescu.networkTasks.GetLastUpdatedChallengesTask;
import com.challengeyourself.ursulescu.utils.NetworkUtils;
import com.etsy.android.grid.StaggeredGridView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ursulescu on 10.06.2015.
 */
public class ChallengesFragment extends Fragment implements AsyncTaskResultProcessing, AbsListView.OnScrollListener {

    private StaggeredGridView challengesPicturesGridView;
    private GridViewAdapter gridViewAdapter;
    private ArrayList<UserChallenge> gridData = new ArrayList<>();

    private int itemsCountUntilAutoload = 2;
    private int numberOfItemsPerPage = 6;
    private boolean loading = false;
    private boolean moreDataAvailable = true;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.challenges_fragment, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(final Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        challengesPicturesGridView = (StaggeredGridView) getView().findViewById(R.id.gridView);
        gridViewAdapter = new GridViewAdapter(getActivity(), android.R.layout.simple_list_item_1, gridData);
        challengesPicturesGridView.setScrollingCacheEnabled(false);
        challengesPicturesGridView.setAdapter(gridViewAdapter);
        challengesPicturesGridView.setOnScrollListener(this);
        challengesPicturesGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UserChallengeStorage.setUserChallenge(gridViewAdapter.getItem(position));
                Intent userPostIntent = new Intent(getActivity(), UserPostActivity.class);
                userPostIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(userPostIntent);
            }
        });

        loading = true;
        new GetLastUpdatedChallengesTask(this).execute(0, numberOfItemsPerPage,
                ((MyProfileActivity)getActivity()).userToken, UserChallengeStorage.getUserId());
    }

    private void addData(ArrayList<UserChallenge> data) {
        if (data != null && data.size() > 0) {
            for (UserChallenge challenge : data) {
                gridViewAdapter.add(challenge);
            }
            gridViewAdapter.notifyDataSetChanged();
        }
        if (data.size() < numberOfItemsPerPage) {
            moreDataAvailable = false;
        }
    }

    @Override
    public void processResult(Object[] result) {
        Map<String, Object> serverResponse = (Map<String, Object>) result[0];

        if ((int)serverResponse.get("statusCode") == 200) {
            if (((String)serverResponse.get("service")).compareTo("lastUpdatedChallenges") == 0) {
                loading = false;
                addData(NetworkUtils.getUserChallengesFromArrayOfHaspMaps(
                        (ArrayList<HashMap<String, Object>>) serverResponse.get("challenges")));
            }
        } else if ((int) serverResponse.get("statusCode") == 401) {
            Intent mainActivityIntent = new Intent(getActivity(), MainActivity.class);
            startActivity(mainActivityIntent);
        }
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {}

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (!loading && moreDataAvailable) {
            if (totalItemCount - itemsCountUntilAutoload <=
                    firstVisibleItem + visibleItemCount) {
                loading = true;
                new GetLastUpdatedChallengesTask(this).execute(totalItemCount, numberOfItemsPerPage,
                        ((MyProfileActivity)getActivity()).userToken, UserChallengeStorage.getUserId());
            }
        }
    }
}
