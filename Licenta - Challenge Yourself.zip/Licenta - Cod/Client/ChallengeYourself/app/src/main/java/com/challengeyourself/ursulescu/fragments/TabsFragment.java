package com.challengeyourself.ursulescu.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.items.TabDefinition;

/**
 * Created by Ursulescu on 10.06.2015.
 */
public class TabsFragment extends Fragment implements TabHost.OnTabChangeListener  {

    private final TabDefinition[] TAB_DEFINITIONS = new TabDefinition[] {
            new TabDefinition(R.id.chart_tab, "Challenges Chart", R.id.tabTitle, R.layout.custom_tab, new ChartFragment()),
            new TabDefinition(R.id.challenges_tab, "Challenges", R.id.tabTitle, R.layout.custom_tab, new ChallengesFragment()),
            new TabDefinition(R.id.friends_tab, "Friends", R.id.tabTitle, R.layout.custom_tab, new FriendsFragment()) };

    private View rootView;
    private TabHost tabHost;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.tabs_fragment, null);
        tabHost = (TabHost) rootView.findViewById(android.R.id.tabhost);
        tabHost.setup();

        for (TabDefinition tab : TAB_DEFINITIONS) {
            tabHost.addTab(createTab(inflater, tab));
        }

        return rootView;
    }

    private TabHost.TabSpec createTab(LayoutInflater inflater, TabDefinition tabDefinition) {
        ViewGroup tabsView = (ViewGroup) rootView.findViewById(android.R.id.tabs);
        View tabView = tabDefinition.createView(inflater, tabsView);

        TabHost.TabSpec tabSpec = tabHost.newTabSpec(tabDefinition.getTabUuid());
        tabSpec.setIndicator(tabView);
        tabSpec.setContent(tabDefinition.getTabContentViewId());
        return tabSpec;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setRetainInstance(true);
        tabHost.setOnTabChangedListener(this);
        if (TAB_DEFINITIONS.length > 0) {
            onTabChanged(TAB_DEFINITIONS[0].getTabUuid());
        }
    }

    @Override
    public void onTabChanged(String tabId) {
        for (TabDefinition tab : TAB_DEFINITIONS) {
            if (tabId != tab.getTabUuid()) {
                continue;
            }

            android.support.v4.app.FragmentManager fragmentManager = getFragmentManager();
            if (fragmentManager.findFragmentByTag(tabId) == null) {
                fragmentManager.beginTransaction()
                        .replace(tab.getTabContentViewId(), tab.getFragment(), tabId).commit();
            }
        }
    }
}
