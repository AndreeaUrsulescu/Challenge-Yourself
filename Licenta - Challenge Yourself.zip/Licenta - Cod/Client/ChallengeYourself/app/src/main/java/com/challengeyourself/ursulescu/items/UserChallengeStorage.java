package com.challengeyourself.ursulescu.items;

/**
 * Created by Ursulescu on 28.05.2015.
 */
public class UserChallengeStorage {
    private static UserChallenge userChallenge;

    private static int userId;

    public static int userChallengeId;

    public static UserChallenge getUserChallenge() {
        return userChallenge;
    }

    public static void setUserChallenge(UserChallenge challenge) {
        userChallenge = challenge;
    }

    public static int getUserId() {
        return userId;
    }

    public static void setUserId(int userId) {
        UserChallengeStorage.userId = userId;
    }
}
