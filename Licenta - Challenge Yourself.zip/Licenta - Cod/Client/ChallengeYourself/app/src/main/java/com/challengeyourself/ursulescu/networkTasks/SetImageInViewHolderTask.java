package com.challengeyourself.ursulescu.networkTasks;

import android.graphics.Bitmap;
import android.os.AsyncTask;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.adapters.PeopleList;
import com.challengeyourself.ursulescu.utils.ImageUtils;


/**
* Created by Ursulescu on 21.03.2015.
*/
public class SetImageInViewHolderTask extends AsyncTask<Object, Void, Object[]> {
    @Override
    protected Object[] doInBackground(Object... params) {

        PeopleList.ViewHolder viewHolder = (PeopleList.ViewHolder) params[0];
        String encodedImage = (String) params[1];
        int photoOrientation = (int) params[2];

        Bitmap imageBitmap = null;

        if (encodedImage.compareTo("Default profile picture") == 0) {
            imageBitmap = null;
        } else {
            imageBitmap = ImageUtils.decodeBase64Image(encodedImage);
        }

        return new Object[] {viewHolder, imageBitmap, photoOrientation, params[3]};
    }

    @Override
    protected void onPostExecute(Object[] result) {
        PeopleList.ViewHolder viewHolder = (PeopleList.ViewHolder) result[0];
        Bitmap imageBitmap = (Bitmap) result[1];
        int photoOrientation = (int) result[2];

        if (imageBitmap != null && (int)result[3] == viewHolder.position) {
            viewHolder.profilePic.setImageBitmap(imageBitmap);
            ImageUtils.rotateImageViewByOrientation(viewHolder.profilePic, photoOrientation);
        }
    }
}
