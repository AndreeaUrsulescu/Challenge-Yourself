package com.challengeyourself.ursulescu.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.challengeyourself.ursulescu.activities.R;
import com.challengeyourself.ursulescu.customizedViews.CircularImage;
import com.challengeyourself.ursulescu.items.User;
import com.challengeyourself.ursulescu.networkTasks.SetFriendImageTask;
import com.challengeyourself.ursulescu.networkTasks.SetImageInViewHolderTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ursulescu on 13.06.2015.
 */
public class FriendsAdapter extends BaseAdapter {

    private List<User> friends = new ArrayList<>();
    private Context context;

    public FriendsAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return friends.size();
    }

    @Override
    public Object getItem(int position) {
        return friends.get(position);
    }

    @Override
    public long getItemId(int position) {
        return friends.get(position).getId();
    }

    public void addMoreItems(List<User> newfriends) {
        friends.addAll(newfriends);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.friends_list_item, null);

            viewHolder = new ViewHolder();
            viewHolder.friendName = (TextView) convertView.findViewById(R.id.friend_name);
            viewHolder.friendDescription = (TextView) convertView.findViewById(R.id.friend_description);
            viewHolder.friendPhoto = (CircularImage) convertView.findViewById(R.id.friend_photo);

            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.friendName.setText(friends.get(position).getName());
        viewHolder.friendDescription.setText(friends.get(position).getDescription());
        setFont(viewHolder);
        viewHolder.position = position;

        new SetFriendImageTask().execute(viewHolder, friends.get(position).getProfilePhoto(),
                friends.get(position).getPhotoOrientation(), position);

        return convertView;
    }

    public static class ViewHolder {
        public TextView friendName;
        public TextView friendDescription;
        public CircularImage friendPhoto;
        public int position;
    }

    private void setFont(ViewHolder viewHolder) {
        Typeface rosemaryFont = Typeface.createFromAsset(context.getAssets(), "fonts/Rosemary.ttf");
        viewHolder.friendName.setTypeface(rosemaryFont);
        viewHolder.friendDescription.setTypeface(rosemaryFont);
    }
}
