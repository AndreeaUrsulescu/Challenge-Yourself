/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.controller;
 
import challengeyourself.entity.User;
import challengeyourself.service.NewsFeedService;
import challengeyourself.service.NotificationService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Ursulescu
 */
@Controller
public class NewsFeedController {
    
    @Autowired
    private NewsFeedService newsFeedService;
    
    @Autowired
    private NotificationService notificationService;
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/newsFeed")
    @ResponseBody
    public Map<String, Object> getNews(@RequestParam("firstIndex") int firstIndex,
            @RequestParam("numberOfItems") int numberOfItems) {
        Map<String, Object> response = new HashMap<>();
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        //notificationService.sendNotificationForPassingChallenge(authenticatedUser.getId(), 1l);
        
        response.put("newsFeed", newsFeedService.getNewsFeedInARange(
                firstIndex, numberOfItems, authenticatedUser.getEmail()));
        
        return response;
    }
}
