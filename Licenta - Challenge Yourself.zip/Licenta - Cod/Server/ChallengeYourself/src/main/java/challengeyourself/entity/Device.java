/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Ursulescu
 */
@NamedQueries({@NamedQuery(name = Device.FIND_BY_USER, query = "select d from Device d where d.userId = :userId")})

@Entity
@Table(name="devices")
public class Device implements Serializable{
    
    public static final String FIND_BY_USER = "Device.findByUser";
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name="user_id", nullable=false, unique=true)
    private Long userId;
    
    @Column(name="registration_id", nullable=false)
    private String registrationId;
    
    public Device() {}
    
    public Device(Long userId, String registrationId) {
        this.userId = userId;
        this.registrationId = registrationId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getRegistrationId() {
        return registrationId;
    }

    public void setRegistrationId(String registrationId) {
        this.registrationId = registrationId;
    }
}
