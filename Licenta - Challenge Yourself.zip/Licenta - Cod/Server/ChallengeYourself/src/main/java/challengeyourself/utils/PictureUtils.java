/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author Ursulescu
 */
public class PictureUtils {
    public static final String LOCATION = System.getProperty("catalina.home") + File.separator + "ProfilePictures";
    
    public static String savePicture(String pictureName, String encodedPicture) {
        String filePath = LOCATION + File.separator + pictureName;
        byte[] imageBytes = Base64.decodeBase64(encodedPicture);
        
        try {
            try (OutputStream os = new FileOutputStream(filePath)) {
                os.write(imageBytes);
                return filePath;
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PictureUtils.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PictureUtils.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
