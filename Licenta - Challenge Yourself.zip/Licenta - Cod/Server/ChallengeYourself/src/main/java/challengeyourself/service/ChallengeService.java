/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.challengesTree.ChallengeTreeFunctions;
import challengeyourself.dto.CommentDto;
import challengeyourself.dto.UserChallengeDto;
import challengeyourself.dto.UserDto;
import challengeyourself.entity.Challenge;
import challengeyourself.entity.Comment;
import challengeyourself.entity.User;
import challengeyourself.entity.UserChallenge;
import challengeyourself.repository.ChallengeRepository;
import challengeyourself.repository.UserRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class ChallengeService {

    @Autowired
    private ChallengeRepository challengeRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private NotificationService notificationService;

    private static final int TOTAL_NUMBER_OF_CHALLENGES_PER_CATEGORY = 22;
    
    private boolean userHasAccessToChallenge(Long userId, Long challengeId) {
        long parentId = ChallengeTreeFunctions.getParentIdForAChallenge(challengeId);

        if (parentId > 0) {
            UserChallenge userChallenge = challengeRepository.getUserChallenge(userId, parentId);

            if (userChallenge == null) {
                return false;
            }

            if (userChallenge.getDone().compareTo("no") == 0) {
                return false;
            }
            return true;
        } else if (parentId == 0) {
            return true;
        }

        return false;
    }

    public Map<String, Object> getChallengeInfo(Long challengeId, Long userId) {
        Map<String, Object> challengeInfo = new HashMap<>();
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userId, challengeId);

        //user has posted a picture by now
        if (userChallenge != null) {
            challengeInfo.put("access", true);
            challengeInfo.put("challengeType", "UserChallenge");
            challengeInfo.put("challenge", convertUserChallengeToDto(userChallenge));
        } else if (userHasAccessToChallenge(userId, challengeId)) {
            challengeInfo.put("access", true);
            challengeInfo.put("challengeType", "Challenge");
            challengeInfo.put("challenge", challengeRepository.getChallengeById(challengeId));
        } else {
            challengeInfo.put("access", false);
        }

        return challengeInfo;
    }

    public UserChallengeDto convertUserChallengeToDto(UserChallenge userChallenge) {
        UserChallengeDto userChallengeDto = new UserChallengeDto();
        Challenge challenge = challengeRepository.getChallengeById(userChallenge.getChallengeId());
        
        userChallengeDto.setChallengeId(userChallenge.getChallengeId());
        userChallengeDto.setDoneChallenge(userChallenge.getDone());
        userChallengeDto.setThumbnail(userChallenge.getThumbnail());
        userChallengeDto.setPicture(userChallenge.getPicture());
        userChallengeDto.setPictureOrientation(userChallenge.getPictureOrientation());
        userChallengeDto.setUpdateDate(userChallenge.getUpdateDate());
        userChallengeDto.setNumberOfVotes(userChallenge.getVotes().size());
        userChallengeDto.setChallengeName(challenge.getName());
        userChallengeDto.setChallengeDescription(challenge.getDescription());
        userChallengeDto.setChallengeType(challenge.getCategory());
        
        return userChallengeDto;
    }

    private List<UserChallengeDto> convertListOfUserChallengesToDtos(List<UserChallenge> userChallenges) {
        List<UserChallengeDto> userChallengeDtos = new ArrayList<>();

        for (UserChallenge userChallenge : userChallenges) {
            userChallengeDtos.add(convertUserChallengeToDto(userChallenge));
        }

        return userChallengeDtos;
    }

    public List<UserChallengeDto> getChallengesInCategoryForUser(String category, Long userId) {
        List<Long> challengesIds = new ArrayList<>();

        for (Challenge challenge : challengeRepository.getChallengesFromCategory(category)) {
            challengesIds.add(challenge.getId());
        }

        return convertListOfUserChallengesToDtos(challengeRepository.getDoneChallengesFromCategory(userId, challengesIds));
    }

    public UserChallenge convertUserChallengeDtoToEntity(UserChallengeDto challengeDto, Long associatedUserId) {
        UserChallenge challenge = new UserChallenge();
        challenge.setChallengeId(challengeDto.getChallengeId());
        challenge.setUserId(associatedUserId);
        challenge.setComments(new LinkedHashSet<Comment>());
        challenge.setDone(challengeDto.getDoneChallenge());
        challenge.setPicture(challengeDto.getPicture());
        challenge.setThumbnail(challengeDto.getThumbnail());
        challenge.setPictureOrientation(challengeDto.getPictureOrientation());
        challenge.setVotes(new LinkedHashSet<User>());
        challenge.setUpdateDate(new Date());
        return challenge;
    }
    
    public void postPictureForChallenge(Long userId, UserChallengeDto challengeToBeUpdated) {
        UserChallenge existentPost = challengeRepository.getUserChallenge(userId, 
                challengeToBeUpdated.getChallengeId());
        if (existentPost != null) {
            existentPost.setDone("no");
            existentPost.setPicture(challengeToBeUpdated.getPicture());
            existentPost.setThumbnail(challengeToBeUpdated.getThumbnail());
            existentPost.setPictureOrientation(challengeToBeUpdated.getPictureOrientation());
            existentPost.setComments(new LinkedHashSet<Comment>());
            existentPost.setVotes(new LinkedHashSet<User>());
            existentPost.setUpdateDate(new Date());
            challengeRepository.updateUserChallenge(existentPost);
        } else {
            UserChallenge newPost = convertUserChallengeDtoToEntity(challengeToBeUpdated, userId);
            newPost.setDone("no");
            challengeRepository.saveUserChallenge(newPost);
        }
    }
    
    private UserDto convertUserToUserDtoForVotesInformation(User user) {
        UserDto userDto = new UserDto();
        userDto.setId(user.getId());
        userDto.setName(user.getName());
        userDto.setProfilePhoto(user.getProfilePhtoto());
        userDto.setPhotoOrientation(user.getPhotoOrientation());
        return userDto;
    }
    
    public List<UserDto> getVotesForUserChallenge(Long userId, Long challengeId,
            int fromIndex, int numberOfItems) {
        UserChallenge challenge = challengeRepository.getUserChallenge(userId, challengeId);
        Object[] votesArray = challenge.getVotes().toArray();
        List<Object> searchedVotes;
        
        if (votesArray.length - fromIndex >= numberOfItems) {
            searchedVotes = Arrays.asList(votesArray)
                .subList(fromIndex, fromIndex + numberOfItems);
        } else {
            searchedVotes = Arrays.asList(votesArray)
                    .subList(fromIndex, fromIndex + votesArray.length - fromIndex);
        }
        List<UserDto> votes = new ArrayList<>();
        
        if (challenge != null) {
           for (int i = searchedVotes.size() - 1; i >= 0; i--) {
               votes.add(convertUserToUserDtoForVotesInformation((User) searchedVotes.get(i)));
           }
        }
        return votes;
    }
    
    private boolean isBetween(long number, long lower, long upper) {
        return lower <= number && number <= upper;
    }
    
    private int getMinimumNumberOfVotesForPassing(long challengeId) {
        if (isBetween(challengeId, 1, 4) || isBetween(challengeId, 23, 26) 
                || isBetween(challengeId, 45, 48) || isBetween(challengeId, 67, 70)) {
            return 10;
        } else if (isBetween(challengeId, 5, 10) || isBetween(challengeId, 27, 32) 
                || isBetween(challengeId, 49, 54) || isBetween(challengeId, 71, 76)) {
            return 20;
        } else if (isBetween(challengeId, 11, 16) || isBetween(challengeId, 33, 38) 
                || isBetween(challengeId, 55, 60) || isBetween(challengeId, 77, 82)) {
            return 40;
        } else if (isBetween(challengeId, 17, 22) || isBetween(challengeId, 39, 44) 
                || isBetween(challengeId, 61, 66) || isBetween(challengeId, 83, 88)) {
            return 80;
        }
        return 100;
    }
    
    public void addVoteToUserChallenge(Long userId, Long challengeId, Long voteOwnerId) {
        UserChallenge challengeToBeVoted = challengeRepository.getUserChallenge(userId, challengeId);
        User voteOwner = userRepository.findUserById(voteOwnerId);
        
        if (challengeToBeVoted != null) {
            if (!challengeToBeVoted.getVotes().contains(voteOwner)){
                challengeToBeVoted.getVotes().add(voteOwner);
                if (challengeToBeVoted.getVotes().size() + 1 >= getMinimumNumberOfVotesForPassing(challengeId)) {
                    challengeToBeVoted.setDone("yes");
                    notificationService.sendNotificationForPassingChallenge(userId, challengeId);
                }
                challengeRepository.updateUserChallenge(challengeToBeVoted);
            }
        }
    }
    
    public List<CommentDto> getCommentsForUserChallenge(Long challengeId, Long userId,
            int fromIndex, int numberOfItems) {
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userId, challengeId);
        
        if (userChallenge != null) {
            return convertListOfCommentsToListOfCommentDtos(userChallenge.getComments(),
                    fromIndex, numberOfItems);
        }
        return null;
    }
    
    public boolean addCommentToUserChallenge(Long challengeId, Long userId, Long commentOwnerId,
            String commentText) {
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userId, challengeId);
        User commentOwner = userRepository.findUserById(commentOwnerId);
        
        Comment comment = new Comment();
        comment.setComment(commentText);
        comment.setDate(new Date());
        comment.setCommentUser(commentOwner);
        challengeRepository.saveComment(comment);
        userChallenge.getComments().add(comment);
        userChallenge = challengeRepository.updateUserChallenge(userChallenge);
        
        if (userChallenge != null) {
            return true;
        }
        return false;
    }
    
    private List<CommentDto> convertListOfCommentsToListOfCommentDtos(Set<Comment> comments,
            int fromIndex, int numberOfItems) {
        List<CommentDto> commentDtos = new ArrayList<>();
        
        for (Comment comment : comments) {
            commentDtos.add(convertCommentToCommentDto(comment));
        }
        Collections.sort(commentDtos);
        
        if (commentDtos.size() - fromIndex >= numberOfItems) {
            return commentDtos.subList(fromIndex, fromIndex + numberOfItems);
        } else {
            return commentDtos.subList(fromIndex, fromIndex + commentDtos.size() - fromIndex);
        }
    }
    
    private CommentDto convertCommentToCommentDto(Comment comment) {
        CommentDto commentDto = new CommentDto();
        
        commentDto.setComment(comment.getComment());
        commentDto.setDate(comment.getDate());
        commentDto.setUsername(comment.getCommentUser().getName());
        commentDto.setUserPhoto(comment.getCommentUser().getProfilePhtoto());
        commentDto.setPhotoOrientation(comment.getCommentUser().getPhotoOrientation());
        commentDto.setUserId(comment.getCommentUser().getId());
        
        return commentDto;
    }
    
    private Long getNumberOfDoneChallengesInCategory(String category, Long userId) {
        List<Long> challengesIds = new ArrayList<>();

        for (Challenge challenge : challengeRepository.getChallengesFromCategory(category)) {
            challengesIds.add(challenge.getId());
        }
        return challengeRepository.getNumberOfDoneChallengesInCategory(userId, challengesIds);
    }
    
    private float getPercentOfChallenges(long number, int totalNumber) {
        return (float)(number * 100)/totalNumber;
    }
    
    public List<Float> getPercentOfDoneChallengesForEachCategory(Long userId) {
        List<Float> percentList = new ArrayList<>();
        percentList.add(getPercentOfChallenges(getNumberOfDoneChallengesInCategory("friendship", userId), 
                TOTAL_NUMBER_OF_CHALLENGES_PER_CATEGORY));
        percentList.add(getPercentOfChallenges(getNumberOfDoneChallengesInCategory("culture", userId), 
                TOTAL_NUMBER_OF_CHALLENGES_PER_CATEGORY));
        percentList.add(getPercentOfChallenges(getNumberOfDoneChallengesInCategory("kitchen", userId), 
                TOTAL_NUMBER_OF_CHALLENGES_PER_CATEGORY));
        percentList.add(getPercentOfChallenges(getNumberOfDoneChallengesInCategory("entertainment", userId), 
                TOTAL_NUMBER_OF_CHALLENGES_PER_CATEGORY));
        return percentList;
    } 
    
    public List<UserChallengeDto> getLastUpdatedChallengesForUser(Long userId, int fromIndex,
            int numberOfItems) {
        return convertListOfUserChallengesToDtos(
                challengeRepository.getLastUpdatedChallengesForUser(userId, fromIndex, numberOfItems));
    }
}
