/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.validator;

import challengeyourself.dto.UserDto;
import challengeyourself.entity.User;
import challengeyourself.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 *
 * @author Ursulescu
 */
@Service
public class UserValidator implements Validator{

    @Autowired
    private UserService userService;
    
    @Override
    public boolean supports(Class<?> clazz) {
        return User.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        UserDto userDto = (UserDto) target;
        
        if (userService.userEmailIsUsed(userDto.getEmail())) {
            errors.rejectValue("email", "UsedEmail", "This email address is already taken.");
        }
    }
    
}
