/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.controller;

import challengeyourself.entity.User;
import challengeyourself.repository.UserRepository;
import challengeyourself.service.ChallengeService;
import challengeyourself.service.UserService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Ursulescu
 */
@Controller
public class UserProfileController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ChallengeService challengeService;
    
    @Autowired
    private UserRepository userRepository;
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/profile/info")
    @ResponseBody
    public Map<String, Object> getLoggedUserInfo(
            @RequestParam(value = "userId", required = false) Long userId) {
        Map<String, Object> response = new HashMap<>();
            
        if (userId == null) {
            UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
            User authenticatedUser = (User) authentication.getPrincipal();
            
            response.put("userInfo", userService.convertUserToUserInfoDto(authenticatedUser));
            response.put("statistics", challengeService.getPercentOfDoneChallengesForEachCategory(
                    authenticatedUser.getId()));
        } else {
            User user = userRepository.findUserById(userId);
            response.put("userInfo", userService.convertUserToUserInfoDto(user));
            response.put("statistics", challengeService.getPercentOfDoneChallengesForEachCategory(
                    user.getId()));
        }
        
        return response;
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/profile/challenges")
    @ResponseBody
    public Map<String, Object> getLastChallengesInRange(@RequestParam("fromIndex") int fromIndex,
            @RequestParam("numberOfItems") int numberOfItems, 
            @RequestParam(value = "userId", required = false) Long userId) {
        Map<String, Object> response = new HashMap<>();
        Long id = userId;
        
        if (userId == null) {
            UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
            User authenticatedUser = (User) authentication.getPrincipal();
            id = authenticatedUser.getId();
        } 
        response.put("challenges", challengeService.getLastUpdatedChallengesForUser(id,
                fromIndex, numberOfItems));
        
        return response;
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/profile/friends")
    @ResponseBody
    public Map<String, Object> getFriends(@RequestParam("fromIndex") int fromIndex,
            @RequestParam("numberOfItems") int numberOfItems,
            @RequestParam(value = "userId", required = false) Long userId) {
        Map<String, Object> response = new HashMap<>();
        Long id = userId;
        
        if (userId == null) {
            UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
            User authenticatedUser = (User) authentication.getPrincipal();
            id = authenticatedUser.getId();
        }
        response.put("friends", userService.getFriendsOfUser(id, fromIndex, numberOfItems));
        return response;
    }
}
