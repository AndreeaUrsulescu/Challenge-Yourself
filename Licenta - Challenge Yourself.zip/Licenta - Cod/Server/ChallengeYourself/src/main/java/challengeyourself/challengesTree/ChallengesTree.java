/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.challengesTree;

/**
 *
 * @author Ursulescu
 */
public class ChallengesTree {
    
    private long challengeId;
    private ChallengesTree parent;

    public long getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(long challengeId) {
        this.challengeId = challengeId;
    }

    public ChallengesTree getParent() {
        return parent;
    }

    public void setParent(ChallengesTree parent) {
        this.parent = parent;
    }
}
