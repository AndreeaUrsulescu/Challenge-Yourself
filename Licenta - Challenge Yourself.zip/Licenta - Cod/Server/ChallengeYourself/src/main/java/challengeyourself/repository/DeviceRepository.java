/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.repository;

import challengeyourself.entity.Device;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ursulescu
 */
@Service
@Transactional
public class DeviceRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public void saveDevice(Device device) {
        entityManager.persist(device);
    }
    
    public void updateDevice(Device device) {
        entityManager.merge(device);
    }
    
    public void deleteDevice(Device device) {
        Device deviceToBeDeleted = entityManager.merge(device);
        entityManager.remove(deviceToBeDeleted);
    }
    
    public Device findDeviceByUser(Long userId) {
        List<Device> devices;
        TypedQuery<Device> query = entityManager.createNamedQuery(Device.FIND_BY_USER, Device.class);
        
        query.setParameter("userId", userId);
        devices = query.getResultList();
        
        if (devices.size() > 0) {
            return devices.get(0);
        } else {
            return null;
        }
    }
}
