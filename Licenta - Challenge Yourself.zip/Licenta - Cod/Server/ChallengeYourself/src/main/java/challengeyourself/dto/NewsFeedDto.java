/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

import java.util.Date;

/**
 *
 * @author Ursulescu
 */
public class NewsFeedDto {
    
    private Long userId;
    
    private String userName;
    
    private String userPhoto;
    
    private Integer userPhotoOrientation;
    
    private Long challengeId;
    
    private String challengeName;
    
    private String challengeDescription;
    
    private String challengeType;
    
    private String challengePhoto;
    
    private Integer challengePhotoOrietation;
    
    private Date updateDate;
    
    private Integer numberOfVotes;
    
    private Boolean canBeVotted;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public Integer getUserPhotoOrientation() {
        return userPhotoOrientation;
    }

    public void setUserPhotoOrientation(Integer userPhotoOrientation) {
        this.userPhotoOrientation = userPhotoOrientation;
    }

    public Long getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(Long challengeId) {
        this.challengeId = challengeId;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public String getChallengeDescription() {
        return challengeDescription;
    }

    public void setChallengeDescription(String challengeDescription) {
        this.challengeDescription = challengeDescription;
    }

    public String getChallengeType() {
        return challengeType;
    }

    public void setChallengeType(String challengeType) {
        this.challengeType = challengeType;
    }

    public String getChallengePhoto() {
        return challengePhoto;
    }

    public void setChallengePhoto(String challengePhoto) {
        this.challengePhoto = challengePhoto;
    }

    public Integer getChallengePhotoOrietation() {
        return challengePhotoOrietation;
    }

    public void setChallengePhotoOrietation(Integer challengePhotoOrietation) {
        this.challengePhotoOrietation = challengePhotoOrietation;
    }

    public Date getUpdateDate() {
        return updateDate;
    }
 
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Integer getNumberOfVotes() {
        return numberOfVotes;
    }

    public void setNumberOfVotes(Integer numberOfVotes) {
        this.numberOfVotes = numberOfVotes;
    }

    public Boolean getCanBeVotted() {
        return canBeVotted;
    }

    public void setCanBeVotted(Boolean canBeVotted) {
        this.canBeVotted = canBeVotted;
    }
}
