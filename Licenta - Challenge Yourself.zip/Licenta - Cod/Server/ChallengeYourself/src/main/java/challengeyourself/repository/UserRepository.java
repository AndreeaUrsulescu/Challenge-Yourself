/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.repository;

import challengeyourself.entity.User;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ursulescu
 */

@Service
@Transactional
public class UserRepository {
    
    private static final Logger LOG = Logger.getLogger(UserRepository.class.getName());
    
    @PersistenceContext()
    private EntityManager entityManager;
    
    public void createUser(User user) {
        entityManager.persist(user);
    }
    
    public User findUserByEmail(String email) {
        List<User> users;
        
        TypedQuery<User> query = entityManager.createNamedQuery(User.FIND_BY_EMAIL, User.class);
        query.setParameter("email", email);
        users = query.getResultList();
        
        if (users.size() > 0) {
            return users.get(0);
        }
        else {
            return null;
        }
    }
    
    public User findUserById(Long id) {
        List<User> users;
        
        TypedQuery<User> query = entityManager.createNamedQuery(User.FIND_BY_ID, User.class);
        query.setParameter("id", id);
        users = query.getResultList();
        
        if (users.size() > 0) {
            return users.get(0);
        } else {
            return null;
        }
    }
    
    public List<User> getAll(User currentUser, int firstIndex, int itemsCount) {
        List<User> users;
        List<User> excludedUsers = new ArrayList<>();
        
        excludedUsers.addAll(currentUser.getFollowingUsers());
        excludedUsers.add(currentUser);
        
        TypedQuery<User> query = entityManager.createNamedQuery(User.FIND_ALL, User.class);
        query.setParameter("friends", excludedUsers);
        query.setFirstResult(firstIndex).setMaxResults(itemsCount);
        users = query.getResultList();
        
        return users;
    }
    
    public List<User> getUsersByName(User currentUser, int firstIndex, int itemsCount, String searchedName) {
        List<User> users = new ArrayList<>();
        TypedQuery<User> query;
        List<User> excludedUsers = new ArrayList<>();
        
        excludedUsers.addAll(currentUser.getFollowingUsers());
        excludedUsers.add(currentUser);
        
        String[] names = searchedName.trim().split(" +");
        
        for (String name : names) {
            query = entityManager.createNamedQuery(User.FIND_BY_NAME, User.class);
            query.setParameter("friends", excludedUsers);
            query.setParameter("firstName", name + "%");
            query.setParameter("name", "% " + name + "%");
            query.setFirstResult(firstIndex).setMaxResults(itemsCount);
            
            for (User user : query.getResultList()) {
                if (!users.contains(user)) {
                    users.add(user);
                }
            }
        }
        
        if (users.size() > 0) {
            return users;
        }
        
        return null;
    }
    
    public User findUserWithFollowingUsers(String userEmail) {
        List<User> users;
        
        TypedQuery<User> query = entityManager.createNamedQuery(User.FIND_BY_EMAIL_WITH_FOLLOWING, User.class);
        query.setParameter("email", userEmail);
        users = query.getResultList();
        
        if (users.size() > 0) {
            return users.get(0);
        } else {
            return null;
        }
    }
    
    public void followUser(User user, User userToFollow) {
        if (!user.getFollowingUsers().contains(userToFollow)) { 
            user.getFollowingUsers().add(userToFollow);
            entityManager.merge(user);
        }
    }
}
