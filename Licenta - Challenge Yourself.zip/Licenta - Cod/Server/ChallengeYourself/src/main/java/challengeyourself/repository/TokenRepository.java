/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.repository;

import challengeyourself.entity.Token;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ursulescu
 */

@Service
@Transactional
public class TokenRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public void saveToken(Token token) {
        entityManager.persist(token);
    }
    
    public void updateToken(Token token) {
        entityManager.merge(token);
    }
    
    public Token findTokenObjectByToken(String token) {
        List<Token> tokenObjects;
        TypedQuery<Token> query = entityManager.createNamedQuery(Token.FIND_BY_TOKEN, Token.class);
        
        query.setParameter("token", token);
        tokenObjects = query.getResultList();
        
        if (tokenObjects.size() > 0) {
            return tokenObjects.get(0);
        } else {
            return null;
        }
    }
    
    public Token findTokenByUserId(Long userId) {
        List<Token> tokenObjects;
        TypedQuery<Token> query = entityManager.createNamedQuery(Token.FIND_BY_USER_ID, Token.class);
        
        query.setParameter("userId", userId);
        tokenObjects = query.getResultList();
        
        if (tokenObjects.size() > 0) {
            return tokenObjects.get(0);
        } else {
            return null;
        }
    }
    
    public void deleteToken(Token tokenObject) {
        Token managedToken = entityManager.merge(tokenObject);
        entityManager.remove(managedToken);
    }
}
