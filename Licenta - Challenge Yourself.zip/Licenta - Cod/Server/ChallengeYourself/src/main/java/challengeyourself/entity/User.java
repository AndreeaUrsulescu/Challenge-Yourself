/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 *
 * @author Ursulescu
 */

@NamedQueries({@NamedQuery(name = User.FIND_BY_EMAIL, query = "select u from User u where lower(u.email) = lower(:email)"),
    @NamedQuery(name = User.FIND_BY_ID, query = "select u from User u where u.id = :id"), 
    @NamedQuery(name = User.FIND_ALL, query = "select u from User u where u not in (:friends)"),
    @NamedQuery(name = User.FIND_BY_NAME, query = "select u from User u where (((lower(u.name) LIKE lower(:firstName)) OR (lower(u.name) LIKE lower(:name))) and (u not in (:friends)))"),
    @NamedQuery(name = User.FIND_BY_EMAIL_WITH_FOLLOWING, query = "select u from User u left join fetch u.followingUsers where lower(u.email) = lower(:email)")})

@Entity
@Table(name = "users")
public class User implements Serializable{
    
    public static final String FIND_BY_EMAIL = "User.findByEmail";
    public static final String FIND_BY_ID = "User.findById";
    public static final String FIND_ALL = "User.findAll";
    public static final String FIND_BY_EMAIL_WITH_FOLLOWING = "User.findFollowing";
    public static final String FIND_BY_NAME = "User.findByName";
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name = "name", length = 30, nullable = false)
    private String name;
    
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    
    @JsonIgnore
    @Column(name = "password_hash", nullable = false)
    private String passwordHash;
    
    @Column(name = "description")
    private String description;
    
    @Column(name = "profile_photo", nullable = false, columnDefinition = "text")
    private String profilePhtoto;
    
    @Column(name = "photo_orientation", nullable = false)
    private Integer photoOrientation;
    
    @ManyToMany
    @JoinTable(name = "followers", 
            joinColumns = {@JoinColumn(name = "follower_id", referencedColumnName = "id")}, 
            inverseJoinColumns = {@JoinColumn(name = "followed_user_id", referencedColumnName = "id")})
    private List<User> followingUsers = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return passwordHash;
    }

    public void setPassword(String password) {
        this.passwordHash = password;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfilePhtoto() {
        return profilePhtoto;
    }

    public void setProfilePhtoto(String profilePhtoto) {
        this.profilePhtoto = profilePhtoto;
    }
    
    public Integer getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(Integer orientation) {
        this.photoOrientation = orientation;
    }

    public List<User> getFollowingUsers() {
        return followingUsers;
    }

    public void setFollowingUsers(List<User> followingUsers) {
        this.followingUsers = followingUsers;
    }
    
    @Override
    public boolean equals(Object object) {
        if (object instanceof User) {
            User user = (User) object;
            return new EqualsBuilder().append(this.email, user.getEmail())
                    .append(this.name, user.getName()).isEquals();
        }
        
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(name).append(email).append(description).toHashCode();
    }
}
