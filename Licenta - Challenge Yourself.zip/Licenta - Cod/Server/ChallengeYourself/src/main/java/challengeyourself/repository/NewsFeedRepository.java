/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.repository;

import challengeyourself.entity.UserChallenge;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ursulescu
 */
@Service
@Transactional
public class NewsFeedRepository {
    
    @PersistenceContext()
    private EntityManager entityManager;
    
    public List<UserChallenge> getLastUpdatedUserChallengesOfFollowedFriendsInRange(
            List<Long> followedFriendsIds, int firstIndex, int numberOfItems) {
        List<UserChallenge> lastUserChallenges;
        
        TypedQuery<UserChallenge> query = entityManager.createNamedQuery(
                UserChallenge.GET_LAST_UPDATED_OF_FRIENDS, UserChallenge.class);
        query.setParameter("followedUsersIds", followedFriendsIds);
        query.setFirstResult(firstIndex);
        query.setMaxResults(numberOfItems);
        
        lastUserChallenges = query.getResultList();
        return lastUserChallenges;
    }
}
