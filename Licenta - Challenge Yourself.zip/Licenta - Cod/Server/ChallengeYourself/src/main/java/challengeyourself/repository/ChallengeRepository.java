/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.repository;

import challengeyourself.entity.Challenge;
import challengeyourself.entity.Comment;
import challengeyourself.entity.UserChallenge;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Ursulescu
 */
@Service
@Transactional
public class ChallengeRepository {
    
    @PersistenceContext()
    private EntityManager entityManager;
    
    public Challenge getChallengeById(Long id) {
        List<Challenge> challenges;
        
        TypedQuery<Challenge> query = entityManager.createNamedQuery(Challenge.FIND_BY_ID, Challenge.class);
        query.setParameter("id", id);
        challenges = query.getResultList();
        
        if (challenges.size() == 1) {
            return challenges.get(0);
        } else {
            return null;
        }
    }
    
    public UserChallenge getUserChallenge(Long userId, Long challengeId) {
        List<UserChallenge> userChallenges;
        
        TypedQuery<UserChallenge> query = entityManager.createNamedQuery(UserChallenge.FIND_BY_IDS, 
                UserChallenge.class);
        query.setParameter("userId", userId);
        query.setParameter("challengeId", challengeId);
        userChallenges = query.getResultList();
        
        if (userChallenges.size() > 0) {
            return userChallenges.get(0);
        } else {
            return null;
        }
    }
    
    public UserChallenge findUserChallengeById(Long userChallengeId) {
        List<UserChallenge> userChallenges;
        
        TypedQuery<UserChallenge> query = entityManager.createNamedQuery(UserChallenge.FIND_BY_ID, 
                UserChallenge.class);
        query.setParameter("id", userChallengeId);
        userChallenges = query.getResultList();
        
        if (userChallenges.size() > 0) {
            return userChallenges.get(0);
        } else {
            return null;
        }
    }
    
    public List<Challenge> getChallengesFromCategory(String category) {
        
        TypedQuery<Challenge> query = entityManager.createNamedQuery(Challenge.FIND_BY_CATEGORY, 
                Challenge.class);
        query.setParameter("category", category);
        
        return query.getResultList();
    }
    
    public Long getNumberOfDoneChallengesInCategory(Long userId, List<Long> challenges) {
        TypedQuery<Long> query = entityManager.createNamedQuery(UserChallenge.NUMBER_OF_DONE_CHALLENGES,
                Long.class);
        query.setParameter("userId", userId);
        query.setParameter("challenges", challenges);
        return query.getSingleResult();
    }
    
    public List<UserChallenge> getDoneChallengesFromCategory(Long userId, 
            List<Long> challenges) {
        
        TypedQuery<UserChallenge> query = entityManager.createNamedQuery(UserChallenge.FIND_IN_CATEGORY, 
                UserChallenge.class);
        query.setParameter("userId", userId);
        query.setParameter("challenges", challenges);
        
        return query.getResultList();
    }
    
    public List<UserChallenge> getLastUpdatedChallengesForUser(Long userId, int fromIndex,
            int numberOfItems) {
        TypedQuery<UserChallenge> query = entityManager.createNamedQuery(UserChallenge.GET_LAST_UPDATED_OF_USER,
                UserChallenge.class);
        query.setParameter("userId", userId);
        query.setFirstResult(fromIndex).setMaxResults(numberOfItems);
        
        return query.getResultList();
    }
    
    public UserChallenge updateUserChallenge(UserChallenge challengeToBeUpdated) {
        return entityManager.merge(challengeToBeUpdated);
    }
    
    public void saveUserChallenge(UserChallenge userChallenge) {
        entityManager.persist(userChallenge);
    }
    
    public void saveComment(Comment comment) {
        entityManager.persist(comment);
    }
}
