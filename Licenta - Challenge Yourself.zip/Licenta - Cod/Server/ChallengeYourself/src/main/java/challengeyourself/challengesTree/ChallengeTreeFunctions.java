/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.challengesTree;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Ursulescu
 */
public class ChallengeTreeFunctions {
    
    private static long getParentId(long challengeId, Set<ChallengesTree> treeLeaves) {
        
        Set<ChallengesTree> parents = new HashSet<>();
        
        for (ChallengesTree treeNode : treeLeaves) {
            if (treeNode.getChallengeId() == challengeId) {
                if (treeNode.getParent() != null) {
                    return treeNode.getParent().getChallengeId();
                } else {
                    return 0;
                }
            } else if (treeNode.getParent() != null) {
                parents.add(treeNode.getParent());
            }
        }
        return getParentId(challengeId, parents);
    }
    
    public static long getParentIdForAChallenge(long challengeId) {
        Set<ChallengesTree> treeLeaves = null;
        
        if ( (challengeId >= 1) && (challengeId <= 22)) {
            treeLeaves = ChallengesTreeFactory.createFriendshipChallengesTree();
        } else if (challengeId <= 44) {
            treeLeaves = ChallengesTreeFactory.createCultureChallengesTree();
        } else if (challengeId <= 66) {
            treeLeaves = ChallengesTreeFactory.createKitchenChallengesTree();
        } else if (challengeId <= 88) {
            treeLeaves = ChallengesTreeFactory.createEntertainmentChallengesTree();
        }
        
        if (treeLeaves != null) {
            return getParentId(challengeId, treeLeaves);
        } else {
            return -1;
        }
    }
}
