/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Ursulescu
 */
public class Content implements Serializable{
    private List<String> registration_ids;
    private Map<String,String> data;
    
    

    public void addRegId(String regId){
        if(getRegistration_ids() == null)
            setRegistration_ids(new LinkedList<String>());
        getRegistration_ids().add(regId);
    }

    public void createData(String message, String userChallengeId){
        if(getData() == null)
            setData(new HashMap<String,String>());
        getData().put("message", message);
        getData().put("userChallengeId", userChallengeId);
//        getData().put("doneChallenge", userChallenge.getDone());
//        getData().put("encodedThumbnail", userChallenge.getThumbnail());
//        getData().put("encodedPhoto", userChallenge.getPicture());
//        getData().put("photoOrientation", String.valueOf(userChallenge.getPictureOrientation()));
//        getData().put("updateDate", String.valueOf(userChallenge.getUpdateDate()));
//        getData().put("numberOfVotes", String.valueOf(userChallenge.getVotes().size()));
//        getData().put("challengeName", challenge.getName());
//        getData().put("challengeDecsription", challenge.getDescription());
//        getData().put("challengeType", challenge.getCategory());
    }

    public List<String> getRegistration_ids() {
        return registration_ids;
    }

    public void setRegistration_ids(List<String> registration_ids) {
        this.registration_ids = registration_ids;
    }

    public Map<String,String> getData() {
        return data;
    }

    public void setData(Map<String,String> data) {
        this.data = data;
    }
}
