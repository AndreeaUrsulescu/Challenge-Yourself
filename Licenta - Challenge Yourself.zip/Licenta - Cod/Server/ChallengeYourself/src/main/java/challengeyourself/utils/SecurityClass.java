/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author Ursulescu
 */
public class SecurityClass {
    private static Cipher cipher;
    
    public static SecretKey generateKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(128);

            return keyGenerator.generateKey();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void savePrivateKey(SecretKey secretKey) {
        String password = "secretKey";
           
        try {
            KeyStore keyStore = KeyStore.getInstance("JCEKS");
            keyStore.load(null, null); 
            
            KeyStore.SecretKeyEntry keyStoreEntry = new KeyStore.SecretKeyEntry(secretKey);
            KeyStore.PasswordProtection keyPassword = new KeyStore.PasswordProtection("secretPassword".toCharArray());
            keyStore.setEntry("passwordSecretKey", keyStoreEntry, keyPassword);
            keyStore.store(new FileOutputStream("store"), password.toCharArray());

        } catch (KeyStoreException | NoSuchAlgorithmException | IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            Logger.getLogger(SecurityClass.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    public static SecretKey getPrivateKey() {
        String password = "secretKey";
        
        try {
            KeyStore keyStore = KeyStore.getInstance("JCEKS");
            keyStore.load(new FileInputStream("store"), password.toCharArray());    
    
            KeyStore.PasswordProtection keyPassword = new KeyStore.PasswordProtection("secretPassword".toCharArray());
            KeyStore.Entry entry = keyStore.getEntry("passwordSecretKey", keyPassword);    
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) entry).getSecretKey();
 
            return secretKey;
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableEntryException | CertificateException | IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            Logger.getLogger(SecurityClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static String encrypt(String text, SecretKey secretKey) {
        try {
            cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(text.getBytes());
            return Base64.encodeBase64String(encryptedBytes);

        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String encryptedText, SecretKey secretKey) {
        try {
            byte[] bytesToDecrypt = Base64.decodeBase64(encryptedText);
            cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] tokenBytes = cipher.doFinal(bytesToDecrypt);
            return new String(tokenBytes);

        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            e.printStackTrace();
        }
        return null;
    }
}
