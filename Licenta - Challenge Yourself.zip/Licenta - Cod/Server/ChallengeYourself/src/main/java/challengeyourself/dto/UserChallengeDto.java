/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Ursulescu
 */
public class UserChallengeDto implements Serializable{
    
    private Long challengeId;

    private String doneChallenge;
    
    private String thumbnail;
    
    private String picture;

    private Integer pictureOrientation;
    
    private Date updateDate;
    
    private Integer numberOfVotes;
    
    private String challengeName;
    
    private String challengeDescription;
    
    private String challengeType;
    
    public Long getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(Long challengeId) {
        this.challengeId = challengeId;
    }
    
    public String getDoneChallenge() {
        return doneChallenge;
    }

    public void setDoneChallenge(String doneChallenge) {
        this.doneChallenge = doneChallenge;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public Integer getPictureOrientation() {
        return pictureOrientation;
    }

    public void setPictureOrientation(Integer pictureOrientation) {
        this.pictureOrientation = pictureOrientation;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
    public Integer getNumberOfVotes() {
        return numberOfVotes;
    }

    public void setNumberOfVotes(Integer numberOfVotes) {
        this.numberOfVotes = numberOfVotes;
    }

    public String getChallengeName() {
        return challengeName;
    }

    public void setChallengeName(String challengeName) {
        this.challengeName = challengeName;
    }

    public String getChallengeDescription() {
        return challengeDescription;
    }

    public void setChallengeDescription(String challengeDescription) {
        this.challengeDescription = challengeDescription;
    }

    public String getChallengeType() {
        return challengeType;
    }

    public void setChallengeType(String challengeType) {
        this.challengeType = challengeType;
    }
}
