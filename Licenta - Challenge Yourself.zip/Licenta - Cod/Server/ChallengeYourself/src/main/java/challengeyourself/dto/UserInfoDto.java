/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

/**
 *
 * @author Ursulescu
 */
public class UserInfoDto {
    private Long id;
    
    private String name;
    
    private String description;
    
    private String profilePhoto;
    
    private Integer photoOrientation;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfilePhoto() {
        return profilePhoto;
    }

    public void setProfilePhoto(String profilePhoto) {
        this.profilePhoto = profilePhoto;
    }
    
    public Integer getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(Integer orientation) {
        this.photoOrientation = orientation;
    }
}
