/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.entity.Token;
import challengeyourself.entity.User;
import challengeyourself.repository.TokenRepository;
import challengeyourself.repository.UserRepository;
import challengeyourself.utils.TokenUtils;
import java.sql.Timestamp;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class TokenService {
    
    @Autowired
    TokenRepository tokenRepository;
    
    @Autowired
    UserRepository userRepository;
    
    public User getUserByToken(String token) {
        Token tokenObject = tokenRepository.findTokenObjectByToken(token);
        User associatedUser = userRepository.findUserById(tokenObject.getUserId());
        
        if (associatedUser != null) {
            return associatedUser;
        } else {
            return null;
        }
    }
    
    public String saveTokenForUser(String userEmail) {
        String token = TokenUtils.generateToken(userEmail);
        
        User user = userRepository.findUserByEmail(userEmail);
        Token existentToken = tokenRepository.findTokenByUserId(user.getId());
        
        Timestamp currentTime = new Timestamp(new Date().getTime());
        Timestamp expirationTime = new Timestamp(currentTime.getTime() + (5 * 24 * 60 * 60 * 1000));
        
        if (existentToken != null) {
            existentToken.setToken(token);
            existentToken.setCreationDate(currentTime);
            existentToken.setExpirationDate(expirationTime);
            
            tokenRepository.updateToken(existentToken);
        } else {
            Token tokenObject = new Token(user.getId(), token, currentTime , expirationTime);
            tokenRepository.saveToken(tokenObject);
        }
        
        return token;
    }
    
    public boolean isTokenValid(String token) {
        Token tokenObject = tokenRepository.findTokenObjectByToken(token);
        
        if (tokenObject != null) {
            Timestamp currentTime = new Timestamp(new Date().getTime());
            
            if (currentTime.after(tokenObject.getExpirationDate())) {
                tokenRepository.deleteToken(tokenObject);
                return false;
            }
            return true;
        } else {
            return false;
        }
    }
    
    public boolean deleteTokenAssociatedWithUser(String userEmail) {
        User user = userRepository.findUserByEmail(userEmail);
        
        if (user != null) {
            Token token = tokenRepository.findTokenByUserId(user.getId());
            if (token != null) {
                tokenRepository.deleteToken(token);
                return true;
            } 
            return false;
        } else {
            return false;
        }
    }
}
