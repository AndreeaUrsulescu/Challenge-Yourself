/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.utils;

import java.util.HashMap;
import java.util.Map;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

/**
 *
 * @author Ursulescu
 */
public class ErrorMessagesExtractor {
    public static Map<String, Object> getErrorMessages(BindingResult bindingResult) {
        Map<String, Object> result = new HashMap<>();
        
        for (FieldError fieldError : bindingResult.getFieldErrors()) {
            result.put(fieldError.getField(), fieldError.getDefaultMessage() + "\n");
        }
        
        return result;
    }
}
