/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.dto.Content;
import challengeyourself.entity.Challenge;
import challengeyourself.entity.Device;
import challengeyourself.entity.User;
import challengeyourself.entity.UserChallenge;
import challengeyourself.googleCloudMessaging.GoogleCloudMessagingUtils;
import challengeyourself.repository.ChallengeRepository;
import challengeyourself.repository.DeviceRepository;
import challengeyourself.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class NotificationService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ChallengeRepository challengeRepository;
    
    @Autowired
    private DeviceRepository deviceRepository;
    
    public void sendNotificationForApprovedChallenge(Long userToNotificateId, 
            Long approvedChallengeId, Long userThatApprovedId) {
        User userThatApproved = userRepository.findUserById(userThatApprovedId);
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userToNotificateId, approvedChallengeId);
        Challenge approvedChallenge = challengeRepository.getChallengeById(approvedChallengeId);
        
        String notificationMessage = userThatApproved.getName() + " has approved your photo for '" 
                + approvedChallenge.getName() + "' challenge";
        sendMessageToGCM(userToNotificateId, notificationMessage, String.valueOf(userChallenge.getId()));
    }
    
    public void sendNotificationForCommentedChallenge(Long userToNotificateId,
            Long commentedChallengeId, Long userThatCommentedId) {
        User userThatCommented = userRepository.findUserById(userThatCommentedId);
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userToNotificateId, commentedChallengeId);
        Challenge commentedChallenge = challengeRepository.getChallengeById(commentedChallengeId);
        
        String notificationMessage = userThatCommented.getName() + " has commented your photo for '" 
                + commentedChallenge.getName() + "' challenge";
        sendMessageToGCM(userToNotificateId, notificationMessage, String.valueOf(userChallenge.getId()));
    }
    
    public void sendNotificationForPassingChallenge(Long userToNotificateId, Long passedChallengeId) {
        Challenge passedChallenge = challengeRepository.getChallengeById(passedChallengeId);
        UserChallenge userChallenge = challengeRepository.getUserChallenge(userToNotificateId, passedChallengeId);
        
        String notificationMessage = "Congratulations!\nYou have just passed '" + passedChallenge.getName() 
                + "' challenge";
        sendMessageToGCM(userToNotificateId, notificationMessage, String.valueOf(userChallenge.getId()));
    }
    
    public void sendNotificationToFollowedUser(Long userToNotificateId, Long userThatFollowsId) {
        User userThatFollows = userRepository.findUserById(userThatFollowsId);
        
        String notificationMessage = userThatFollows.getName() + " has started following you!";
        sendMessageToGCM(userToNotificateId, notificationMessage, "");
    }
    
    private void sendMessageToGCM(Long userId, String message, String userChallengeId) {
        String apiKey = "AIzaSyCNI-aZWAyAVT3E044u3TEk_ihLDopCyTM";
        Device device = deviceRepository.findDeviceByUser(userId);
        
        if (device != null) {
            Content content = createContent(device.getRegistrationId(), userChallengeId, message);
            GoogleCloudMessagingUtils.post(apiKey, content);
        }
    }
    
    private Content createContent(String regId, String userChallengeId, String message) {
        Content c = new Content();
        c.addRegId(regId);
        c.createData(message, userChallengeId);

        return c;
    }
}
