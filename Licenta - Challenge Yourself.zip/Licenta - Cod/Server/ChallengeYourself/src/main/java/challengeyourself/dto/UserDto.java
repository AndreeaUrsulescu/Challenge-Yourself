/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

import challengeyourself.entity.User;
import challengeyourself.utils.SecurityClass;
import javax.crypto.SecretKey;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author Ursulescu
 */
public class UserDto {
    
    private Long id;
    
    @NotBlank(message = "Name must contain between 3 and 30 characters.")
    @Pattern( regexp = "^[A-Za-z ]*$", message = "Only alphabetic characters and spaces are accepted.")
    @Size(min = 3, max = 30, message = "Name must contain between 3 and 30 characters.")
    private String name;
    
    @NotBlank(message = "Enter a valid email address.")
    @Email(message = "Enter a valid email address.")
    private String email;
    
    @NotBlank(message = "Password must contain between 8 and 20 characters.")
    @Pattern(regexp = "^[A-Za-z0-9]*$", message = "Only alphanumeric characters are accepted.")
    @Size(min = 8, max = 20, message = "Password must contain between 8 and 20 characters.")
    private String password;
    
    @Size(max = 255, message = "Description must contain maximum 255 characters.")
    private String description;
    
    private String profilePhoto;
    
    private Integer photoOrientation;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfilePhoto() {
        return profilePhoto;
    }

    public void setProfilePhoto(String profilePhoto) {
        this.profilePhoto = profilePhoto;
    }
    
    public Integer getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(Integer orientation) {
        this.photoOrientation = orientation;
    }
}
