/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.entity.Device;
import challengeyourself.entity.User;
import challengeyourself.repository.DeviceRepository;
import challengeyourself.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class DeviceService {
    
    @Autowired
    private DeviceRepository deviceRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public void saveDevice(String userEmail, String registerId) {
        User loggedUser = userRepository.findUserByEmail(userEmail);
        
        if (loggedUser != null) {
            Device userDevice = deviceRepository.findDeviceByUser(loggedUser.getId());
            if (userDevice == null) {
                userDevice = new Device(loggedUser.getId(), registerId);
                deviceRepository.saveDevice(userDevice);
            } else if (userDevice.getRegistrationId().compareTo(registerId) != 0) {
                userDevice.setRegistrationId(registerId);
                deviceRepository.updateDevice(userDevice);
            }
        }
       
    }
}
