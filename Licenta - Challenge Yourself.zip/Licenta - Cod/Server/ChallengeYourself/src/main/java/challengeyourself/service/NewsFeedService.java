/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.dto.NewsFeedDto;
import challengeyourself.entity.Challenge;
import challengeyourself.entity.User;
import challengeyourself.entity.UserChallenge;
import challengeyourself.repository.ChallengeRepository;
import challengeyourself.repository.NewsFeedRepository;
import challengeyourself.repository.UserRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class NewsFeedService {
    
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    ChallengeRepository challengeRepository;
    
    @Autowired
    NewsFeedRepository newsFeedRepository;
    
    public List<NewsFeedDto> getNewsFeedInARange(int firstIndex, 
            int numberOfItems, String userEmail) {
        
        List<User> friendsFollowedByUser = userRepository.findUserWithFollowingUsers(userEmail)
                .getFollowingUsers();
        List<Long> usersIds = getIdsFromUsersList(friendsFollowedByUser);
        List<UserChallenge> lastUpdatedUserChallengesOfFollowingFriends =
                newsFeedRepository.getLastUpdatedUserChallengesOfFollowedFriendsInRange(
                        usersIds, firstIndex, numberOfItems);
        
        return convertListOfUserChallengesToNewsFeedDtos(
                lastUpdatedUserChallengesOfFollowingFriends, userEmail);
        
    }
    
    private NewsFeedDto convertUserChallengeToNewsFeedDto(UserChallenge userChallenge, User user) {
        NewsFeedDto newsFeedDto = new NewsFeedDto();
        Challenge challengeInfo = challengeRepository.getChallengeById(
                userChallenge.getChallengeId());
        User postOwnerInfo = userRepository.findUserById(userChallenge.getUserId());
        
        newsFeedDto.setUserId(postOwnerInfo.getId());
        newsFeedDto.setUserName(postOwnerInfo.getName());
        newsFeedDto.setUserPhoto(postOwnerInfo.getProfilePhtoto());
        newsFeedDto.setUserPhotoOrientation(postOwnerInfo.getPhotoOrientation());
        newsFeedDto.setChallengeId(challengeInfo.getId());
        newsFeedDto.setChallengeName(challengeInfo.getName());
        newsFeedDto.setChallengeDescription(challengeInfo.getDescription());
        newsFeedDto.setChallengeType(challengeInfo.getCategory());
        newsFeedDto.setChallengePhoto(userChallenge.getPicture());
        newsFeedDto.setChallengePhotoOrietation(userChallenge.getPictureOrientation());
        newsFeedDto.setUpdateDate(userChallenge.getUpdateDate());
        newsFeedDto.setNumberOfVotes(userChallenge.getVotes().size());
        if (userChallenge.getVotes().contains(user)) {
            newsFeedDto.setCanBeVotted(false);
        } else {
            newsFeedDto.setCanBeVotted(true);
        }
        
        return newsFeedDto;
   }
    
    private List<NewsFeedDto> convertListOfUserChallengesToNewsFeedDtos(
            List<UserChallenge> userChallenges, String userEmail) {
        List<NewsFeedDto> newsFeedDtos = new ArrayList<>();
        User user = userRepository.findUserByEmail(userEmail);
        
        for (UserChallenge userChallenge : userChallenges) {
            newsFeedDtos.add(convertUserChallengeToNewsFeedDto(userChallenge, user));
        }
        return newsFeedDtos;
    }
    
    private List<Long> getIdsFromUsersList(List<User> usersList) {
        List<Long> ids = new ArrayList<>();
        
        for (User user : usersList) {
            ids.add(user.getId());
        }
        
        return ids;
    }
}
