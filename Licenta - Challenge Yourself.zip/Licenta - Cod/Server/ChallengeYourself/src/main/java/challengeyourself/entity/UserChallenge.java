/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Ursulescu
 */
@NamedQueries({@NamedQuery(name = UserChallenge.FIND_BY_IDS, 
        query = "select uc from UserChallenge uc left join fetch uc.comments left join fetch uc.votes where (uc.userId = :userId) and (uc.challengeId = :challengeId)"),
    @NamedQuery(name = UserChallenge.FIND_IN_CATEGORY, 
            query = "select uc from UserChallenge uc left join fetch uc.votes where (uc.userId = :userId) and (uc.challengeId in (:challenges))"),
    @NamedQuery(name = UserChallenge.GET_LAST_UPDATED_OF_FRIENDS,
            query = "select uc from UserChallenge uc left join fetch uc.votes where (uc.userId in (:followedUsersIds)) order by uc.updateDate desc"),
    @NamedQuery(name = UserChallenge.NUMBER_OF_DONE_CHALLENGES,
            query = "select count(uc) from UserChallenge uc where (uc.userId = :userId) and (uc.challengeId in (:challenges)) and (uc.done = 'yes')"),
    @NamedQuery(name = UserChallenge.GET_LAST_UPDATED_OF_USER,
            query = "select uc from UserChallenge uc left join fetch uc.votes where (uc.userId = :userId) order by uc.updateDate desc"),
    @NamedQuery(name = UserChallenge.FIND_BY_ID,
            query = "select uc from UserChallenge uc left join fetch uc.votes where uc.id = :id")})

@Entity
@Table(name = "user_challenges")
public class UserChallenge implements Serializable{
    
    public static final String FIND_BY_IDS = "UserChallenge.findByIds";
    public static final String FIND_IN_CATEGORY = "UserChallenge.findInCategory";
    public static final String GET_LAST_UPDATED_OF_FRIENDS = "UserChallenge.getLastUpdatedOfFriends";
    public static final String GET_LAST_UPDATED_OF_USER = "UserChallenge.getLastUpdatedOfUser";
    public static final String NUMBER_OF_DONE_CHALLENGES = "UserChallenge.numberOfDoneChallenges";
    public static final String FIND_BY_ID = "UserChallenge.findById";
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name = "user_id", nullable = false)
    private Long userId;
    
    @Column(name = "challenge_id", nullable = false)
    private Long challengeId;
    
    @Column(name = "thumbnail", columnDefinition = "text", nullable = false)
    private String thumbnail;
    
    @Column(name = "picture", columnDefinition = "text", nullable = false)
    private String picture;
    
    @Column(name = "picture_orientation", nullable = false)
    private Integer pictureOrientation;
    
    @Column(name = "update_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    
    @ManyToMany
    @JoinTable(name = "votes",
            joinColumns = {@JoinColumn(name = "user_challenge_id", referencedColumnName = "id")},
            inverseJoinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")})
    private Set<User> votes = new LinkedHashSet<>();
    
    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "comments", referencedColumnName = "id")
    private Set<Comment> comments = new LinkedHashSet<>();
    
    @Column(name = "done", nullable = false)
    private String done = "no";

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getChallengeId() {
        return challengeId;
    }

    public void setChallengeId(Long challengeId) {
        this.challengeId = challengeId;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
    
    public Integer getPictureOrientation() {
        return pictureOrientation;
    }

    public void setPictureOrientation(Integer pictureOrientation) {
        this.pictureOrientation = pictureOrientation;
    }
    
    public Set<User> getVotes() {
        return this.votes;
    }
    
    public void setVotes(Set<User> votes) {
        this.votes = votes;
    }
    
    public Set<Comment> getComments() {
        return comments;
    }

    public void setComments(Set<Comment> comments) {
        this.comments = comments;
    }

    public String getDone() {
        return done;
    }

    public void setDone(String done) {
        this.done = done;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
