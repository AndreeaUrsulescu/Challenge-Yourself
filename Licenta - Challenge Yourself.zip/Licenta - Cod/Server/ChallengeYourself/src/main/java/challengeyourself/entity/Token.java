/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Ursulescu
 */

@NamedQueries({@NamedQuery(name=Token.FIND_BY_TOKEN, query="select t from Token t where t.token= :token"),
    @NamedQuery(name = Token.FIND_BY_USER_ID, query = "select t from Token t where t.userId = :userId")})

@Entity
@Table(name="tokens")
public class Token implements Serializable{
    
    public static final String FIND_BY_TOKEN = "Token.findByToken";
    public static final String FIND_BY_USER_ID = "Token.findByUserId";
   
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name="user_id", nullable=false, unique=true)
    private Long userId;
    
    @Column(name="token", nullable=false, unique=true)
    private String token;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="creation_date", nullable=false)
    private Date creationDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="expiration_date", nullable=false)
    private Date expirationDate;
    
    public Token() {}
    
    public Token(Long uId, String tokenString, Timestamp currentDate, Timestamp expirationTime) {
        this.userId = uId;
        this.token = tokenString;
        this.creationDate = currentDate;
        this.expirationDate = expirationTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Timestamp creationDate) {
        this.creationDate = creationDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Timestamp expirationDate) {
        this.expirationDate = expirationDate;
    }
}
