/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.controller;

import challengeyourself.dto.CommentDto;
import challengeyourself.dto.UserChallengeDto;
import challengeyourself.dto.UserDto;
import challengeyourself.entity.User;
import challengeyourself.repository.ChallengeRepository;
import challengeyourself.service.ChallengeService;
import challengeyourself.service.NotificationService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Ursulescu
 */
@Controller
public class ChallengeController {
    
    @Autowired
    private ChallengeService challengeService;
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private ChallengeRepository challengeRepository;
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/userchallenge/{id}")
    @ResponseBody
    public Map<String, Object> getUserChallenge(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        response.put("challenge", challengeService.convertUserChallengeToDto(
            challengeRepository.findUserChallengeById(id)));
        return response;
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/challenge/{id}")
    @ResponseBody
    public Map<String, Object> getChallengeInfo(@PathVariable Long id, HttpServletResponse response, HttpServletRequest request) {
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        Map<String, Object> challengeInfo = challengeService.getChallengeInfo(id, authenticatedUser.getId());
        
        return challengeInfo;
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/challenges/{category}")
    @ResponseBody
    public Map<String, Object> getChallengesForUser(@PathVariable String category, 
            HttpServletResponse response, HttpServletRequest request) {
        Map<String, Object> result = new HashMap<>();
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        List<UserChallengeDto> userChallenges = challengeService.getChallengesInCategoryForUser(category, 
                authenticatedUser.getId());
        
        if (userChallenges.size() > 0) {
            result.put("existChallenges", true);
            result.put("challenges", userChallenges);
        } else {
            result.put("existChallenges", false);
        }
        
        return result;
    }
    
    @RequestMapping(method = RequestMethod.POST, value = "/api/challenge/{id}/photo")
    @ResponseBody
    public void postPictureForChallenge(@PathVariable Long id, @RequestBody UserChallengeDto challenge) {
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        challengeService.postPictureForChallenge(authenticatedUser.getId(), challenge);
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/challenge/{id}/votes")
    @ResponseBody
    public Map<String, Object> getVotesForChallenge(@PathVariable Long id,
            @RequestParam("firstIndex") int firstIndex, 
            @RequestParam("itemsCount") int itemsCount,
            @RequestParam(value = "userId", required = false) Long userId) {
        
        Map<String, Object> response = new HashMap<>();
        Long challengeOwnerId;
        
        if (userId != null) {
            challengeOwnerId = userId;
        } else {
            UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
            User authenticatedUser = (User) authentication.getPrincipal();
            challengeOwnerId = authenticatedUser.getId();
        }
        
        List<UserDto> votes = challengeService.getVotesForUserChallenge(challengeOwnerId, id, 
                firstIndex, itemsCount);
        
        if (votes.size() > 0) {
            response.put("existVotes", true);
            response.put("votes", votes);
        } else {
            response.put("existVotes", false);
        }
        return response;
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/challenge/{id}/approve")
    @ResponseBody
    public void approveChallenge(@PathVariable Long id, @RequestParam(value = "userId",
            required = true) Long userId) {
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        challengeService.addVoteToUserChallenge(userId, id, authenticatedUser.getId());
        notificationService.sendNotificationForApprovedChallenge(userId, id, authenticatedUser.getId());
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/challenge/{id}/comments")
    @ResponseBody
    public Map<String, Object> getComments(@PathVariable Long id, 
            @RequestParam(value = "userId", required = false) Long userId, 
            @RequestParam("firstIndex") int firstIndex, 
            @RequestParam("numberOfItems") int numberOfItems) {
        
        Map<String, Object> result = new HashMap<>();
        Long uId = userId;
        
        if (userId == null) {
            UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
            User authenticatedUser = (User) authentication.getPrincipal();
            uId = authenticatedUser.getId();
        }
        List<CommentDto> commentDtos = challengeService.getCommentsForUserChallenge(id, 
                uId, firstIndex, numberOfItems);
        
        if (commentDtos != null && commentDtos.size() > 0) {
            result.put("existComments", true);
            result.put("comments", commentDtos);
        } else {
            result.put("existComments", false);
        }
        return result;
     }
    
    @RequestMapping(method = RequestMethod.POST, value = "/api/challenge/{id}/addcomment")
    @ResponseBody
    public Map<String, Object> addComment(@RequestBody Map<String, String> comment,
            @PathVariable Long id, @RequestParam(value = "userId", required = false) Long userId) {
        Map<String, Object> result = new HashMap<>();
        Long uId = userId;
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        if (userId == null) {
            uId = authenticatedUser.getId();
        } else {
            notificationService.sendNotificationForCommentedChallenge(userId, id, authenticatedUser.getId());
        }
        
        boolean success = challengeService.addCommentToUserChallenge(id, uId, 
                authenticatedUser.getId(), comment.get("comment"));
        result.put("success", success);
        return result;
    }
}
