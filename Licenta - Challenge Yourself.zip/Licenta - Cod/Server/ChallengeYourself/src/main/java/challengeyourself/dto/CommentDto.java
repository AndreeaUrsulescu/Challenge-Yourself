/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.dto;

import java.util.Date;

/**
 *
 * @author Ursulescu
 */
public class CommentDto implements Comparable<CommentDto>{
    
    private Long userId;
    
    private String username;
    
    private String userPhoto;
    
    private Integer photoOrientation;
    
    private String comment;
    
    private Date date;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public Integer getPhotoOrientation() {
        return photoOrientation;
    }

    public void setPhotoOrientation(Integer photoOrientation) {
        this.photoOrientation = photoOrientation;
    }

    @Override
    public int compareTo(CommentDto o) {
        return -this.date.compareTo(o.date);
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
