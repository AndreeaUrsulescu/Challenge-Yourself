/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.controller;

import challengeyourself.dto.LoginDto;
import challengeyourself.entity.Device;
import challengeyourself.entity.User;
import challengeyourself.repository.DeviceRepository;
import challengeyourself.service.DeviceService;
import challengeyourself.service.TokenService;
import challengeyourself.utils.SecurityClass;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author Ursulescu
*/

@Controller
public class AuthenticationController {
    
    @Autowired
    AuthenticationManager authenticationManager;
    
    @Autowired
    TokenService tokenService;
    
    @Autowired
    private DeviceService deviceService;
    
    @Autowired
    private DeviceRepository deviceRepository;
    
    @RequestMapping(method = RequestMethod.POST, value = "/authenticate")
    public void authenticateUser(@RequestBody LoginDto loginData, 
            HttpServletResponse response, HttpServletRequest request) {
        
        SecretKey secretKey = SecurityClass.getPrivateKey();
        loginData.setPassword(SecurityClass.encrypt(loginData.getPassword(), secretKey));
        
        Authentication authenticationData = new UsernamePasswordAuthenticationToken(loginData.getEmail(), 
                loginData.getPassword());
        
        Authentication authenticationResult = authenticationManager.authenticate(authenticationData);
        
        if (authenticationResult != null) {
            SecurityContext securityContext = SecurityContextHolder.getContext();
            securityContext.setAuthentication(authenticationResult);
           
            deviceService.saveDevice(loginData.getEmail(), loginData.getDeviceRegisterId());
            
            String token = tokenService.saveTokenForUser(loginData.getEmail());
            
            response.addHeader("X-Auth-Token", token);
        }
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "/api/logout")
    @ResponseBody
    public Map<String, Object> logout(HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> result = new HashMap<>();
        
        UsernamePasswordAuthenticationToken authentication = 
                (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
        User authenticatedUser = (User) authentication.getPrincipal();
        
        boolean successfulDeletion = tokenService.deleteTokenAssociatedWithUser(authenticatedUser.getEmail());
        
        if (successfulDeletion) {
            Device userDevice = deviceRepository.findDeviceByUser(authenticatedUser.getId());
            deviceRepository.deleteDevice(userDevice);
        }
        
        result.put("success", successfulDeletion);
        return result;
    }
}
