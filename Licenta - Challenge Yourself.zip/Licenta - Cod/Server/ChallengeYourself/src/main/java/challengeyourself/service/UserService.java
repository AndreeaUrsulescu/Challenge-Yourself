/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.service;

import challengeyourself.dto.UserDto;
import challengeyourself.dto.UserInfoDto;
import challengeyourself.entity.User;
import challengeyourself.repository.UserRepository;
import challengeyourself.utils.SecurityClass;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ursulescu
 */
@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    public User getUserEntityFromUserDto(UserDto userDto) {
        SecretKey secretKey = SecurityClass.getPrivateKey();
                
        User user = new User();
        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setDescription(userDto.getDescription());
        user.setPassword(SecurityClass.encrypt(userDto.getPassword(), secretKey));
        user.setProfilePhtoto(userDto.getProfilePhoto());
        user.setPhotoOrientation(userDto.getPhotoOrientation());
        
        return user;
    }
    
    public UserInfoDto convertUserToUserInfoDto(User user) {
        UserInfoDto userInfoDto = new UserInfoDto();
        
        userInfoDto.setId(user.getId());
        userInfoDto.setName(user.getName());
        userInfoDto.setDescription(user.getDescription());
        userInfoDto.setProfilePhoto(user.getProfilePhtoto());
        userInfoDto.setPhotoOrientation(user.getPhotoOrientation());
        
        return userInfoDto;
    }
    
    public boolean userEmailIsUsed(String email) {
        User user = userRepository.findUserByEmail(email);    
        return user != null;
    }
    
    public void registerUser(UserDto userDto) {
        User user = getUserEntityFromUserDto(userDto);
        userRepository.createUser(user);
    }
    
    public User login(String email, String password) {
        User user = userRepository.findUserByEmail(email);
                
        if (user != null) {
            SecretKey secretKey = SecurityClass.getPrivateKey();
            if (SecurityClass.decrypt(password, secretKey).compareTo(
                    SecurityClass.decrypt(user.getPassword(), secretKey)) == 0) {
                return user;
            }
            return null;
        }
        
        return null;
    }
    
    public List<UserInfoDto> getAllUsers(String currentUserEmail, int firstIndex, int itemsCount) {
        List<UserInfoDto> userInfoDtos = new ArrayList<>();
        
        User currentUser = userRepository.findUserWithFollowingUsers(currentUserEmail);
        List<User> users = userRepository.getAll(currentUser, firstIndex, itemsCount);
        
        for (User user : users) {
            userInfoDtos.add(convertUserToUserInfoDto(user));
        }
        
        return userInfoDtos;
    }
    
    public List<UserInfoDto> getUsersByName(String currentUserEmail, int firstIndex, 
            int itemsCount, String searchedUser) {
        List<UserInfoDto> userInfoDtos = new ArrayList<>();
        
        User currentUser = userRepository.findUserWithFollowingUsers(currentUserEmail);
        List<User> users = userRepository.getUsersByName(currentUser, firstIndex, itemsCount, searchedUser);
        
        for (User user : users) {
            userInfoDtos.add(convertUserToUserInfoDto(user));
        }
        
        return userInfoDtos;
    }
    
    public boolean followUser(String userEmail, Long followingUserId) {
        User user = userRepository.findUserWithFollowingUsers(userEmail);
        User userToFollow = userRepository.findUserById(followingUserId);
        
        if (user != null && userToFollow != null) {
            userRepository.followUser(user, userToFollow);
            return true;
        }
        return false;
    }
    
    public List<UserInfoDto> getFriendsOfUser(Long userId, int fromIndex, int numberOfItems) {
        List<UserInfoDto> friends = new ArrayList<>();
        
        User user = userRepository.findUserById(userId);
        user = userRepository.findUserWithFollowingUsers(user.getEmail());
        List<User> users = user.getFollowingUsers();
        
        for (User friend : users) {
            friends.add(convertUserToUserInfoDto(friend));
        }
        
        if (friends.size() - fromIndex >= numberOfItems) {
            return friends.subList(fromIndex, fromIndex + numberOfItems);
        } else {
            return friends.subList(fromIndex, fromIndex + friends.size() - fromIndex);
        }
    }
}
