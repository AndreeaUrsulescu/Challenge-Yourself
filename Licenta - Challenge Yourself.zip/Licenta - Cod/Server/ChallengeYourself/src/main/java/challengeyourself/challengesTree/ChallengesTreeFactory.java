/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.challengesTree;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Ursulescu
 */
public class ChallengesTreeFactory {
    
    private static ChallengesTree createChallengeNode(long challengeId, ChallengesTree parent) {
        ChallengesTree challengeNode = new ChallengesTree();
        
        challengeNode.setChallengeId(challengeId);
        challengeNode.setParent(parent);
        
        return challengeNode;
    }
    
    public static Set<ChallengesTree> createFriendshipChallengesTree() {
        Set<ChallengesTree> leaves = new HashSet<>();
        ChallengesTree challenge1Node = createChallengeNode(1, null);
        
        ChallengesTree challenge2Node = createChallengeNode(2, challenge1Node);
        ChallengesTree challenge3Node = createChallengeNode(3, challenge1Node);
        ChallengesTree challenge4Node = createChallengeNode(4, challenge1Node);
        
        ChallengesTree challenge5Node = createChallengeNode(5, challenge2Node);
        ChallengesTree challenge6Node = createChallengeNode(6, challenge2Node);
        leaves.add(challenge5Node);
        leaves.add(challenge6Node);
        
        ChallengesTree challenge7Node = createChallengeNode(7, challenge4Node);
        ChallengesTree challenge8Node = createChallengeNode(8, challenge4Node);
        leaves.add(challenge7Node);
        leaves.add(challenge8Node);
        
        ChallengesTree challenge9Node = createChallengeNode(9, challenge3Node);
        ChallengesTree challenge10Node = createChallengeNode(10, challenge3Node);
        ChallengesTree challenge11Node = createChallengeNode(11, challenge3Node);
        
        ChallengesTree challenge12Node = createChallengeNode(12, challenge9Node);
        ChallengesTree challenge15Node = createChallengeNode(15, challenge12Node);
        leaves.add(challenge15Node);
        
        ChallengesTree challenge14Node = createChallengeNode(14, challenge11Node);
        ChallengesTree challenge18Node = createChallengeNode(18, challenge14Node);
        leaves.add(challenge18Node);
        
        ChallengesTree challenge13Node = createChallengeNode(13, challenge10Node);
        
        ChallengesTree challenge16Node = createChallengeNode(16, challenge13Node);
        ChallengesTree challenge17Node = createChallengeNode(17, challenge13Node);
        
        ChallengesTree challenge19Node = createChallengeNode(19, challenge16Node);
        ChallengesTree challenge20Node = createChallengeNode(20, challenge16Node);
        leaves.add(challenge19Node);
        leaves.add(challenge20Node);
        
        ChallengesTree challenge21Node = createChallengeNode(21, challenge17Node);
        ChallengesTree challenge22Node = createChallengeNode(22, challenge17Node);
        leaves.add(challenge21Node);
        leaves.add(challenge22Node);
        
        return leaves;
    }
    
    public static Set<ChallengesTree> createCultureChallengesTree() {
        Set<ChallengesTree> leaves = new HashSet<>();
        ChallengesTree challenge23Node = createChallengeNode(23, null);
        
        ChallengesTree challenge24Node = createChallengeNode(24, challenge23Node);
        ChallengesTree challenge25Node = createChallengeNode(25, challenge23Node);
        ChallengesTree challenge26Node = createChallengeNode(26, challenge23Node);
        
        ChallengesTree challenge27Node = createChallengeNode(27, challenge24Node);
        ChallengesTree challenge28Node = createChallengeNode(28, challenge24Node);
        leaves.add(challenge27Node);
        leaves.add(challenge28Node);
        
        ChallengesTree challenge29Node = createChallengeNode(29, challenge26Node);
        ChallengesTree challenge30Node = createChallengeNode(30, challenge26Node);
        leaves.add(challenge29Node);
        leaves.add(challenge30Node);
        
        ChallengesTree challenge31Node = createChallengeNode(31, challenge25Node);
        ChallengesTree challenge32Node = createChallengeNode(32, challenge25Node);
        ChallengesTree challenge33Node = createChallengeNode(33, challenge25Node);
        
        ChallengesTree challenge34Node = createChallengeNode(34, challenge31Node);
        ChallengesTree challenge37Node = createChallengeNode(37, challenge34Node);
        leaves.add(challenge37Node);
        
        ChallengesTree challenge36Node = createChallengeNode(36, challenge33Node);
        ChallengesTree challenge40Node = createChallengeNode(40, challenge36Node);
        leaves.add(challenge40Node);
        
        ChallengesTree challenge35Node = createChallengeNode(35, challenge32Node);
        
        ChallengesTree challenge38Node = createChallengeNode(38, challenge35Node);
        ChallengesTree challenge39Node = createChallengeNode(39, challenge35Node);
        
        ChallengesTree challenge41Node = createChallengeNode(41, challenge38Node);
        ChallengesTree challenge42Node = createChallengeNode(42, challenge38Node);
        leaves.add(challenge41Node);
        leaves.add(challenge42Node);
        
        ChallengesTree challenge43Node = createChallengeNode(43, challenge39Node);
        ChallengesTree challenge44Node = createChallengeNode(44, challenge39Node);
        leaves.add(challenge43Node);
        leaves.add(challenge44Node);
        
        return leaves;
    }
    
    public static Set<ChallengesTree> createKitchenChallengesTree() {
        Set<ChallengesTree> leaves = new HashSet<>();
        ChallengesTree challenge45Node = createChallengeNode(45, null);
        
        ChallengesTree challenge46Node = createChallengeNode(46, challenge45Node);
        ChallengesTree challenge47Node = createChallengeNode(47, challenge45Node);
        ChallengesTree challenge48Node = createChallengeNode(48, challenge45Node);
        
        ChallengesTree challenge49Node = createChallengeNode(49, challenge46Node);
        ChallengesTree challenge50Node = createChallengeNode(50, challenge46Node);
        leaves.add(challenge49Node);
        leaves.add(challenge50Node);
        
        ChallengesTree challenge51Node = createChallengeNode(51, challenge48Node);
        ChallengesTree challenge52Node = createChallengeNode(52, challenge48Node);
        leaves.add(challenge51Node);
        leaves.add(challenge52Node);
        
        ChallengesTree challenge53Node = createChallengeNode(53, challenge47Node);
        ChallengesTree challenge54Node = createChallengeNode(54, challenge47Node);
        ChallengesTree challenge55Node = createChallengeNode(55, challenge47Node);
        
        ChallengesTree challenge56Node = createChallengeNode(56, challenge53Node);
        ChallengesTree challenge59Node = createChallengeNode(59, challenge56Node);
        leaves.add(challenge59Node);
        
        ChallengesTree challenge58Node = createChallengeNode(58, challenge55Node);
        ChallengesTree challenge62Node = createChallengeNode(62, challenge58Node);
        leaves.add(challenge62Node);
        
        ChallengesTree challenge57Node = createChallengeNode(57, challenge54Node);
        
        ChallengesTree challenge60Node = createChallengeNode(60, challenge57Node);
        ChallengesTree challenge61Node = createChallengeNode(61, challenge57Node);
        
        ChallengesTree challenge63Node = createChallengeNode(63, challenge60Node);
        ChallengesTree challenge64Node = createChallengeNode(64, challenge60Node);
        leaves.add(challenge63Node);
        leaves.add(challenge64Node);
        
        ChallengesTree challenge65Node = createChallengeNode(65, challenge61Node);
        ChallengesTree challenge66Node = createChallengeNode(66, challenge61Node);
        leaves.add(challenge65Node);
        leaves.add(challenge66Node);
        
        return leaves;
    }
    
    public static Set<ChallengesTree> createEntertainmentChallengesTree() {
        Set<ChallengesTree> leaves = new HashSet<>();
        ChallengesTree challenge67Node = createChallengeNode(67, null);
        
        ChallengesTree challenge68Node = createChallengeNode(68, challenge67Node);
        ChallengesTree challenge69Node = createChallengeNode(69, challenge67Node);
        ChallengesTree challenge70Node = createChallengeNode(70, challenge67Node);
        
        ChallengesTree challenge71Node = createChallengeNode(71, challenge68Node);
        ChallengesTree challenge72Node = createChallengeNode(72, challenge68Node);
        leaves.add(challenge71Node);
        leaves.add(challenge72Node);
        
        ChallengesTree challenge73Node = createChallengeNode(73, challenge70Node);
        ChallengesTree challenge74Node = createChallengeNode(74, challenge70Node);
        leaves.add(challenge73Node);
        leaves.add(challenge74Node);
        
        ChallengesTree challenge75Node = createChallengeNode(75, challenge69Node);
        ChallengesTree challenge76Node = createChallengeNode(76, challenge69Node);
        ChallengesTree challenge77Node = createChallengeNode(77, challenge69Node);
        
        ChallengesTree challenge78Node = createChallengeNode(78, challenge75Node);
        ChallengesTree challenge81Node = createChallengeNode(81, challenge78Node);
        leaves.add(challenge81Node);
        
        ChallengesTree challenge80Node = createChallengeNode(80, challenge77Node);
        ChallengesTree challenge84Node = createChallengeNode(84, challenge80Node);
        leaves.add(challenge84Node);
        
        ChallengesTree challenge79Node = createChallengeNode(79, challenge76Node);
        
        ChallengesTree challenge82Node = createChallengeNode(82, challenge79Node);
        ChallengesTree challenge83Node = createChallengeNode(83, challenge79Node);
        
        ChallengesTree challenge85Node = createChallengeNode(85, challenge82Node);
        ChallengesTree challenge86Node = createChallengeNode(86, challenge82Node);
        leaves.add(challenge85Node);
        leaves.add(challenge86Node);
        
        ChallengesTree challenge87Node = createChallengeNode(87, challenge83Node);
        ChallengesTree challenge88Node = createChallengeNode(88, challenge83Node);
        leaves.add(challenge87Node);
        leaves.add(challenge88Node);
        
        return leaves;
    }
}
