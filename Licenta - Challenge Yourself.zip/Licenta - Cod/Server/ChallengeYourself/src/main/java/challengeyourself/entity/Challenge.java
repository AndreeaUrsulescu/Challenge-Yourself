/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package challengeyourself.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 *
 * @author Ursulescu
 */
@NamedQueries({@NamedQuery(name = Challenge.FIND_BY_ID, query = "select c from Challenge c where c.id = :id"),
    @NamedQuery(name = Challenge.FIND_BY_CATEGORY, query = "select c from Challenge c where c.category = :category")})

@Entity
@Table(name = "challenges")
public class Challenge implements Serializable{
    
    public static final String FIND_BY_ID = "Challenge.findById";
    public static final String FIND_BY_CATEGORY = "Challenge.findByCategory";
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "description", nullable = false)
    private String description;
    
    @Column(name ="category", nullable = false)
    private String category;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    @Override
    public boolean equals(Object object) {
        if (object instanceof Challenge) {
            Challenge challenge = (Challenge) object;
            return new EqualsBuilder().append(this.name, challenge.getName())
                    .append(this.description, challenge.getDescription())
                    .append(this.category, challenge.getCategory()).isEquals();
        }
        
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(name).append(description).append(category).toHashCode();
    }
}
